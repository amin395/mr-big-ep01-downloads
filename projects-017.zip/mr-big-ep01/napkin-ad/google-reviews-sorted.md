# YO SKINCARE Google reviews: sorted for ad use

Pulled October 21, 2026 from the Google reviews widget on yoskincare.com (Reputon widget). The listing shows **5.0 stars from 70 reviews**; the widget loaded **50** of them, 41 with text.

An automated browser read the review text. Before any review goes into an ad, check its exact wording on Google and get the reviewer's OK.

Rules (FTC Endorsement Guides, 16 CFR 255.1(a) and 255.2): a review in our ad counts as our own claim. So in ads we use only reviews about experience, feel, scent, price or service, and never condition or cure claims. Quote exactly; "..." may shorten a review but must not change its meaning. Credit the reviewer as first name and last initial, with the stars and a "Google review" label.

## Top picks for the ad (the Beat 9 "comments flip" in Storytime)

| # | Reviewer (credit as) | Quote to use | Why it works |
|---|---|---|---|
| 1 | Tanesha W. | "My skin has a consistent GLOW! This face & body wash finally forced me to throw my other products out because they simply don't compare." | The glow, and she switched |
| 2 | Valerie E. | "The facial oil feels nice on skin. Not greasy or oily. Absorbs well into my skin." | Proves "grease, not oil" |
| 3 | Allegra E. | "The face oil is not greasy... It is the only thing I use on my face." | Same point; the "does not break me out" part is cut |
| 4 | Inshirah J. | "I love that they feel lightweight... people are always saying, 'Ooh, girl, you smell good!'" | Her voice, culture, lightweight |
| 5 | Kareemah M. | "...my skin retains moisture, doesn't dry out and is glowing like summertime!" | Glow, phrased like her |
| 6 | Anthony W. | "I've gotten so many compliments on my skin." | Social proof, and men buy too |
| 7 | D. C. | "BLACK GOLD!!!" | Two words that work as a hook or end-card tag |

## Also safe (experience, scent, price, service, story)

- **Dianne F.:** "My skin is soft and supple. The scent is not overpowering."
- **Kue W.:** "It smells really good, and it doesn't leave my skin dry afterwards."
- **Naadiya M.:** "My skin literally feels squeaky clean!"
- **Janice B.:** her husband loves it, it's face and body in one, and she buys 6 at a time. (Good for the men angle.)
- **Andrew B.:** "Great quality personal care products at a reasonable price!" (The price angle.)
- **Tonga B.:** "I purchased it on impulse because it was a black owned company... I stopped eating and said sell me one now." (Funny and cultural; fix the "implus" typo only if she approves.)
- **Gee T.:** "Wow! What an amazing experience! I didn't want to get out the shower." (Fun.)
- **Frank B.:** "The Face and Body Wash had me jumping in the shower even when I didn't need to."
- **Chante L.:** "If you have sensitive skin, be sure to purchase Unscented! ... My skin feels amazing."
- **Otycs:** "I had the opportunity to meet the owner of the Products, Very hard working man." (Proof for the booth and founders.)
- **The Earth:** "I first found out about this amazing company at the New Black Wall Street Market in Stonecrest, Georgia." (Booth proof.)
- **Lovable M., Ramtulaye M.:** soft, smooth, glowing.
- **Drizzy Z., Zuhayra M., Zarina H.:** customer service.

## Do NOT use in ads or marketing (condition or cure claims, or other risk)

| Reviewer | Problem |
|---|---|
| Karla M. | "my eczema has calmed down": a condition claim |
| Esha H. | "helped my skin and hyperpigmentation": a condition claim |
| Violet M. | perioral dermatitis, "no outbreak": a condition claim |
| Asia O. | skin rash "gone away completely": a cure claim |
| Marcus D. | acne "cleared it right up", dermatologist comparison: a cure claim |
| M M. | "Skin much clearer": an acne implication |
| Lynnia L. | "hydrated and clear": "clear" implies acne |
| Xavier S. | "My skin is healing", and the reviewer is 16 (a minor) |
| FWG | reduced puffiness around the eyes: a physiological claim |
| Avery M. | "pores has reduced": a structure claim |
| Cheron H. | sunburn soothed (her "softer, healthier, bright" part alone is OK) |
| Umar C. | "The best... there is": a superlative we avoid |
| Qualityby Shannon | names a competitor (Dove) |
| Keishon K. | "10 essential oils", "all skin types and issues", plus his own business plug |
| Shamika K. | beard use: off-message for this ad |

No-text 5-star reviews (Attiyya A., Nyjer E., Dimkha D., Katrina P., Cierra A., Chocolatte G., Simone B., georg b., Kirsten) count toward the 5.0 rating but have no quotes.

## Insight from the reviews (for the story)

- Many reviewers met you at festivals (Sweet Auburn Fest, the Malcolm X Festival, New Black Wall Street Market). That backs up the booth scene.
- Scent comes up again and again: lemongrass and peppermint, "you smell good!" That's a sensory beat we haven't used yet.
- Husbands and sons use it too, which is an easy line for a male angle in the cutdowns.
- Customers found YO because it's Black-owned, and they say so.
