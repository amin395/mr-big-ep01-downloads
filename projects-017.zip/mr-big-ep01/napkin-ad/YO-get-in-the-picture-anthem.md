**Goal:** an original anthem a Black woman would play on repeat, in the car, getting dressed, after a long shift. She hears her own fears, secrets and pride in it and walks away lifted. **Done:** full lyrics, the exact Suno settings, three sound options with my pick, and a checklist for choosing the winning version.

## What the song has to do

- **She sees herself, good, bad and ugly.** The verses tell the truth she doesn't say out loud: "I'm fine," crying in the car, carrying everybody, covering what she's ashamed of, being called "too much," buying what the phone sold her. Nothing is softened.
- **She hears her pride.** Her hard work, her patience, her steadiness, showing up when nobody showed up for her. The song honors those things before it asks her to set the weight down.
- **She gets lifted, not lectured.** The chorus never tells her she's wrong. It invites her into the picture, the way a sister would.
- **It stands alone.** The full song works as a single and as a TikTok or Reels sound, without the film. That is what makes people play it again and again. The film uses a shorter cut.
- **Wash and feed, both.** The bridge sings the whole method as her own healing: wash off what she carried, then feed herself and pour back what she gave away. It mirrors the routine without making a product claim. Ms. Faye does the product talk, spoken.

## The lyrics: "Get In The Picture"

Paste this into Suno exactly. Words in square brackets are directions, so Suno doesn't sing them. Words in parentheses are sung as backing vocals.

**[Intro]** [soft Rhodes, vinyl crackle, one camera shutter click, humming]\
Mm-mm...\
(Get in, baby...)

**[Verse 1]**\
I was raised on "baby, you strong,"\
so I never learned how to be held.\
Kept a smile for the church folk,\
kept the lights on, kept the rest to myself.\
Edges laid with a toothbrush and a prayer,\
sweat running from a double shift.\
Heard "Mama, can you stand in the back?"\
and I been standing there ever since.

**[Pre-Chorus]**\
I said "I'm fine" so many times\
my own mirror thinks it's true.\
But "fine" is just one more layer\
I put on 'fore I walk in the room...

**[Chorus]**\
So get in the picture, baby, get in.\
Front row, chin up, let the flash come in.\
Every shift, every gray, every "I'm okay,"\
every tear in the car on the way.\
I ain't hiding what my mama gave me,\
I ain't stepping out again.\
Get in the picture... get in.

**[Post-Chorus]** [stacked vocals, chant]\
I'm in it, I'm in it (front row)\
I'm in it, I'm in it (let 'em know)\
I'm in it, I'm in it (all of me)\
Get in the picture... get in.

**[Verse 2]**\
Five a.m., silk press and a full face,\
that's my armor, that's my shield.\
"You're so articulate" by lunchtime,\
fix it by two so nobody sees what's real.\
Too loud, too strong, too much, too proud,\
I been called it all and still kept my head high.\
Eleven steps and a ring light,\
they sold me glass and I bought the lie.

**[Pre-Chorus]**\
I carried everybody's weight\
'cause that's what strong girls do.\
But who holds the one who holds it down?\
Tonight I'm holding me too...

**[Chorus]**\
So get in the picture, baby, get in.\
Front row, chin up, let the flash come in.\
Every shift, every gray, every "I'm okay,"\
every tear in the car on the way.\
I ain't hiding what my mama gave me,\
I ain't stepping out again.\
Get in the picture... get in.

**[Post-Chorus]** [stacked vocals, chant]\
I'm in it, I'm in it (front row)\
I'm in it, I'm in it (let 'em know)\
I'm in it, I'm in it (all of me)\
Get in the picture... get in.

**[Bridge]** [music drops to piano and a soft choir hum]\
Wash it off (wash it off)\
every layer, every lie.\
Wash it off (wash it off)\
every year I didn't cry.\
Then feed me (feed me)\
like I fed everybody else.\
Pour it back (pour it back)\
I'm saving some for myself.\
What my grandmama knew, what her mama knew:\
wash it off, then feed it, let the real come through.\
I'm not too much, I'm not too little,\
I'm just finally... me.

**[Build]** [drums return, choir rising]\
I been patient (patient), I been steady (steady),\
showed up for everybody when nobody showed for me.\
I been faithful (faithful), I been ready (ready),\
now I'm showing up for me...

**[Final Chorus]** [key change up, full choir, biggest vocal]\
Get in the picture, Mama, get in.\
Front row, hold my hand, let the flash come in.\
Every shift, every sacrifice, every quiet prayer,\
I see you, Mama, I see you there.\
You ain't hiding what you gave me,\
you ain't stepping out again.\
Get in the picture... get in.

**[Post-Chorus]** [full choir chant]\
We in it, we in it (front row)\
Real glow, not glass (let 'em know)\
We in it, we in it (all of us)\
Get in the picture... get in.

**[Outro]** [voice alone, then one camera shutter click]\
Get in.

## What each part taps into

| Part | What she feels | The truth in it |
|---|---|---|
| Verse 1 | Recognized, a little exposed | The "strong Black woman" she was raised to be, the work, the sweat, the mother told to stand in the back |
| Pre-Chorus 1 | Caught | The secret: "I'm fine" is a mask |
| Chorus | Seen and invited | Her scars, shifts and tears count as part of her picture, not reasons to hide |
| Post-Chorus | Fun, confident | The chant people sing along to and remember, the part that becomes the TikTok sound |
| Verse 2 | Proud and tired | The armor at work, the "articulate" comment, being called too much, the glass-skin promise she bought |
| Pre-Chorus 2 | Relief | "Who holds the one who holds it down?" She finally holds herself |
| Bridge | Release, tears | Letting go of the years and the layers, then pouring back into herself everything she gave away; wash, then feed, the wisdom of the women before her |
| Build | Pride | Her patience, steadiness and faithfulness honored out loud |
| Final Chorus | Triumph, love | She turns to her mother and brings her into the picture too |
| Final Post-Chorus | Belonging | "I'm in it" becomes "we in it": every woman watching is in the picture |

## The sound: three options and my pick

1. **Modern soul anthem (my pick).** Today's R&B production with real gospel power: trap hi-hats and 808 under warm keys, a raw alto lead, and a choir that only arrives when it's earned. It sounds current on a phone speaker and still brings the tears. It fits everything you asked for.
2. **Afro-soul.** Log drums and percussion with an R&B vocal, around 100 BPM. More danceable and great for TikTok, but less room for the tears in the bridge.
3. **Gospel ballad.** The most emotional, with a big choir and Hammond organ. It reads older and churchier, so younger viewers may scroll past.

**Why the pick:** option 1 is the only one that hits all three: emotional enough for the wash scene, current enough for a 25-year-old, and big enough for a 50-year-old to call it her anthem.

## Exact Suno settings

1. **Create → Custom mode.** Use the newest model Suno offers.
2. **Lyrics:** paste the lyrics above exactly, square brackets included.
3. **Style of music:** paste this:

> modern R&B soul anthem with gospel power, female lead vocal, warm raw alto with grit, soaring belts on the chorus, intimate close-mic verses, soft Rhodes and grand piano, deep 808 bass, crisp trap hi-hats, live snare, stacked harmonies and call-and-response, chant post-chorus, choir enters on the bridge and final chorus, key change up on the final chorus, cinematic build, empowering, emotional, uplifting, polished radio mix, 76 BPM

4. **Exclude styles:** male vocals, rap verse, rock, country, EDM, heavy autotune, lo-fi, children's choir
5. **Vocal gender:** Female.
6. **Advanced sliders, if your plan shows them:** Weirdness around 30% and Style influence around 70%. That keeps it on-genre without sounding generic.
7. **Title:** Get In The Picture. Never put an artist's name anywhere in the prompt.
8. **Generate 3 rounds, about 6 versions.** Use a paid plan so you own the commercial rights.

## How to pick the winner

Listen to each version once on your phone speaker and once in the car. Keep the one that passes all of these:

- **Chills on the first chorus.** If you don't feel it, nobody will.
- **She sounds like a grown Black woman singing to herself,** not a pop star performing.
- **Every word is clear,** especially "get in the picture," "I'm fine," "wash it off" and "Mama."
- **The post-chorus is stuck in your head** after one listen.
- **The bridge gets quiet** and the final chorus clearly goes up.
- **Under about 3:45 long,** with nothing mispronounced or garbled.

**Fixing a near-winner:** if one line is weak, use Suno's replace-section tool on just that part instead of starting over. If it ends early, use extend. Then download the stems or the instrumental, so Ms. Faye can speak over the music.

**Send me:** the full vocal version and the instrumental, as a Google Drive link. Send the two runners-up too; I'll check every lyric against the film timing.

## How the film uses it

- **Verse 1** plays over seventeen years of photos and Kenya's glass-skin video, then breaks off on the car.
- **Verse 2** plays over Simone's armor and breaks off at the mirror.
- **The bridge** plays as Ms. Dee washes her daughter's face, and its "then feed me" lines carry us straight into the oils.
- **The first full chorus and post-chorus** play over the thirty nights.
- **The final chorus** plays at the portrait, right after "Never again."
- **"Glow Like Dat"** plays out over the end card.

**Bonus:** release the full song as its own track and as the sound on a 30-second Reels and TikTok cut of the chorus. Every woman who uses the sound for her own "get in the picture" moment advertises YO for free.
