# Forever Pictures: voice plan

**Goal:** decide who speaks, how they sound and how each voice gets made. **Pick:** a real Black voice actress for Ms. Faye, you and Kimmy record your own lines, and AI voices for the short supporting lines. Every voice is matched to one room sound.

## The narrator: Ms. Faye

**Who she is.** A makeup artist in her mid-50s with 25 years in her chair. She has done the faces of Black brides, prom girls, nurses and executives. Southern and Atlanta warm, the auntie everybody trusts with the truth.

**How she sounds.** A low-to-mid alto with a smile in it, unhurried, and close to the mic, as if she's talking just to you. Never a "commercial announcer" voice, never preachy, never deep and serious by default. Humor sits right under the surface.

**The narration style.**
- **Narration is spoken word, in short rhymes.** One or two lines at a time over the music: "She takes care of everybody. Every body but her own." "She don't wear makeup. She wears armor. 'Cause the room she walks in don't forgive."
- **Her dialogue in the chair is plain talk, no rhyme**, so it lands as truth: "Baby, that ain't glow. That's layers."
- **Captions are word by word**, with the key word in gold, the craft from your Batana reference.
- **She carries about 60% of all the audio.** That's why she's the one voice worth paying a real actress for.

## Every other voice

| Who | How much they say | Sound | On camera (lip-sync) or voice-over |
|---|---|---|---|
| **Kenya**, 31, ICU nurse, the bride | About 10 lines | Mid-range, bright, a little tired, Atlanta | Mostly on camera: GRWM video, the car, the chair, "Mama, I asked you to stand in the back once. Never again." |
| **Kenya at 14** | 1 line: "Mama, can you stand in the back?" | Young teen girl, quick and embarrassed | On camera, short |
| **Ms. Dee**, 56, the mother | 3 lines: "Take it without me, baby." "Let me." | Soft, low, worn but loving | On camera |
| **Simone**, 42, bank VP | About 6 lines: "Armor on." "Nobody at work has seen my real skin in fifteen years." "I took something off." | Polished, professional voice that cracks when she's exposed | On camera |
| **Jordan**, 16, the niece | 1 to 2 lines: "Just like Auntie's" | Teen, excited | On camera, short |
| **Amin** (you) | About 3 lines at the tent, plus 1 Amazon line | Your own voice | Voice-over over the tent flashback, so no lip-sync needed |
| **Kimmy** | 2 lines: her mother's esthetics room | Her own voice | Voice-over over the flashback |
| **Ghana elder** | 2 lines: "You want it fast, or you want it right?" "My grandmother washed me with this..." | Older Ghanaian woman, slow and certain | One on camera, one voice-over |
| **Ethiopian farmer** | 1 line: "Tikur azmud." | Ethiopian man, must say the Amharic correctly | On camera, one line |
| **Groomsman** | 1 line: "Bro. Your ankles." | Young Black man, dry comedy | On camera |
| **Small parts** | 1 line each: photographer, office colleague, guest ("Okay... what's the routine?"), Monday colleague | Natural, background | Mostly voice-over or over the shoulder |

**In total:** 14 voices. About 45 spoken lines. About 15 of them are on camera and need lip-sync; everything else plays over the action, which keeps it cheaper and looking more polished.

## How we produce them: three options

1. **All AI voices.** Cheapest, at about 0.6 credits a line (about 30 credits total) and fast. The risk is the narrator: 2 to 3 minutes of AI narration is where people hear "fake," and Ms. Faye carries the whole film.
2. **All real voice actors.** The best sound, but about $800 to $1,500 for 10 or more actors and more time to cast and schedule.
3. **Hybrid (my pick):**
   - **Ms. Faye:** a real Black voice actress, Atlanta-born or a solid Southern read, about $150 to $300 for the full narration and her lines. Cast her through Voices.com, Backstage, or an Atlanta casting contact, or someone from your network who fits.
   - **Amin and Kimmy:** you record yourselves. It's your real voice, it builds trust and it's free. I'll send a line sheet. Record on a phone in a closet full of clothes, three takes per line.
   - **Ghana elder and Ethiopian farmer:** a native speaker for each. They're short lines, about $50 to $100 each, so the accent and the Amharic are authentic and respectful. AI is the backup only if I can verify the pronunciation.
   - **Kenya, Simone, Ms. Dee, the teens and the small parts:** AI voices. I'll audition 3 options per character first, at about 8 credits, and you pick. Every voice must read clearly as Black American and match the character's look. The two teen roles stay AI, so no minors need to be hired.

**Why the hybrid:** your money goes where the ear notices most, the narrator. Your real voices make the founders real, the two origin voices stay authentic, and everything else stays cheap and fast.

## The order we work in

1. **Scratch track, free.** I voice the whole script with a local AI voice so we can lock the timing before anyone records.
2. **Auditions, about 8 credits.** 3 AI options per supporting character, and 2 or 3 actress demos for Ms. Faye.
3. **Record.** The actress, you and Kimmy, and the two native speakers.
4. **Room-match.** Every voice gets the same room sound, levels and light EQ, so the film sounds like one space, not a patchwork.
5. **Lip-sync** only on the roughly 15 on-camera lines, at about 110 credits (about 2.5 credits a second). The budget had 55 for 7 lines. My pick is to keep 8 lines on camera (the emotional ones) to hold near 60, and turn the rest into voice-over with reaction shots.

## What I need from you

- **Ms. Faye:** OK to hire a real actress at about $150 to $300, or do you have someone in mind?
- **Native speakers:** OK to hire one Ghanaian and one Ethiopian speaker at about $50 to $100 each?
- **The founders:** you and Kimmy record your lines once the script is locked.
