# memories-000.zip  (MR BIG BEAUTY project, 2026-11-17)
- PROJECT-INSTRUCTIONS.md : the project's standing rules (asset protocol, production standard, shot logic gate, standing rules)
- project-memory/ : every project memory file Claude keeps across threads (MEMORY.md index + topic files: decisions, feedback, looks, audio engine, history)
- project-notes/ : every .md planning note in the project folder (briefs, scene plans, voice bible, registry, casting scripts, production standard)
