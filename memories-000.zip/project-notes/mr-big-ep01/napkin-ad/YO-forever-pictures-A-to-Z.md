# Forever Pictures: the story from A to Z

A three-and-a-half-minute animated film for YO Skincare, in Pixar-quality 3D. It's told by Ms. Faye, a makeup artist who has done Black brides' faces for 25 years, speaking in short warm rhymes over music. It's made for Black women first, from 18 to 55, plus the people who love them.

The whole film in one sentence: a mother has hidden from every family photo since her daughter asked her to stand in the back, and on the daughter's wedding day the truth about their skin brings her back to the front.

## Scene 1. The photo she keeps walking out of

**What happens.** We're at a wedding. The photographer calls out, "Family of the bride!" Everyone crowds in, except one woman. Ms. Dee, the bride's mother, 56, quietly slides out of the frame and says, "Take it without me, baby."

Then we flash back to June 2009. Ms. Dee is 39 and works as a nursing aide. She has come straight from a double shift to her daughter's eighth-grade graduation, still in her scrubs. It's hot. The hair grease holding her edges down is melting onto her forehead, and her arms shine with cocoa butter. Her daughter Kenya, 14, embarrassed in front of her friends, tugs her sleeve: "Mama, can you stand in the back?" Ms. Dee does. She has stood in the back of every picture since.

**What you feel.** A gut punch. Every mother who has ever been made to feel she embarrassed her child feels it. So does every daughter who once said something careless to her mother and never took it back. You want to see this mother get her picture back, and that question keeps you watching to the end.

**The value.** No product yet, on purpose. This scene earns the right to talk about skin by showing what skin can cost a family: pictures, pride, a mother's place in the frame. It also shows the real life of a working Black woman, double shifts and heat, with no time and no products made for her.

## Scene 2. The daughter who followed her

**What happens.** Today. Kenya is 31 now, an ICU nurse. She followed her mother into healthcare. We see her 12-hour shift in quick flashes: mask on, mask off, sweat at her hairline, a fast look in the bathroom mirror. Ms. Faye says, "She takes care of everybody. Every body but her own."

That night Kenya sets up her ring light and films a "get ready with me" video for her wedding. Eleven bottles line the counter. "Step seven, y'all, seal it in." The comments pour in: "Glass skin goals!" She has spent about $600 on this routine.

Then the low point. She's alone in her car in the hospital garage after a shift. The mask has left lines in her cheeks, and her foundation is gone. She wipes it off her phone screen and whispers, "I did everything they said."

**What you feel.** Recognition, then sympathy. Any woman who works on her feet, sweats through her day, and still tries to look put together knows that car moment. The irony stings: the girl who was ashamed of her mother's shine is now paying good money to make the same shine on purpose.

**The value.** It names the modern problem without blaming anyone. The internet sells more steps, more bottles, more layers, and they still don't hold up to a real Black woman's real day. The viewer starts to wonder whether she's doing too much too.

## Scene 3. Ms. Faye's chair: three women, one problem

**What happens.** The wedding morning. Ms. Faye works three women in a row.

First Kenya. Her foundation slides right off. "But my skin's healthy, look at the glow!" Ms. Faye, kind but firm: "Baby, that ain't glow. That's layers." We see it up close: eleven thin films stacked on the skin, the camera flash bouncing off them.

Next Simone, 42, the maid of honor, a bank vice president. "Don't even start. I wear a full face ten hours a day. It took me seven tries to find my shade, and it's gone by two o'clock." Ms. Faye asks, "And at night?" Simone goes quiet. "I sleep in it more than I'd admit."

Then Jordan, 19, the cousin, a college sophomore with perfect laid edges and glazed TikTok skin. Ms. Faye runs a finger along her hairline and holds it up to the light. It's edge gel. "What you put on your hair don't stay on your hair."

The groom, Marcus, walks by stacking on beard oil. His groomsman looks down. "Bro. Your ankles." They're ashy.

Then Ms. Faye says the line of the film to Kenya, holding up an old photo of her mother: "Your mama called it grease. Your phone calls it glass. Baby, it's the same layers."

**What you feel.** Laughter and being caught at once: "that's me." It's the first real laugh in the film, and it lets the audience breathe. Under the laugh is a click of understanding. Mother and daughter were doing the same thing, a generation apart.

**The value.** This is where the truth comes out. The problem isn't her skin; it's what's piled on top of it, from makeup, hair products and trendy routines. And it's the same for every age: the professional woman, the college girl, the nurse, even the man. Every viewer finds herself in that chair.

## Scene 4. It ain't your fault

**What happens.** Kenya pushes back, hurt: "So my mama was wrong, and I'm wrong too?" Ms. Faye puts her brush down and answers softly:

"No, baby. Nobody made it for us. Not for our skin, not for our shifts, not for our sweat. So our mamas made do. Grease was making do. And them videos? Most of them never even asked what kind of skin you got."

A quiet line appears on screen: 84% of the top viral glass-skin videos didn't account for skin type.

Then Ms. Faye says, "You ain't doing too little. You doing too much of the wrong thing."

**What you feel.** Relief, like a weight coming off. Shame turns into understanding. Mothers watching forgive themselves, daughters forgive their mothers, and nobody is made the villain.

**The value.** This is the emotional key to the whole film. It says out loud what Black women have lived: the beauty industry didn't make products for them, so they improvised. That opens the door for a brand that was built for them.

## Scene 5. Who finally made it for us

**What happens.** Ms. Faye sets a bottle of YO Cleanse on the counter. Kenya scoffs. "Black soap? Mama's bars dried us out." Ms. Faye answers, "Not all black soap is the same. I asked the people who make this one."

We flash back to the YO tent at a festival, where Ms. Faye met the founders. Amin tells her, "Fifteen years in this business, I watched them sell us more steps, smaller bottles, and labels nobody reads. So I went and got it myself." Kimmy adds, "I grew up in my mother's esthetics room. Every woman who sat in her chair, she washed first. Then she fed the skin. That's how we built this."

**What you feel.** Trust, and some pride. These are insiders, people who look like you and know the business and the skin, not a big company guessing.

**The value.** It answers "nobody made it for us" with "these two did." YO is Black-owned and family-founded, built on fifteen years in the industry and a master esthetician's way of caring for skin: wash first, then feed it.

## Scene 6. Back to the source

**What happens.** The film travels.

First Ghana, in a village soap yard. Plantain skins and cocoa pods burn slowly down to ash while an elder woman stirs a big iron pot for hours. She presses a warm ball of black soap into Amin's hand and asks, "You want it fast, or you want it right?" We cut back to Kenya's eleven bottles. Then the elder gently washes her granddaughter's face: "My grandmother washed me with this. I washed her mother."

Then Ethiopia, misty fields high in the mountains. A farmer pours tiny black seeds into Amin's palm: "Tikur azmud." Black seed. People have treasured it for thousands of years, and it was even found in King Tut's tomb. We watch it pressed into a slow stream of dark gold oil. It's rich in antioxidants, so skin feels smooth and looks nourished, and it's in all three YO bottles.

Back in the chair, Ms. Faye counts off on her fingers the three things that make YO's black soap different. Each one gets its own close-up:
- Sea moss, a mineral-rich cushion of moisture, so you rinse soft, not tight.
- Black seed, so skin feels smooth and nourished even while you wash.
- Jojoba. "It ain't even really an oil, baby. It's a liquid wax, close to what your own skin makes." It gives the lather slip and rinses clean.

Kenya washes a patch on her hand, waiting for the tight, squeaky feeling she grew up with. It never comes. "Huh."

**What you feel.** Wonder and respect, the bigness of where this comes from. Then a small, satisfying surprise when the soap doesn't dry her out.

**The value.** Real origin and real quality. The soap comes from Ghana, the black seed from Ethiopia, and three ingredients, sea moss, black seed and jojoba, set this black soap apart from the bars on the shelf. Its biggest objection, "black soap dries me out," is answered right on Kenya's hand.

## Scene 7. The wash: the heart of the film

**What happens.** Ms. Dee has been standing in the doorway listening the whole time. She steps forward and holds out her hand for the bottle. "Let me." On her wedding morning, the mother washes her grown daughter's face. Kenya closes her eyes. The film cuts back and forth between Ms. Dee's careful hands and the elder in Ghana washing her granddaughter, in the same warm light with the same lather. Ms. Faye says softly, "Same soap. Other side of the ocean." The music almost disappears; we hear only water and breathing.

**What you feel.** The first big emotional peak, a lump in your throat. The mother who was pushed to the back is now the one caring for her daughter. Nobody has said "I'm sorry" yet, but the healing has started.

**The value.** This scene is what YO means: Your Original Skincare, a ritual handed down from mothers and grandmothers, connecting Black women here to their roots. It's skincare as love, not as another chore.

## Scene 8. Head to toe

**What happens.** The pace picks up into a quick, rhythmic montage.

Ms. Faye opens the Supa Glo Facial Elixir: ten oils, two drops. Each oil flashes on screen: rosehip, turmeric, argan, almond, calendula, grapeseed, jojoba, black seed, and one most people have never heard of. Copaiba is a golden resin that runs from a tall tree in the Amazon rainforest. Amin says, "I didn't fly to the Amazon for this one. I studied it till I knew exactly why it belonged." Ms. Faye smiles: "Bet you never heard of it. That's the point." On screen: helps fade the look of dark marks.

Two drops sink into Kenya's skin, while beside them a slick of glass-skin product just sits on top. "Glass sits on top. This absorbs." Ms. Faye's brush glides, and this time the makeup holds. "Now THAT'S a canvas."

Then the Supa Glo Body Oil. Kenya smooths it over her shoulders and arms, and her white satin wedding gown slides on. She touches the fabric. "Not a mark on that dress." Marcus uses the same oil on his ashy ankles.

Finally everything comes home. The soap from Ghana, the black seed from Ethiopia and the copaiba from the Amazon arrive at a clean workroom in America, where they're mixed, filled and bottled. Ms. Faye sums it up: "Twenty plant ingredients. Three bottles. Face to feet. Thirty-seven ninety-seven."

**What you feel.** Excitement and confidence. The pace feels like a payoff, and the white dress moment is real tension and relief, because every woman knows the fear of oil on a white outfit.

**The value.** The full product story in one burst:
- a complete routine for face and body, head to toe, not face-only;
- totally plant-based, 20 plant ingredients;
- a rare ingredient, copaiba, that most brands for our skin don't use;
- lightweight oils that absorb, so makeup holds and clothes stay clean;
- bottled in the USA;
- all three full-size bottles for $37.97.

## Scene 9. Thirty nights

**What happens.** We see the next thirty nights, one moment for each person.
- Kenya comes home from a 12-hour shift, washes once, presses in two drops, and she's done. She posts a new video with no ring light: "Y'all. I been doing too much."
- Simone takes the day off her face every night now: "Haven't slept in my face in a month."
- Jordan washes along her hairline every night after laying her edges.
- Then the moment that matters most. Ms. Dee sits alone at her vanity and slides her old jars into a box. She washes, presses in two drops, and looks at herself in the mirror longer than she has in years. Ms. Faye says, "Her mama took the longest to believe. Thirty nights. Then she did."

**What you feel.** Warm hope. Ms. Dee's private moment hits hardest. She isn't changing for anyone else; she's choosing herself again.

**The value.** It shows the routine fits real life: simple, quick, after a long shift, for every age. It also earns the ending, because Ms. Dee steps into the next photo by her own choice, not only because her daughter pulled her.

## Scene 10. Get in the picture

**What happens.** We're back at the family portrait. "Family of the bride!" Out of habit, Ms. Dee starts to slip out of the frame again, and this time Kenya catches her hand. "Mama, I asked you to stand in the back once. Never again." She pulls her mother front and center. The flash goes off, and they both glow, with no glare. A guest leans over and asks, "Okay... what's the routine?"

Ms. Faye turns to the camera: "It ain't your skin. It ain't your fault. It's what you stacked on it. Wash it off. Then get in the picture."

The screen goes black and these words appear: For every woman who worked a double and still showed up for the picture.

Then a real photo of the real founders, Amin and Kimmy, at the real YO tent. The real founders. The real soap. Last comes the end card: the YO logo, Your Original Skincare, the Complete Routine for $37.97, five-star Google reviews, mixed, filled and bottled in the USA, and available in 45+ beauty supply stores. Ms. Faye closes: "Online, or at your beauty supply." Kimmy's song "Glow Like Dat" plays out on "Keep yourself beautiful, don't gotta go broke for that."

**What you feel.** The second big peak, tears and joy together. The wound from the first scene is healed: the daughter brings her mother back into the picture. Then the dedication makes every working woman watching feel seen.

**The value.** It closes the loop. Skincare isn't vanity here; it's about being present in your own family's memories. Seeing the real founders makes it real and trustworthy, and the end card says exactly what to buy, what it costs and where to get it.

## The feeling, start to finish

1. A gut punch at the start.
2. Recognition in the car.
3. Laughter in the chair.
4. Relief at "it ain't your fault."
5. Wonder at the source.
6. Tears at the wash.
7. Excitement in the head-to-toe montage.
8. Hope at the mirror.
9. Tears and joy at the final portrait.

There are two big emotional peaks, the wash and the portrait, with laughs placed in between so the audience can breathe.

## The value, start to finish

By the end, a viewer knows:
- the problem was never her skin, it was the layers;
- it isn't her fault, because nobody made products for her;
- YO was made for her by Black founders who know skin;
- it comes from Ghana and Ethiopia, with a rare Amazon oil, and is bottled in America;
- three ingredients make this black soap different: sea moss, black seed and jojoba;
- it's totally plant-based and covers face to feet;
- it's light, absorbs, holds makeup and won't mark your clothes;
- it costs $37.97, online or at her beauty supply.
