# Forever Pictures v8: the timed cut

**Goal:** lock the whole film to the real song, 35M2, so every Ms. Faye line, every sung section and every shot has a time on the clock, and we know the true runtime and the true credit cost. **Done:** the clock below, a rough audio cut of the whole film you can listen to now, the tightened Ms. Faye lines, the shot list and the budget.

## The honest runtime

- **The real song changes the math.** The film uses 3:26 of singing, and Ms. Faye never talks over a sung line. Her full 853-word script on top of that runs about **9:30**. My earlier 5:00 estimate was wrong.
- **Tightened (my pick, on the decision card), it measures 7:19.** Every value point stays: the same story, the same ingredients and origins, the founders, the price and the reviews, in 592 of her words instead of 853. That's about the length of your 7:24 "Dad Weight" reference.
- **A real narrator will run a little longer than the placeholder voice,** so plan on **7:15 to 7:45**.
- **To get to about 6:30** we'd have to drop something whole, such as the "Every stage" scene and the final "Real glow, not glass" chant. I don't recommend it: "Every stage" is how every age group sees herself.
- **The paid ads** are the 60- and 30-second cutdowns. The full film is the YouTube hero and the link everything points to.

## Listen first

The rough audio cut is at the top of the [Review Room](https://claude.ai/artifact/DdHZjwY3HodA6qzJWJ3eBj): the real 35M2 song and instrumental, with every spoken line at real timing. The voices are free placeholder voices, only for timing. Your cast replaces them.

## The film on one clock

| Scene | Clock | What plays | What you see |
|---|---|---|---|
| 1. The picture she keeps walking out of | 0:00 to 0:25 | spoken | A wedding. Everyone crowds in for the family photo except the bride's mother, Ms. Dee, 56, who slides out of frame. Flashback to June 2009: Ms. Dee runs from a double shift to Kenya's eighth-grade graduation, still in scrubs. Kenya, 14, embarrassed in front of her friends, asks her to stand in the back. |
| 2. The back row | 0:25 to 1:17 | sung, Verse 1 | Seventeen years of family photos, Ms. Dee always at the edge. Kenya grows up, becomes an ICU nurse, films an eleven-bottle glass-skin routine; her niece Jordan copies it. The song climbs toward the chorus and breaks off on Kenya alone in her car after a twelve-hour shift. |
| 3. The armor | 1:17 to 2:02 | sung, Verse 2 | Simone, 42, a bank vice president, at 5 a.m.: face beat, silk press, edge control, like she's suiting up. Kenya under her ring light with a cart full of serums. The song breaks off on Simone's face in the office bathroom mirror. |
| 4. The chair | 2:02 to 2:28 | spoken | Ms. Faye's makeup chair, the week before the wedding. She lifts Kenya's edges, then a 3D cross-section of the hairline shows edge product settling onto the skin. She holds up the 2009 photo. |
| 5. Every stage | 2:28 to 2:52 | spoken | A fast portrait montage: the prom girl, the new mama, the nurse off nights, the boss, the grandmama with her mama's jar, then a phone feed of glass-skin videos. |
| 6. The source | 2:52 to 3:47 | spoken | The founders, then Ghana: an elder soap maker. Ethiopia: a farmer pours black seed into his palm. 3D macros of sea moss, black seed and jojoba in the lather. Kenya tries the soap. |
| 7. Wash it off | 3:47 to 4:23 | sung, Bridge | Ms. Dee takes the washcloth from Ms. Faye and washes her grown daughter's face. Kenya closes her eyes. Cut to the elder in Ghana washing her granddaughter's face with the same soap. |
| 8. Feed it | 4:23 to 5:17 | spoken, on the beat | The beat kicks in. One oil per cut, then 3D shots of two drops sinking in, foundation going on smooth, the body oil on the groom's ankles, Kenya in her dress, the three bottles. |
| 9. Thirty nights | 5:17 to 5:48 | sung, first full chorus | The chorus finally lands. Kenya posts a new video with no ring light; Simone at work in light makeup; Jordan washing her edges at the sink; Marcus hunting for his body oil. Ms. Dee smiles at herself in the mirror. |
| 10. Get in the picture | 5:48 to 6:53 | sung, Build and Final Chorus | The wedding portrait. Ms. Dee starts to slip out; Kenya catches her hand. The music drops out for Kenya's line, then front and center, flash, and the final chorus. Ms. Faye to camera. |
| 11. The exit | 6:53 to 7:19 | brand song | Glow Like Dat over a real photo of Amin and Kimmy at the YO tent, then the end card: YO logo, Your Original Skincare, the Complete Routine at $37.97, YOSKINCARE.COM. |

## Every line, by the clock

Song times are positions inside 35M2. "Instrumental" means the vocal-free stem.

### 1. The picture she keeps walking out of · 0:00 to 0:25 · spoken

A wedding. Everyone crowds in for the family photo except the bride's mother, Ms. Dee, 56, who slides out of frame. Flashback to June 2009: Ms. Dee runs from a double shift to Kenya's eighth-grade graduation, still in scrubs. Kenya, 14, embarrassed in front of her friends, asks her to stand in the back.

| Clock | Who | What you hear |
|---|---|---|
| 0:00 | Photographer | "Family of the bride! Everybody in!" |
| 0:02 | Ms. Dee (on camera) | "Take it without me, baby." |
| 0:05 | Ms. Faye | "Every family's got a picture. Some of us been hiding from ours for years." |
| 0:09 | Ms. Faye | "Seventeen years out of frame. Here's where it started." |
| 0:13 | Ms. Faye | "June, two thousand nine. Off a double, still in scrubs, the grease on her edges giving up in the heat." |
| 0:19 | Kenya at 14 (on camera) | "Mama... can you stand in the back?" |
| 0:21 | Ms. Faye | "Kids say things quick. Mamas carry them long." |

### 2. The back row · 0:25 to 1:17 · sung, Verse 1

Seventeen years of family photos, Ms. Dee always at the edge. Kenya grows up, becomes an ICU nurse, films an eleven-bottle glass-skin routine; her niece Jordan copies it. The song climbs toward the chorus and breaks off on Kenya alone in her car after a twelve-hour shift.

| Clock | Who | What you hear |
|---|---|---|
| 0:25 | Song (instrumental) | *35M2 0:00 to 0:12: Instrumental intro, looped to fit Ms. Faye* |
| 0:25 | Ms. Faye | "Now that baby's an ICU nurse. Takes care of every body but her own." |
| 0:30 | Ms. Faye | "Eleven bottles. Six hundred dollars. Chasing the shine she was ashamed of at fourteen." |
| 0:37 | Song | *35M2 0:12 to 0:48: Verse 1 and Pre-Chorus, sung. Breaks off on 'walk in the room'* |
| 1:13 | Ms. Faye | "She did everything they said. Nobody said what was underneath." |

### 3. The armor · 1:17 to 2:02 · sung, Verse 2

Simone, 42, a bank vice president, at 5 a.m.: face beat, silk press, edge control, like she's suiting up. Kenya under her ring light with a cart full of serums. The song breaks off on Simone's face in the office bathroom mirror.

| Clock | Who | What you hear |
|---|---|---|
| 1:17 | Song | *35M2 1:15 to 1:52: Verse 2 and Pre-Chorus 2, sung: face beat, code-switch, ring light, light bill, everybody's weight* |
| 1:54 | Ms. Faye | "She don't wear makeup. She wears armor. 'Cause the room don't forgive." |
| 1:58 | Ms. Faye | "Cover it. Layer it. Sleep in it. Do it again." |

### 4. The chair · 2:02 to 2:28 · spoken

Ms. Faye's makeup chair, the week before the wedding. She lifts Kenya's edges, then a 3D cross-section of the hairline shows edge product settling onto the skin. She holds up the 2009 photo.

| Clock | Who | What you hear |
|---|---|---|
| 2:02 | Ms. Faye | "Kenya sat down proud. 'Look at my glow.' Baby, that ain't glow. That's buildup." |
| 2:07 | Ms. Faye | "Little bumps at the hairline. 'How long?' 'Since nursing school.'" |
| 2:11 | Ms. Faye | "What you put on your hair don't stay on your hair." |
| 2:14 | Ms. Faye | "Simone ain't let nobody at work see her real skin in fifteen years." |
| 2:19 | Ms. Faye | "I told her, it's beautiful. It's just tired of carrying all that." |
| 2:23 | Ms. Faye (on camera) | "Your mama called it grease. Your phone calls it glass. Baby, it's the same buildup." |

### 5. Every stage · 2:28 to 2:52 · spoken

A fast portrait montage: the prom girl, the new mama, the nurse off nights, the boss, the grandmama with her mama's jar, then a phone feed of glass-skin videos.

| Clock | Who | What you hear |
|---|---|---|
| 2:28 | Ms. Faye | "Twenty-five years in this chair. The prom girl. The new mama. The nurse off nights. The boss. The grandmama with her mama's jar. Same story." |
| 2:38 | Ms. Faye | "Nobody made it for our skin, our shifts, our sweat. So we piled it on. Your mama wasn't wrong. Grease was making do." |
| 2:45 | Ms. Faye | "And them videos never asked what skin you got. You ain't doing too little. You doing too much of the wrong thing." |

### 6. The source · 2:52 to 3:47 · spoken

The founders, then Ghana: an elder soap maker. Ethiopia: a farmer pours black seed into his palm. 3D macros of sea moss, black seed and jojoba in the lather. Kenya tries the soap.

| Clock | Who | What you hear |
|---|---|---|
| 2:52 | Ms. Faye | "Not all black soap is the same. And washing's only half. Wash it right, then feed it right. One without the other don't work." |
| 3:00 | Ms. Faye | "Him: fifteen years in this business. Her: raised in her mama's esthetics room, where every woman got washed first, then fed. So he went to the source." |
| 3:09 | Ghana elder (on camera) | "You want it fast, or you want it right?" |
| 3:11 | Ethiopian farmer (on camera) | "T'ikur azmud." |
| 3:13 | Ms. Faye | "Black seed. Found in King Tut's tomb. Rich in antioxidants. In every YO bottle." |
| 3:19 | Ms. Faye | "Plain black soap dries you out. This one's made in Ghana, with three things plain don't have. Sea moss, so you rinse soft, not tight. Black seed, to nourish while you wash. And jojoba, a liquid wax close to what your own skin makes." |
| 3:33 | Ms. Faye | "It helps lift the buildup: edge control, sweat, yesterday's makeup. Cleanses, exfoliates, tones. Face and body. Never stripped." |
| 3:42 | Ms. Faye | "Kenya rubbed her hands. 'Huh. It don't feel tight.' Then, 'Is that peppermint?'" |

### 7. Wash it off · 3:47 to 4:23 · sung, Bridge

Ms. Dee takes the washcloth from Ms. Faye and washes her grown daughter's face. Kenya closes her eyes. Cut to the elder in Ghana washing her granddaughter's face with the same soap.

| Clock | Who | What you hear |
|---|---|---|
| 3:47 | Ms. Dee (voice-over) | "Let me." |
| 3:49 | Song | *35M2 2:20 to 2:52: Bridge, sung: wash it off, all that buildup, then feed me* |
| 4:21 | Ms. Faye | "Same soap. Other side of the ocean." |

### 8. Feed it · 4:23 to 5:17 · spoken, on the beat

The beat kicks in. One oil per cut, then 3D shots of two drops sinking in, foundation going on smooth, the body oil on the groom's ankles, Kenya in her dress, the three bottles.

| Clock | Who | What you hear |
|---|---|---|
| 4:23 | Ms. Faye | "Now we feed it. Ten oils. Two drops." |
| 4:27 | Ms. Faye | "Rosehip, smooth under foundation. Turmeric, for that bright. Argan, almond, vitamin E, for the mama on no sleep. Calendula, after a hot shift. Grapeseed, light under a mask. Jojoba and black seed, the family. And copaiba." |
| 4:42 | Ms. Faye | "Co-pai-what? Exactly. From South America. He studied it till he knew why it belonged." |
| 4:48 | Ms. Faye | "Glass sits on top. This sinks in. The wash clears the way. The oils feed it and seal the deal." |
| 4:54 | Ms. Faye | "Now that's a canvas." |
| 4:56 | Ms. Faye | "Then the body. Seven oils, face to feet. Absorbs fast. Even the groom's ankles." |
| 5:02 | Ms. Faye | "Not a mark on that dress." |
| 5:04 | Ms. Faye | "Ghana in the wash. Ethiopia in every bottle. Mixed and bottled right here at home. Twenty plant ingredients. Three bottles. Thirty-seven ninety-seven. Five stars. One review just said, 'Black gold.'" |

### 9. Thirty nights · 5:17 to 5:48 · sung, first full chorus

The chorus finally lands. Kenya posts a new video with no ring light; Simone at work in light makeup; Jordan washing her edges at the sink; Marcus hunting for his body oil. Ms. Dee smiles at herself in the mirror.

| Clock | Who | What you hear |
|---|---|---|
| 5:17 | Song (instrumental) | *35M2 0:44 to 0:48: Pre-chorus tail, instrumental* |
| 5:18 | Ms. Faye | "Thirty nights. Wash, then feed." |
| 5:21 | Song | *35M2 0:48 to 1:15: Chorus 1 and Post-Chorus, sung, picking up exactly where scene 2 broke off* |
| 5:40 | Ms. Faye | "Her mama took the longest to believe. Then she did." |

### 10. Get in the picture · 5:48 to 6:53 · sung, Build and Final Chorus

The wedding portrait. Ms. Dee starts to slip out; Kenya catches her hand. The music drops out for Kenya's line, then front and center, flash, and the final chorus. Ms. Faye to camera.

| Clock | Who | What you hear |
|---|---|---|
| 5:48 | Photographer | "Family of the bride!" |
| 5:50 | Song | *35M2 2:52 to 3:06: Build, sung: patient, steady, showin' up for me* |
| 6:04 | Kenya (on camera) | "Mama, I asked you to stand in the back once. Never again." |
| 6:09 | Song | *35M2 3:06 to 3:40: Final Chorus and Post-Chorus, sung: Get in the picture, Mama* |
| 6:43 | Song (instrumental) | *35M2 3:40 to 3:50: Outro instrumental under Ms. Faye* |
| 6:43 | Ms. Faye (on camera) | "It ain't your skin. It ain't your fault. It's what you stacked on it. Wash it off. Feed it right. Then get in the picture." |

### 11. The exit · 6:53 to 7:19 · brand song

Glow Like Dat over a real photo of Amin and Kimmy at the YO tent, then the end card: YO logo, Your Original Skincare, the Complete Routine at $37.97, YOSKINCARE.COM.

| Clock | Who | What you hear |
|---|---|---|
| 6:53 | Brand song | *Glow Like Dat: 'Keep yourself beautiful, don't gotta go broke for that'* |
| 7:02 | Ms. Faye | "YO. Your Original Skincare. Black-owned. Family-founded. The Complete Routine, thirty-seven ninety-seven." |
| 7:09 | Kimmy (over real photo) | "Wash first. Then feed it. That's how my mother did it." |
| 7:13 | Amin (over real photo) | "That's how we built YO." |
| 7:15 | Ms. Faye | "Online, or at your beauty supply." |


## What the tightening cut, and what it kept

**Kept, every one:**
- The cause (buildup, hair products on the skin, glass skin from the phone, "too much of the wrong thing").
- Wash and feed as equals ("One without the other don't work", "The wash clears the way. The oils feed it and seal the deal").
- The soap's three differences and what each one does (sea moss, black seed, jojoba).
- Cleanses, exfoliates, tones, never stripped, face and body.
- Ten oils, each tied to a woman in the story, and copaiba from South America.
- Seven body oils, face to feet, absorbs fast.
- Ghana, Ethiopia, mixed and bottled at home, twenty plant ingredients.
- Amin's fifteen years and Kimmy's mother's esthetics room.
- $37.97, five stars and "Black gold".
- Black-owned, family-founded, online or at your beauty supply.

**Cut, words only:**
- Repeated phrasing.
- "gone by two" in Simone's story.
- Folded together: the two "every stage" lines; the source lines F23 and F24 into one; and "Nobody made it for us" into F17.

**Changed for casting:** Ms. Faye's lines are now the ones in this doc. When you confirm the pick, I'll update her [casting script](https://claude.ai/artifact/78aS81wy8Z7CjKBtq49mmr) to match, so candidates read the final words.

## Shot list and credits

**How I kept the cost down:**
- Every photo, portrait, oil and product moment is a still image, about 2 credits each, moved locally for free.
- Only moments with real action are video clips: about 12 credits each for 5 seconds.
- The big emotional moments get the better video model: about 25 credits each.
- The seven on-camera lines are lip-synced at about 7 to 9 credits each.

| Scene | Shots | Credits |
|---|---|---|
| 1. The picture she keeps walking out of | 2 hero moving shots (crowd, Ms. Dee slipping out), 2 flashback clips, 2 lip-sync (D1, K14) | 88 |
| 2. The back row | 10 photo stills with free local motion, 3 clips (Kenya's routine, Jordan copying), 1 hero shot (car) | 81 |
| 3. The armor | 5 clips (Simone suiting up, Kenya's ring light and cart), 1 hero shot (mirror) | 85 |
| 4. The chair | 1 hero shot (the chair), 1 clip (edges), 2 hairline cross-section stills, 1 lip-sync (F15) | 50 |
| 5. Every stage | 7 portrait stills with free local motion | 14 |
| 6. The source | 5 clips (founders, Ghana, Ethiopia, Kenya's hands), 4 ingredient macro stills, 2 lip-sync (elder, farmer) | 98 |
| 7. Wash it off | 2 hero shots (the wash), 2 clips (Ghana granddaughter, Kenya's eyes) | 74 |
| 8. Feed it | 11 oil and product stills with free local motion, 4 clips (two drops, foundation, ankles), 1 hero shot (the dress) | 95 |
| 9. Thirty nights | 4 clips (Kenya's new video, Simone, Jordan, Marcus), 1 hero shot (Ms. Dee's smile) | 73 |
| 10. Get in the picture | 2 hero shots (catching her hand, the flash), 3 clips (final chorus), 2 lip-sync (K13, F38) | 104 |
| 11. The exit | Real founders photo and end card, built locally | 0 |
| Phase 1 masters | 10 character and location master images | 20 |
| **Subtotal** | | **782** |
| Retries (15%) | | 117 |
| **Total** | | **about 900** |

- **Balance now:** 175.46 credits.
- **Phase 1** (the 10 master images, about 20 credits) fits now and is waiting on your GO.
- **The rest** needs about 725 more credits before video starts.

## Next

1. Tap your pick on the runtime card.
2. GO on phase 1 masters (about 20 credits).
3. I update Ms. Faye's casting script to the final lines.
4. Cast recordings replace the placeholder voices in this same timed cut, so we can hear the real film before spending video credits.
5. Add credits for video (about 725).
