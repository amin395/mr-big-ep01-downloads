# Get In The Picture (35M2): section map

Taken from the separated vocal. Times are approximate, to about ±1 s.

| Section | Start | End | Film use (v7) |
|---|---|---|---|
| Intro (hum, "Get in, sis") | 0:00 | 0:12 | Wedding open |
| Verse 1 | 0:12 | 0:34 | 17 years of photos, Kenya's glass-skin video |
| Pre-Chorus 1 ("girl, I'm good") | 0:34 | 0:48 | Breaks off on the car |
| Chorus 1 | 0:48 | 1:07 | Held back. The first full chorus plays over the thirty nights |
| Post-Chorus 1 ("I'm in it") | 1:07 | 1:15 | |
| Verse 2 (face beat, code-switch, ring light, light bill) | 1:15 | 1:43 | Simone's armor |
| Pre-Chorus 2 ("everybody's weight") | 1:43 | 1:52 | Breaks off at the mirror |
| Chorus 2 | 1:52 | 2:12 | Thirty nights |
| Post-Chorus 2 | 2:12 | 2:20 | |
| Bridge ("wash it off... then feed me") | 2:20 | 2:52 | Ms. Dee washes Kenya's face, into the oils |
| Build ("patient, steady, faithful") | 2:52 | 3:06 | Lead-in to the portrait |
| Final Chorus ("Get in the picture, Mama") | 3:06 | 3:28 | The portrait, right after "Never again" |
| Final Post-Chorus ("Real glow, not glass") | 3:28 | 3:40 | Founders, real photo |
| Outro ("Get in the picture... get in") | 3:40 | 3:50 | Then "Glow Like Dat" over the end card |

Files in this folder:
- 35M2-get-in-the-picture.wav (master)
- 35M2-INSTRUMENTAL.wav
- 35M2-VOCALS.wav
- MP3 versions of all three
