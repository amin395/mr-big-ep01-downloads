# Your edits, read back (Nov 13)

Nothing has been spent. Nothing changes until you confirm this list.
Page labels are the ones on the Phase 1 Looks page: https://claude.ai/artifact/26NVBmAzXcCV3zJ2d2qwSJ#signoff

## The standard for every woman (applies to Kenya, Ms. Dee, Zoe, Simone)

- **BEFORE skin** = the Ms. Dee **DRIVE "before, shiny but dull"** sheet. That is the reference for everyone's Before: a flat sheen sitting on top, tired and grayish underneath, no light from within. Add a tad more color than that sheet.
- **Glow must build step by step**, visibly different at each stage:
  1. Before: dull
  2. Night 1 (first wash)
  3. Robe Day 14: noticeably better
  4. Robe Day 30: radiant
  5. Wedding: the MOST radiant of all
- **Under-eye shadows fade gradually** (everyone who has them): visible on Day 1 and Night 1, fading by Day 14, completely gone on Day 30 and the wedding. No dark marks on the cheeks of any Before face, so nothing on screen claims a spot was removed (your pick, Nov 13).
- **Brighter, never lighter:** by the wedding, skin is more luminous (same brown with the lights on), same complexion.
- **Radiant means** bright, clear, even, "doughy" glow from within. It does not mean wet shine, and it does not change anyone's complexion (no lightening).

## Changes, look by look

1. **Kenya, WED Day 30** (wedding sheet; shots 1-3, 13, 95-100, 102)
   - Remove the dark marks under her eyes in the close-up.
   - Her forehead and lower face (lips, lower cheeks, chin, around the mouth) read darker than on Day 14. Even them out so the whole face glows.
   - It must look at least as good as Robe Day 30 (you like Robe Day 30 better right now), and then a step above it, because this is her most radiant moment.
2. **Kenya, Before looks** (Scrubs Before, Home Before): match the Dee DRIVE "shiny but dull" standard.
3. **Kenya, hair** (all adult looks): natural hair with styled baby hairs and laid edges. Not slicked straight back, and not a split part.
4. **Ms. Dee, full progression** (Home Before → Night 1 wash → Robe D14 → Robe D30 → Wedding): right now they look too alike. Before = the DRIVE sheet. Each later stage clearly brighter, with the Wedding the most radiant.
5. **Zoe, WED Day 30**: bump up the glow to match the new radiance level. Glowing, doughy skin, not shiny.
6. **Simone, Day 30 / after looks**: the transformation is good. Make her brighter and healthier-looking.
7. **Marcus, WED**: pump up his wedding-day glow.
8. **Marcus, ashy looks** (Lounge and Shower): make the ash subtler. Right now it reads as white powder. It should read as light everyday dryness on his arms, legs and feet.
9. **Kenya at 22** (shot 30): keep her as she is (natural hair, younger). Add the start of the problem: edge control and gel at her hairline running onto her face, with the little bumps just beginning. (On screen only; no claims spoken about it.)
10. **Ms. Dee at 10** (shot 7): change her hair to an 80s style. Hair in 4-5 sections with barrettes, bows and twisty-tail ends. No braids.
11. **Amin backstory, 3D** (shots 44-46, 50 and onward: expo, war room, map, Africa trips): keep the LOCKED face from the approved sheet (job 82) exactly. Change only the clothes: olive button-up, jeans, and for the expo a headset. Make the gray streak a little more subtle.
12. **Amin, tent ending, realistic** (shots 104-105): good, but make the gray streak subtler.
13. **Kimmy, real / realistic** (shots 104-105): good, but the side (three-quarter) view looks a tad thicker than she is. Slim that view to match her full-body photo.

## Added Nov 13 (your 11:34 PM note): done in the production book, no credits

- **Rested + even-looking** is now written into every Day 14, Day 30 and wedding prompt: Day 14 "more even-looking, more rested", Day 30 "even-looking, well-rested, doughy", wedding "the most radiant she has ever looked", same complexion.
- **Other people noticing** (no new shots, no new lines):
  - Shot 93: a board member looks up at bare-faced Simone with an admiring smile and nod.
  - Shot 97: as Ms. Dee steps into her spot, an auntie catches her glow, hand to her chest, and nudges the cousin beside her.
  - Shot 101: under Zoe's comment, three more stack up: "Y'ALL ARE GLOWING", "Ms. Dee!!!", "ok what are you using??" (built in the edit).
- Already in the story: Simone stops touching up (93), Kenya's no-filter post (101), real Google reviews on screen.

## Approved as is (no changes)

Ms. Faye · Groomsmen (you like the guy with the box cut and textured hair) · Wedding family · Kenya at 14 · Ms. Dee at 39 · Grandma 1980 · Kimmy backstory 3D (shots 47, 50) · Kimmy at 12 · Kimmy at 16 · Ghana elder · Ethiopian farmer

## What I will NOT do

- Regenerate Amin's face.
- Touch any approved look.
- Spend a credit before you approve a written plan with a total.

## After you confirm

I'll send one plan that sorts each change into **free** (color/glow grading and retouch done here, no credits) or **needs a render** (hair changes, Kenya at 22's hairline, possibly Amin's shirt). It will have an exact total, and nothing runs until you say GO.

Correction for the record: Phase 1 has spent about 165.5 credits so far, not the 125 I told you earlier (balance 2,835.39 of 3,000.89).
