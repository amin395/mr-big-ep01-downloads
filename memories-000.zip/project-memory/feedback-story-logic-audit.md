---
name: feedback-story-logic-audit
description: Amin 11-16 12:17Z: shot 5 staging contradicted its line; every shot must be checked line -> blocking -> previous shot BEFORE any render; never rewrite a prompt to fit a frame
metadata:
  type: feedback
---
Amin 11-16 12:17Z, angry, STOP SPENDING: shot 5 Kenya says "Mama, can you stand in the back?" while Mama is already on the stage. "Everything is supposed to be put together based upon sequence, order, rationale."

**Why:** I matched prompts to the approved frames (shots 2, 5) instead of checking frames against the script. The approved stills page was checked for looks, not story logic.

**How to apply:** before quoting any video batch, check each shot in order: (1) the line, and who says it to whom; (2) who stands where in the frame, and whether that allows the line; (3) whether it continues the previous shot (place, wardrobe, time); (4) callbacks (98 and 100 call back to 5). If a frame contradicts the script, flag it to Amin. Never edit the prompt to fit the picture.

Audit 11-16 (page https://claude.ai/artifact/X4ccYWumzyqD7unUGAAWkU):
- MUST: 5/6 restage outdoors as the photo under the shot 4 trees, Dee beside Kenya, then steps back (2 new frames); 1/2 order (crop Dee out of s001 free; shot 2 she slips out per script).
- SHOULD: 41/42 cardigan vs scrubs + driver facing camera; 77 wrong room (not Faye studio); 43 reflection reads as a second woman; 102/104 book text out of date vs riser chart.
- FREE prompt fixes: 39, 11, 83, 60.
- V1 clips 3, 4, 7-10 stand. NO SPEND until Amin says so.
Related: [[feedback-frame-standard]], [[wedding-blocking-plan]].

SHOT LOGIC GATE (Amin 11-16 12:21, in project instructions): before any quote, show a one-line logic check per shot (who is where, what is said, why it follows), run 3 passes (script, project instructions, order/callbacks) and actually do them. Gate v2 is on the audit page. Book facts: DRIVE look = beige cardigan (no scrubs). Shot 2 clip stands (cut lands +0.10 s after the line). Shot 1: A free crop (cuts the far-left girl) or B paint-out + re-render. Wedding text follows Amin's riser chart over the old standard map.

RATIONALE DEFINED (Amin 11-16 12:25, in project instructions): rationale = every objective of the video; never show anything failing time/space/position/sequence/visual logic, never offer a flawed option, show only the correct version. Resolution: shot 1 STANDS (book action); shot 2 frame is wrong (must be on her exit path by the tent, Kenya soft on the riser). Quote card 11-16: frames 2,5,6 new + 41,42,43,77 edits = 14 cr, then videos 2,5 Wan + 6 Seedance = 47; base 61, cap 75. Awaiting GO.

LOOK + STAGE RULE (Amin 11-16 12:27): every character must show the exact locked look + skin stage for that point in the timeline (2009 / Before / Night 1 / Day 14 / Day 30 / wedding D30); every logic line names the look master id + stage. Stage audit 11-16: all frames read the right stage; Day1->14->30 builds for all 4. Set flags: Zoe D30 (s094_3) wrong wall/light; Simone D1 (s092_4) missing the lit mirror. Quote now: 9 frames 18 cr + videos 2/5/6 47 cr = 65 base, cap 80.

PIXEL AUDIT 11-16 13:50Z (Amin 13:48 angry: use the book + prompts already built, no extras, no options, one plan one quote). Fails vs book: 2009 print (family must be dressed for graduation, outdoors lawn = sets 5/6), 2, 5, 6, 10 (table must match 4), 21 (KVAN room != 17), 41, 42, 43, 61 (Zoe at edge, must be Kenya), 77, 92_4, 94_3, Kenya robe portraits 92_1/93_1/94_1 (locked robe look has silk wrap). Free: comp new print into 4/37/100/105, 83/84 swap (body-oil words over soap), 74 dropper paint-out, 102/104 text to riser chart. Quote sent: 16 frames 32 cr + V1 re-renders 2,4,5,6,10 = 63.5 -> 95.5, cap 105.
