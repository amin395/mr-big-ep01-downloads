---
name: brand-songs-drive
description: Amin's YO Skincare brand songs pulled from Google Drive (connector works for audio); picks for score, Big Skin Shine sting, alt end tag
metadata:
  type: reference
  modified: 2026-10-20T19:20:29.131Z
---
Google Drive connector connected 2026-10-20 19:07 (Amin: "Use Google Drive for this"). Drive's `download_file_content` returns base64. Oversized results get saved to a tool-results file, so decode them locally with jq + base64 -d. This works for audio.

Files:
- 10 unique songs are in /mnt/project-files/mr-big-ep01/music-drive/. Details are in .notes/inputs.md.
- Duplicates: Anthem Amapiano = Remember It Well; Da Real Deal = OG Supa Glo.

Picks (auditions in music-drive/auditions/, built 19:25):
- **01 Big Skin Shine sting:** Glow_Tonight_Disco. The groove runs from 3.62s under "Big... Skin...", the music drops out for "SHINE", then a one-bar disco hit (8.5-10.45s).
  - Use a 0.5/0.5 stereo downmix of the VELVET line. Its left channel alone is heard by ASR as "shot", so "Shine" is borderline in the recording. An optional Suno pickup with a crisp, held SHIIINE would fix it.
- **02 Briefing bed:** YO_Da_Real_Deal outro (88-108s), low-passed at 450 Hz to leave a brand bass pulse. It cuts out before "It gets worse!" ASR confirms every A1 word stays clear.
- **03 Alt end tag:** Glow_Like_Dat_Kimmy 7.6-16.4s, which sings "Keep yourself beautiful, don't gotta go broke for that". For an end-card A/B test against the "We Don't Play" close.

See [[lipsync-fix-plan]], [[feedback-director-mindset]].
MUSIC PLAN sent 20:09 (awaiting Amin OK on items 3 and 5):
1. Open: We Don't Play (Remastered x2), LOCKED.
2. Slam, panic, Assistant: no music.
3. Big Skin Shine: disco sting.
4. Exec scoffs: no music.
5. Briefing: Real Deal low pulse, cut on "It gets worse!".
6. Everything from the confrontation through "Calendar reminders": NO music, cha-chings in a dead-quiet room. The "sneaky theme" idea is dropped.
7. Close after "Somebody SHINE me!": LOCKED.
A/B option: alt end card with Glow Like Dat.
