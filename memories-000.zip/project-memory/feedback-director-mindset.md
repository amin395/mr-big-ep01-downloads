---
name: feedback-director-mindset
description: Amin wants Claude to act as a Pixar-level director/editor and proactively flag everything, not just react to his notes
metadata:
  type: feedback
  modified: 2026-10-20T18:56:51.228Z
---
Amin 2026-10-20 18:48: "You are supposed to be acting in the position of like a Pixar animation editor... If I'm missing something, then you're supposed to be telling me... I should not have to continue to call out things to you." He rejected a report that only fixed what he had called out and then asked for credits.

**Why:** he can't spot every craft issue himself; he needs Claude to own comedy, believability, story clarity and polish.
**How to apply:** before every report or deliverable, run a full director's pass yourself, frame by frame. Cover:
- the hook in the first 3s, and brand + price early;
- setups and payoffs, and reaction beats;
- acting that matches the voice, eyelines, identity drift against the master images;
- camera moves, color grade match;
- sound layers;
- captions and end card in platform safe zones (Reels: bottom 35% and top 14% are covered);
- length per platform.

Mark which items are his notes and which are your own. Free fixes first, then a credit quote. See [[lipsync-fix-plan]].
- 10-24 Amin again: "I don't want to continue to have to ask you to do what you should already think about doing in regards to conveying value and emotion, drama, attention retaining content." Before every story update, audit EVERY product + EVERY ingredient's job (esp. ones in all 3 bottles: black seed, jojoba), each audience's payoff, each character's arc (e.g. Ms. Dee's own change), where-to-buy, social proof, and point-of-difference framing. Fix all gaps unasked.
- 10-29 QUOTE = HARD CAP: never spend past a quote, even for a "correction" (e.g. the 2-cr Kenya skin-tone fix that made 28 vs 26). Stop, show the problem, ask Amin, then spend. Coordinator reminder 10-29 06:38.
- 11-11 Amin: GRAPHICS MUST MOVE ("not just sitting there looking at a chart"; people see how things are done), clean + high quality, but efficient (don't burn credits). Edit-built motion graphics for text/maps/charts; AI only for diagrams/acting. Before any book/prompt delivery, run a scripted stage-order + position-consistency + audio-label check.
- 11-11 06:03 Amin: EVERY product-use shot shows the EXACT YO bottle (right variant, label readable), never a dropper/generic bottle. Method: composite real product photo into the start frame, then animate. Women's soap = LEMONGRASS (Kenya says "is that lemongrass?"); men/Marcus = PEPPERMINT. Groom Marcus + 3 locked groomsmen added (Marcus ashy feet -> body oil Night 1; groomsmen join wedding wide on 'We in it').
