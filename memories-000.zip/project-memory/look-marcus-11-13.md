---
name: look-marcus-11-13
description: Marcus look sheets 11-13: lighter ash fix + wedding glow method, LOCKED 11-13 09:30 (media 26fd8edc/75b8c0dc/a8303407)
metadata:
  type: project
---
## Marcus (11-13 08:15)
- Renders 220 (shower, job 32c916bd) + 221 (lounge, fafc7c0b), 3 cr: generator kept heavy white ash from the old sheet. Fixed free with p1/grade/ash.py (skin-only recolor of gray ash on arms/legs/feet, keep=0.5 texture). Outputs img/220a.png, 221a.png.
- Wedding: flat brightness lift (fit WED 1.34) made deep skin read LIGHTER -> rejected. Use glow_marcus.py style: saturation +30%, small lift, warm gold glow on high planes. Lesson for male/deep skin: glow = richer + highlights, never a flat lift.

Related: [[look-feedback-11-13]]
