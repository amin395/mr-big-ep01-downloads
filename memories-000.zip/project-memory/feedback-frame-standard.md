---
name: feedback-frame-standard
description: Amin 11-15 rejected start-frame batch 1 for continuity/geometry/cast errors; the anchor + spec-gate method every frame must follow
metadata:
  type: feedback
  modified: 2026-11-15T23:27:21.963Z
---
Amin 11-15 18:25 ET: angry: "You're supposed to have a standard that you're checking this stuff by before you even produce it... I do not want iteration after iteration."

He caught these errors, which my check had passed:
- Simone missing from the wedding wides.
- Mirror geometry impossible: a second mirror or sink behind her, or a reflection that doesn't match where she sits.
- Studio shots 26-30 don't match shot 25.
- Kenya's hair and car change from shot 15 to 16.
- Car shots: Dee faces the wrong way, extra arms.
- Scale: Amin a giant, people standing on tables.
- Wrong bottles and labels.
- Liquid black soap shown clear. It is BROWN.
- Hair diagram showed slicked hair. It must be natural with laid edges, gel and curl cream.
- Zoe looked about 6 in shot 102. She is 14.
- The booth was made up. It must match the real tent and table cover.

**Why:** generating each frame alone lets the model reinvent the set. Thumbnail QC misses geometry.

**How to apply (every frame from now on):**
1. ANCHOR per set: attach the approved anchor frame and say "same room, furniture, camera side, light".
   - Studio = shot 25, idx 250.
   - Kenya car = shot 15, idx 150.
   - Mirror portraits = Simone shot 92.4, idx 924.
2. CHAIN: the same character in consecutive shots attaches her previous frame (hair, outfit, face).
3. RULES in every prompt:
   - Mirrors: one mirror, one sink; the reflection matches the real position.
   - Cars: driver faces the windshield; 2 arms per person.
   - Scale: real heights, feet on the floor, never on furniture.
   - Exact bottle variant per scene.
4. SPEC GATE: before showing Amin, check every frame at full size against its spec:
   - who is in frame, position, facing, hair, outfit, props/bottle, set vs anchor, scale, limbs, hands, mouth.
   Re-roll failures inside the cap.
5. Story facts from these notes:
   - Simone is a visible wedding guest beside the risers in the wides, and steps up in shot 104, which is a full wide.
   - SIMONE = UNSCENTED set (sensitive skin): soap-unscented + Elixir + Body Oil, everywhere including her mirror portraits and gift bag.
   - Black seed shot 74 pours into the 3 real bottles: lemongrass wash, Elixir, Body Oil.
   - Elixir use (shot 71): 2 drops in palm, rubbed on, coats the whole skin, absorbs, glows.
   - Body oil diagram (shot 85): a little shine on the top layer.
Related: [[feedback-director-mindset]], [[look-feedback-11-13]].
