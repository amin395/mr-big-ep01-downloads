---
name: feedback-audio-drive-track
description: Every concept/story pitch or strategy update for Amin must ALSO ship as an audio drive track, unasked
metadata:
  type: feedback
  modified: 2026-10-21T20:29:20.767Z
---
Amin 2026-10-21 (15:00, 19:36): he listens while driving. Every concept, story pitch or substantial update must come with an audio track as well as the text, without him asking.

**Why:** he reviews on his phone while driving; text-only pitches stall.
**How to apply:** render with free local Kokoro TTS (sherpa-onnx, scratchpad tts_run.py, model kokoro-en-v0_19, speaker 1, speed 0.95), encode with ffmpeg as an 80k mono mp3, copy to /mnt/project-files/mr-big-ep01/napkin-ad/, and put a player at the TOP of the review page (DdHZjwY3HodA6qzJWJ3eBj). Spell numbers out, no emoji, and say who speaks and whether it's sung or spoken. Related: [[yo-concepts-round2]].
- BUG 10-22: publishing the review page with `edits` alone does NOT upload new audio files, so the players were dead and Amin couldn't play them. When adding a track, ALWAYS publish with `files` (Edit html, then publish file_path + files map). Verify with Artifact list scope "files".
- REVIEW ROOM SIZE CAP 256 MiB hit 11-06 (v70): removed v8/v8-1/v9/v10/v11 cut mp3s (copies stay in mr-big-ep01/music-suno/). Before adding big audio, prune superseded files via files map null.
