---
name: feedback-eyeline
description: Amin 11-16 18:12 caught Kenya looking into the lens on "Mama, can you stand in the back?"; every talking frame must have the speaker looking at the listener
metadata:
  type: feedback
---
Amin 11-16 18:12, angry: in shot 5 Kenya looks at the camera while asking her mother. "What's your rationale in presenting this to me?"

**Why:** the book text and the lip-sync template both said "face clearly visible to camera / three-quarter toward camera". The generator read that as eyes to lens. My spec gate checked look, place and wardrobe but never eyeline.

**How to apply:**
- Every talking frame and prompt names the LISTENER: "eyes and head on <listener>, never into the lens; mouth still visible to camera".
- The spec gate gets an eyeline line per shot.
- Exceptions: mirror shots (26/28/30), where the camera is the mirror; founders 106/107, who speak direct to the viewer.

Audit 11-16:
- FAIL: 2 (Dee to Kenya), 5 (Kenya to Mama), 54 (elder to Amin), 60 (Kenya to Zoe; Faye is NOT in the sink scene 58-63, only VO).
- PASS: 26, 28, 30, 52, 53, 61, 72, 73, 98, 106, 107.

GO 19:14 cap 160. Edits 2d7fa9fe(2) 2a169971(5) c260a5f0(54) e4fb9649(60) all pass, files fixB-pending/sNNN_eye.png, page https://claude.ai/artifact/EKBB2g6iiCJYbsRdorxMxB. Book: EYELINE line in 15 talking vid_prompts (backup book_pre_eyeline.json). Spent 139.5/160. Next after OK: promote to APPROVED, Wan clips 2+5 (20 cr).
Related: [[feedback-story-logic-audit]], [[feedback-frame-standard]].
20:15Z Amin asked if shot 5 should put the viewer in Ms. Dee's place. Proposed POV: Dee out of frame, Kenya14 looks UP into the lens; cuts to shot 6 as a reverse, pays off in 98. Old clips can't be reused (Dee in frame). Card: POV frame 2 cr + clips 2/5 20 cr, cap 162. Clips 2 and 5 ON HOLD.
20:20Z Amin GO POV (cap 162). Shot 5 POV frame = job 2456417d (fixB-pending/s005_pov.png), passes; spent 141.5. Amin wants shot 98 ("I asked you to stand in the back once...") as Dee POV too: Kenya (WED f58e8d54) holds Mama's hands (Dee WED 416cdf8c sleeve/hands in foreground) and looks into the lens; frame 2 cr (cap would go to 164), clip later. Clips 2 and 5 wait on his OK of the frames.

POV shots 5 + 98 (Amin 20:15 11-16): viewer = Ms. Dee. Shot 98 POV must be on the RISER set (Kenya front riser center, family behind, Marcus frame-right), not the ceremony aisle; never a second bride or a cream-dressed elder in bg (reads as twin Ms. Dee). v1 d3d2463f rejected for that. Clips 2 (6be728f2) + 5 (14e749d8) delivered 20:36, take3/.
Shot 98 POV v2 = job 3e248a6a (from shot 97 frame 601d4512 + KENYA WED + DEE WED), pass self-QC, file frames/fixB-pending/s098_pov.png, awaiting Amin OK. Spend 165.5/166.
Batch 2 video notes moved to [[batch2-video]].
