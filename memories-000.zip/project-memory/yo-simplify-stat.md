---
name: yo-simplify-stat
description: Simplicity stat for YO ads = The Benchmarking Company Jan 2025 (93%/83%/76%), replaces Olay 81%; "won't burn/tight" still blocked
metadata:
  type: project
  modified: 2026-10-23T00:23:36.836Z
---
Amin 2026-10-23 00:18 pasted 93% / 76% / 83% stats (no source). Traced: The Benchmarking Company, January 2025 beauty habits study, 3,900 U.S. women (via cosmeticobs.com 2025-03-19 + GCI/MedEsthetics 2025-03-04; primary report paywalled).
- 93% seek to simplify their routine without compromising results (also 93% appreciate time-saving tips, 94% say convenience matters).
- Multi-use products liked because they save time 83%, simplify routine 76%, save money 57%.
- 60% use 4-10 products a day; 31% use 11+. 67% regularly buy multi-function products.
- USE: replaces the UK Olay 81%. On screen in Buried shot 16 ("93% of women want a simpler routine, without giving up results") + footnote naming study. Confirm exact wording with the primary report before air. General U.S. women, not Black-women-specific: pair with our 30-woman study number.
- Amin also asked "Won't burn, won't leave you tight like raw black soap: say it now." Answered NO until pH test + HRIPT (safety claim + comparative). Say now: "Not all black soap is the same", ingredients, label line "without leaving skin feeling stripped", Tonya's dramatized line.
- Drive track: mr-big-ep01/napkin-ad/YO-stats-and-claim.mp3 (top of Review Room v25).
Related: [[yo-market-research]], [[yo-buried-door-opener]].
