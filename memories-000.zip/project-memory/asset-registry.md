---
name: asset-registry
description: Higgsfield asset registry (Amin's mandatory protocol 11-15): project id, folder ids, what is registered/pending, registry file locations
metadata:
  type: project
---
Amin 11-15 rule (project instructions): every approved/locked asset must be registered in the Higgsfield project "YO SKINCARE | Mr. Big Beauty | Episode 01 | An Inside Job" (acecdd6c-5b9f-4d70-a818-31e8d3a4f0b2, workspace e4f91310-9a50-4c8e-8ff0-0930c4eaa618). Approval = register, never regenerate. Before any generation, pull refs from these folders and attach the actual media.
Folders (created 11-15): 00 PROJECT BIBLE c6613ba8-6237-4b69-b1ed-b03baa9160f6; 01 APPROVED CHARACTERS 7a71d67c-f448-4ade-b677-eba0b0e0771b; 02 APPROVED ENVIRONMENTS 35e2e848-443f-48ee-8e32-fb4a2d4ea66f; 03 PROPS & PRODUCTS a4ada47d-2c81-4c2d-9617-20b155855969; 04 SCENES & FRAMES 6eb82507-1997-4ec4-8424-fe10db3ecc14; 05 VIDEO 49dcca7c-2bb0-46b2-b5d4-fa1186ca1db8; 06 REVISIONS & ARCHIVE 273c3cb7-bb03-446a-bddd-f750197cd7be.
11-15 05:40 COMPLETE: 54 placed (00: song master mp3 5c768dd1 + registry md 0be0e11f + json 884aaa4b; 01: 47 looks; 03: logo + real product photos lemongrass ae432abc, elixir 2197ea71, body oil 79efd9ff). Each look has Amin's lock quote+time in master-registry.json; all 48 images re-downloaded HTTP 200 + visually matched. Identity master per character = Night 1 clean sheet (Kenya f4984ceb, Dee 1a677ff7, Zoe 3870a9b3, Simone 48e65dcb). Film title FOREVER PICTURES in all docs. Earlier: 48 registered (47 locked looks = book LOCK dict into 01; YO logo a274248a into 03), all connector-confirmed. PENDING (asked Amin on a card): 16 plates (p1/jobs.txt idx 100-115), founder photos, product photos, song stems, book. Registry: /mnt/project-files/mr-big-ep01/registry/MASTER-REGISTRY.md + master-registry.json; page https://claude.ai/artifact/LXWfhFdj953SHuLZjrHpAT.
Attach API: attach_project_asset with source type media_input (uploads) or job (renders).
