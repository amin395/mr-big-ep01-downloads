---
name: wedding-blocking-plan
description: Forever Pictures wedding riser chart + per-shot cast proposed 11-16 after Amin's notes (Simone beside Ms. Dee, cousin two cut); awaiting his yes/no
metadata:
  type: project
  modified: 2026-11-16T05:40:25.703Z
---
Amin 11-15 23:57 ET, angry: the frames don't follow the storyline. Wedding wides didn't match each other. He asked: how many pictures have Kenya, Simone, and her mother? Which ONE picture has everybody?

**His corrections:**
- Simone stands next to her mother. Front row order: Simone, Ms. Dee, Kenya (mother in the middle). Never beside Marcus.
- Simone in the bridal-party dress color, not green.
- The "strange girl in pink with braids" (cousin two) has no role. Cut her, or put Marcus's family on that side.
- Groomsmen must be in the wides.
- 107: no second table. 91: liquid must pour from the spout; same outfit as 90.
- 95: Day 30, so she needs full radiance. 14 and 96: side angle, driver facing the windshield.
- 58: soap the SAME color as the black soap bars.
- Do not burn credits on misses.

**Plan doc (awaiting his yes/no, NO spend):** https://claude.ai/artifact/5CMo3r7e3EYshZn2wSHXKu

**Riser chart (left to right from the camera):**
- BACK: auntie one, grandfather, groomsmen 1-3.
- FRONT: cousin one, Simone, Ms. Dee's spot, Kenya (center), Marcus, uncle + auntie two (Marcus's side).
- Zoe (14) on the grass in front of Kenya. Use her home look 95a6ad2f for age; the wedding sheet makes her a child.
- Faye stays by the cake table, never on the risers.

**Per-shot rules:**
- The wides are 1, 3, 13, 97, 99, 100, 102, 104. Only Ms. Dee changes between them.
- 104 = the everybody picture and the master frame. The other wides are edits of the master.
- The book says Simone wears her SILK ROBE at home in shots 90/91, not a suit.

Cap: 45 cr, Amin GO'd option A 11-16 05:30Z (also: Zoe must NOT stand in front of the bride; customary portrait order; he prefers scripted back angles for car shots). Riser chart now customary: Zoe far-left front, then Simone, Ms. Dee, Kenya, Marcus, his father, his mother; back cousin one, auntie one, grandfather, groomsmen.

**11-16 09:40Z:** Amin: Amin+Kimmy in 1083 GREAT (keep exactly). Side walls must be HALF-height (the skirt) with the approved TENT v4 print (pattern + yellow band + YO logo) same inside as outside, NOT full height. Free fix walls2.py -> r2/1084.png. Spent still 69/71.
**11-16 09:30Z:** GO 2 cr edit 5289e175 MISSED (put pattern flaps OUTSIDE, hug unchanged). Free fix on 1081g: hand on his shoulder removed (aligned 1069c), inner side walls full-height pattern warped from 1082 flap (walls.py) -> r2/1083.png. Spent 69/71. Back-banner garbled bottle now hidden.
**11-16 09:20Z:** Side hug GO (cap 71). Edit a61dcf57 (2 cr, 67/71) -> Amin head+silver pendants pasted back from 1069c (SIFT affine, same position) since edit gave gold coin necklace; shoulder-hand rings tinted gold free. Result r2/1081g.png awaiting Amin. Kimmy face = new render (very close, not pasted).
**11-16 09:10Z:** Amin LOCKED refreshed founders r2/1069c.png (uploaded media ee588676). Wants hands/rings fixed (Kimmy missing green+red stone rings, henna faded gray; Amin knuckles grayish) + warmer pose for name line. Card: side hug up to 4 cr (cap 71) pending.
**11-16 09:05Z:** Amin asked Kimmy younger/shapelier/square shoulders. GO cap 67; edit ca38580c (2k, 2 cr) PASS first try; ECC-aligned, body-only composite (rows>=1500, x90-585) onto 1068 -> FOUNDERS = r2/1069c.png. Spent 65/67.
**11-16 07:57Z:** FOUNDERS PICTURE = r2/1068.png (1536x2752): 1079b outpainted 1:1 (e5649775) then 9:16 (3c24189d), original 107 pixels (scale 1.12 at 338,547) pasted back over Amin side. Cap 63 all spent. Awaiting Amin OK; outpaint needs ASPECT CHANGE to extend.
**11-16 07:50Z:** 107 streak redone free (r2/1077.png); Amin OK'd it, asked jewelry: GO 3.5 (cap 59). 107 jewelry = r2/1079b.png (edit 39fc949a lower body composited, ruby moved to right hand + onyx recolor free). MISTAKE: outpaint 60032b52 at same 9:16 aspect only UPSCALED (2 cr wasted). Zoom-out needs aspect change (9:16->1:1->9:16, 2 cr each). Spent 59/59. Amin wants expanded 107 to be THE founders picture (106 too).
**11-16 07:25Z (Amin 07:19 ANGRY):** rejected 1066k (Kimmy face looks pasted) + 107 streak brush (dark smudge, incomplete). Showed locked sheets page https://claude.ai/artifact/6T5sYVNYEMMMQuEu86eE6U. Never face-paste again. Plan: redo 107 streak properly free; 106 = zoom-out of 107 itself so faces are the same pixels (needs his GO).
**11-16 07:20Z:** 106 FINAL = r2/1066k.png (base 106c_base + Kimmy face region from edit job b42486dd, feathered paste; Amin kept from base). Spent 55.5 of 56.5. Edit job also changed Amin, so ONLY paste Kimmy region. Awaiting Amin look on 106/107.
**11-16 07:15Z (Amin 07:03 ANGRY, stop burning credits):** CANONICAL founders = faces in 107 (1075g.png): Kimmy as in 107, Amin as in 107 with LIGHT (subtle salt-pepper) streak, never the bright white streak. 106 Amin = free seamlessClone of 107 face (106c_base.png). Kimmy 106 still wrong: 107 Kimmy is cut at frame edge so free paste fails; asked 1.5 cr card using crop r2/kimmy107_crop.png. Do NOT show Amin approved frames again; only the ones he flags.
**11-16 07:00Z:** GO 3 cr (cap 55, spent 54). 106 = 21d045bf (+free clean -> 1065f), 107 = 1ff63fdc (1075f). Amin face from AMINR 08e09fe3; Kimmy from 0c27bbf1. Awaiting Amin look.
**11-16 06:50Z (Amin 06:46, angry):** 106/107 Amin face WRONG (full beard wrapping face): use LOCKED AMINR 08e09fe3 as face ref, keep current body (approved bigger upper body). Kimmy = as in 107 (0c27bbf1). 3 cr card pending (cap 52 used 51). 21 reverted to original approved frame (frames/png/210.png) - never redo approved frames. 23 gray tint removed free (230g.png).
**11-16 06:30Z (Amin 06:24):** Faye OUT of the family portrait (only in candid 102 by cake table). New master 104 = job 2c5223ee (locs man = groomsman 3 back-right, adult cousin woman blue dress back-left). Done from it: 1 (53f716ac), 3 (5e116876), 97 (601d4512), 13 = master + free golden haze, 100 = master. 99 + 102 wait on cap card (45 hit exactly). Amin LOCKED all other frames. 106 = 4d41f1c5 (+free claims/url clean), 107 = 0c27bbf1 (Kimmy in 107 is how she really looks; Amin beard: bare cheeks, long chin beard). 45/46 jewelry 7d0dbc0b/9403e139.
**11-16 06:10Z:** 31.5 of 45 spent. Fixed 106 (1062g, Kimmy face from real photo upload 2b90ba27, Amin build ref d0c73651), 107 (1073f), 38 phone = Zoe selfie (382). Book: shot 90 card adds "UNSCENTED one, for your sensitive skin"; 91 uses Unscented wash; 71 = film coats, sinks in, glows (nothing on top). Wides still wait on 104 OK.
**11-16 06:00Z status:** 24 of 45 spent. 104 master = job 744e89ed (r2/1041.png), awaiting Amin OK; known gaps: back row shows 2 groomsmen + locs cousin in navy, Simone/Kenya read young-ish. After OK: wides 1,3,13,97,99,100,102 as edits of 744e89ed (~10.5 cr). Round-2 passes on stills page v5 (14/96 anchored to shot 42 f3460c47; 21 white patches removed free; Day-30 radiance = free grade; real bottles composited). Files mr-big-ep01/frames/fix/r2/. Related: [[feedback-frame-standard]].

## 11-16 09:58 VIDEO PHASE START (Amin 09:33: build ONLY on approved masters, 1-2 takes max, no hallucinations)
- Batch V1 shots 1-10 prepped: spec mr-big-ep01/video-v1/batchV1_spec.json (start media ids, byte-verified; audio D1 d3e4793f, K14 c11ad27c, 0.3 s lead padded to 4 s mp3). 5 prompts fixed to match approved frames (1,2,5,7,9). Card: GO cap 175 (base 150.5). Approved still = always start frame (ignore book "continuity" attach). Shot 104 -> use master 1042. 106/107 -> 1084 (107 crop).
**11-16 10:10Z APPROVED FRAMES FOLDER (Amin 10:02: no shot may ever point to an older still):** /mnt/project-files/mr-big-ep01/frames/APPROVED/ = 110 files s001..s107 (+ s071_end, s092_x/093_x/094_x) + APPROVED-MANIFEST.json, built from the stills page img srcs (pixel-verified). s100 = s104 = master 1042; s106 = s107 = 1084. Not in folder by design: 62 (continues 61's last video frame), G edit shots 76/87/88/89/103/105/108/109. ALL older stills moved to frames/_ARCHIVE_DO_NOT_USE (read-only) + scratchpad/_ARCHIVE_DO_NOT_USE. Shared mount re-saves PNGs: verify by PIXELS not md5. Batch V1 GO'd (cap 175).
**11-16 10:25Z BATCH V1 RENDERED:** 150.5/175 spent, 1 take each. 9 pass; shot 3 Kling made the bride glow and vanish -> replaced FREE with the approved still s003 held as a freeze (ffmpeg flash + 3% push). Clips in mr-big-ep01/video-v1/take1/; review page https://claude.ai/artifact/5A78drXw13XZyCcSAHEboZ. Lesson: "freeze" shots = free still holds, never AI.
**11-16 14:58Z FIX B (Amin GO 14:35 cap 105):** 17 corrected frames + new 2009 class photo prop on https://claude.ai/artifact/RMGWLv3gDqEoUjXEz9bGAx, files mr-big-ep01/frames/fixB-pending/ (NOT approved yet). Spent 40/105 (16 edits + retakes 2/6/Zoe + 74 dropper). Shot 2 + Zoe D30 = free composites of approved pixels (22c over blurred s003; 093_3 room + 094_3 Zoe). Book 4/83/84/102/104 text updated (backup book_pre_fixB.json). Next after Amin OK: copy to APPROVED, render clips 2,4,5,6,10 (63.5 cr).
**11-16 17:05Z FIX B R2 (Amin 16:37 notes):** Spent 66/105. Shot 21 OUT (pending file archived). 2 = hair fix free (22d). 5 = r51c (edit ed0e9337 + free crop: no podium, at foot of class riser). 10 = r101c (4 new family photos jobs ecda799f/d63dd0d2/d2e40b31/82526ee2, Dee half cut off right edge, free perspective comp). 74 = r741L (real Nigella pod f1499442 + real labels ECC-pasted from 074c). Portraits drifted from locks (Kenya D1 glossier than D14, D30 forehead hotspot; Simone D1/D30 off): re-edited from locks + free Lab skin match to lock (fixB/skingrade.py). Page v2 same URL. Awaiting Amin OK; then videos need cap card.
**11-16 17:10Z FIX B APPROVED (Amin 16:59 "everything else OK, let's move"):** after 2 fixes (shot 2 crown hair free = 22e; Simone D1 edit 154b0209 bags/brows per lock 48e65dcb, bottles pasted back). Spent 68/105. All fixB frames promoted to APPROVED (old in frames/_ARCHIVE_DO_NOT_USE/pre-fixB/), s021 REMOVED from APPROVED + manifest. Card: raise cap to 132 for clips 2,4,5,6,10 (63.5 cr) pending.
**11-16 18:00Z V1 RETAKES DONE (Amin OK 17:46 cap 132, spent 131.5):** clips 2,4,5,6,10 from new APPROVED frames, 1 take each, all pass QC; files mr-big-ep01/video-v1/take2/; page https://claude.ai/artifact/UKhbPK9YMcurzMoUNdLDiL. Cuts: 2 @3.03 s, 5 @2.74 s (Dee walks off after the line, cut hides it). Awaiting Amin.
