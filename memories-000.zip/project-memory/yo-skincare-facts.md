---
name: yo-skincare-facts
description: Verified YO SKINCARE products, prices, ingredients, claims, URLs (yoskincare.com, checked 2026-10-14)
metadata:
  type: project
---
Site confirmed by Amin: https://www.yoskincare.com. Brand by GO ESSENTIALS, INC., Atlanta GA. Tagline: "Botanical Skincare for Melanin-Rich Skin".
- Triple-Action Cleanse = African Black Soap face & body wash, 9 fl oz, $9.99 (Unscented/Peppermint/Lemongrass); sea moss, black seed oil, jojoba. Label: "helps remove dirt, excess oil and surface buildup without leaving skin feeling stripped."
- SUPA GLO 10-Oil Facial Elixir, 2 fl oz, $15.99; black seed + jojoba, NO sea moss.
- SUPA GLO 7-Oil Body Oil, 8 fl oz, $13.99. Jojoba is in BOTH oils, so the kit has <=16 distinct oils: never say "seventeen (other) oils" (checked combo page 2026-10-14).
- Complete Routine (all 3): $37.97, compare-at $39.97 (= sum of singles). Permanent per Amin. Page: https://www.yoskincare.com/products/yo-supa-glo-combo-pack
- Claims OK: "lightweight", "fast-absorbing" (page: "absorbs fast", "finish light"; labels: "lightweight blend", "absorbs easily").
- Google 5.0 stars, 60+ reviews (don't quote count in ads).
- Product photos in /mnt/project-files/mr-big-ep01/products/ (soap front PNG has a FAKE baked-in checkerboard, needs a real transparent file).
**Why:** ad scripts/claims in [[mr-big-ep01-project]].
**How to apply:** re-check prices before new ads; never say sea moss is in the Elixir.
- Amin confirmed 2026-10-20 that the products are totally plant-based, so the "totally plant-based" claim is OK.

- SOURCING (Amin 2026-10-21): African Black Soap made in Ghana; black seed oil from Ethiopia. Amin wants Africa/source story highlighted. Say "made in Ghana", "Ethiopian black seed"; avoid flat "best in the world", "non-comedogenic", cure language. Black seed oil (Ethiopian) is in ALL THREE: cleanse, Elixir, Body Oil (site, 2026-10-21). Mixed/filled/packaged in US.
- NAME: YO = "Your Original Skincare" (Amin 2026-10-21). Target: melanin-rich skin, mostly African American / African descent. Song payoff "Y... O... Your Original".
- FOUNDERS (yoskincare.com/pages/about-yo-skincare, read 2026-10-21): Amin (15+ yrs multicultural beauty; helped grow Taliah Waajid Brand + World Natural Hair Health & Beauty Show, 300+ exhibitors/30k+ attendees) and Kimmy Waajid (daughter of a master esthetician who owns Corrective Skin Care). 2018 car accident (falling trees) driving to Essence Fest -> reflection, Do-for-Self -> YO. NEVER mention in ads the supply line breaking or partner's family loss (Amin 2026-10-21). Chose source over cheaper US black soap; Amin traveled to Ghana + Ethiopia himself. Site claims usable: Elixir "helps fade the look of dark marks"; Body Oil "visibly reduce the look of ashiness"; "Black-owned. Family-founded." "Accessible prestige."
- Founders photo (site home page) imported to Higgsfield media da0cb6e7-29d3-4bc6-a2fe-02a590a31aed; Kimmy OK as stylized character; Kimmy's mother by role only.
- Founder characters, booth, wardrobe, jewelry: see [[yo-founders-characters]].
