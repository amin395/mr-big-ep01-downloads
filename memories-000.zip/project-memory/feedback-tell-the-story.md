---
name: feedback-tell-the-story
description: Amin needs story pitches told as clear narrative (what happens, who it reaches, emotion, value per beat, then resources), not shot-table briefs
metadata:
  type: feedback
---
Amin 2026-10-24: "When you give me this update, it has to be very clear how the story is being told, what's going on in the story, and where's the value of each thing." A delta brief (changed shots only) confused him.

**Why:** he shares pitches with others and listens while driving; a listener must follow the whole story without the earlier versions.
**How to apply:** every story update = full narrative start to finish in plain prose (scene: what happens -> why it's there: audience, emotion, product value), a who-it-reaches table, an emotion map (peaks + intensity), proof, then a resources list (from Amin, cast, credits by phase, tests, time). Audio track tells the story the same way. Never send only the changed shots. Related: [[feedback-audio-drive-track]], [[yo-fresh-storylines]].
