**The film:** *Forever Pictures*, a short animated film (Pixar-style 3D) for YO Skincare, a Black-owned, plant-based skincare brand. A mother has stood in the back of every family picture for seventeen years. At her daughter's wedding, she finally gets in the picture. An original anthem carries the emotion, and a narrator, Ms. Faye, tells the story.

These are short roles: one or two lines each, but they are the moments the whole film turns on. Kenya at 14 must be voiced by an adult (18+) who can sound young.

## Ms. Dee, the mother (2 lines)

**Who she is:** 56, a nurse's aide who has worked doubles her whole life. Soft, low, worn but loving. She has stood in the back of every family picture since her daughter was 14.

**D1** · on camera (we match the mouth to your read)

*The moment:* her daughter's wedding. The photographer calls, "Family of the bride! Everybody in!" and she slips out of the frame.

> "Take it without me, baby."

- **How to say it:** soft and practiced, a smile that doesn't reach her eyes. She has said this a hundred times.
- **What it has to make people feel:** a gut punch: a mother removing herself from her own family picture.

**D2** · voice-over

*The moment:* the week before the wedding, in the makeup chair. She takes the washcloth to wash her grown daughter's face herself.

> "Let me."

- **How to say it:** barely above a whisper, holding out her hand.
- **What it has to make people feel:** the mother steps forward. The turn of the whole film.

## Kenya, the bride (1 line)

**Who she is:** 31, an ICU nurse. Bright, funny, tired, proud. Mid-range voice, Atlanta.

**K13** · on camera (we match the mouth to your read)

*The moment:* the wedding portrait. The photographer calls the family in again, and her mother starts to slip out. Kenya catches her hand. The music drops out.

> "Mama, I asked you to stand in the back once. Never again."

- **How to say it:** steady and loving, holding her hand. A small break on "never again."
- **What it has to make people feel:** the payoff of the whole film.

## Kenya at 14 (1 line)

**Who she is:** Kenya in 2009, at her eighth-grade graduation, embarrassed in front of her friends. An adult who can sound fourteen.

**K14** · on camera (we match the mouth to your read)

*The moment:* her mother arrives straight from a double shift, still in scrubs and sweating under the gym lights, as the family gathers for a photo.

> "Mama... can you stand in the back?"

- **How to say it:** quick, embarrassed, half under her breath, eyes on her friends.
- **What it has to make people feel:** the wound the whole film heals. It has to sting because it's so casual.

## The photographer (2 lines)

**P1** · voice-over, the opening of the film

> "Family of the bride! Everybody in!"

**P2** · voice-over, the end of the film

> "Family of the bride!"

- **How to say it:** bright and busy, calling across a crowd. Say both exactly the same way, so the ending echoes the opening.

## How to record

- **Where:** a quiet room with soft surfaces. A closet full of clothes works well. No fans, AC, TV or music.
- **Mic:** a good USB mic if you have one; otherwise a phone voice-memo app at its highest quality. Keep the mic about 6 to 8 inches from your mouth, slightly off to the side.
- **Takes:** three takes of every line, each one a little different. Say the line ID before each take ("D1, take one"), then pause two seconds before the line.
- **Files:** WAV if possible (48 kHz), otherwise the original phone file. Name it with the role and line ID, for example "MsDee_D1.wav". Don't add effects, music or noise removal.
- **On-camera lines:** just play them naturally. We match the animated character's mouth to your recording.
