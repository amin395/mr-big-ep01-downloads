**The film:** *Forever Pictures*, a short animated film (Pixar-style 3D) for YO Skincare, a Black-owned, plant-based skincare brand. A mother has stood in the back of every family picture for seventeen years. At her daughter's wedding, she finally gets in the picture. The story is told by Ms. Faye, a makeup artist who has seen every woman, at every stage, in her chair.

A short role: one line, on camera.

## Ethiopian farmer

**Who he is:** an Ethiopian farmer who grows black seed. He pours a handful of seeds into the visitor's palm and tells him what they are called.

**Voice:** an Ethiopian man, proud and warm. The line is in Amharic: **ጥቁር አዝሙድ** (*t'ikur azmud*), meaning black seed. Please say it the way it is really said at home; correct pronunciation matters more than anything else here.

**Optional:** a second, slower take, and one take where you add a few natural words of your own in Amharic before the name. Please write down what you said so we can subtitle it.

**Lines:** 1

### Scene 7

*The moment:* The origin. An elder soap maker in Ghana and a black seed farmer in Ethiopia. Back in the chair, Ms. Faye explains what makes this soap different.

**ET1** · on camera (we match the mouth to your read)

*Cue, the line before yours:* Ghana elder: "My grandmother washed me with this. I washed her mother."

> "Tikur azmud."

- **How to say it:** Proud, pouring seeds into Amin's palm. Correct Amharic.
- **What it has to make people feel:** Authentic origin you can hear.

## How to record

- **Where:** a quiet room with soft surfaces. A closet full of clothes works well. No fans, AC, TV or music.
- **Mic:** a good USB mic if you have one; otherwise a phone voice-memo app at its highest quality. Keep the mic about 6 to 8 inches from your mouth, slightly off to the side.
- **Takes:** three takes of every line, each one a little different. Say the line ID before each take ("F12, take one"), then pause two seconds before the line.
- **Files:** WAV if possible (48 kHz), otherwise the original phone file. Name it with the role and line ID, for example "MsFaye_F12.wav". Don't add effects, music or noise removal; we match every voice to one room afterward.
- **Lines marked on camera:** just play them naturally. We match the animated character's mouth to your recording.
