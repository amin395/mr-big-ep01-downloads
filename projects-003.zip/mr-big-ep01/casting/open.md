**The film:** *Forever Pictures*, a short animated film (Pixar-style 3D) for YO Skincare, a Black-owned, plant-based skincare brand. A mother has stood in the back of every family picture for seventeen years. At her daughter's wedding, she finally gets in the picture. The story is told by Ms. Faye, a makeup artist who has seen every woman, at every stage, in her chair.

These roles can be cast with real voice actors. Anything we can't cast, we'll make with AI voices. All roles are Black American unless noted. Jordan and young Kenya are teenagers, so only cast **adults (18+) who can sound young**; otherwise those two stay AI.

## Kenya

**The bride, 31, ICU nurse.** Bright, funny, tired, proud. Mid-range voice, Atlanta. She performs for her phone, breaks down in her car, gets defensive in the chair and ends the film with its biggest line. 13 lines, 2 on camera. The biggest open role.

**Lines:** 13

### Scene 2

*The moment:* Today. Kenya, now 31 and an ICU nurse, films a glass-skin get-ready video for her wedding countdown. Her niece Jordan copies every word. After a twelve-hour shift, Kenya sits alone in her car and breaks.

**K1** · on her phone screen

*Cue, the line before yours:* Ms. Faye: "Now that baby's thirty-one. An ICU nurse, just like her mama. She takes care of everybody. Every body but her own."

> "Okay y'all, wedding countdown! Step seven: seal it in."

- **How to say it:** Upbeat creator voice, performing for her phone.
- **What it has to make people feel:** The modern habit, shown with love, not mockery.

**K2** · on camera (we match the mouth to your read)

*Cue, the line before yours:* Ms. Faye: "Somebody's always watching."

> "I did everything they said."

- **How to say it:** Alone in the car, exhausted, almost crying, not quite.
- **What it has to make people feel:** The low point every woman on her feet all day knows.

### Scene 4

*The moment:* Ms. Faye's makeup chair, the week before the wedding. Ms. Faye sees the layers on Kenya's skin and the bumps at her hairline, Simone admits she sleeps in her makeup, and the groomsmen tease the groom.

**K3** · voice-over

> "But my skin's healthy. Look at the glow!"

- **How to say it:** Defensive and proud.
- **What it has to make people feel:** The myth: shine means healthy.

**K4** · voice-over

*Cue, the line before yours:* Ms. Faye: "And these little bumps at your hairline? How long you been covering these?"

> "...Since nursing school."

- **How to say it:** Small, caught.
- **What it has to make people feel:** Years of hiding in two words.

### Scene 5

*The moment:* Ms. Faye sets her brush down and talks about every woman she has seen in 25 years: a montage of portraits, from the prom girl to the grandmother.

**K5** · voice-over

> "So my mama was wrong... and I'm wrong too?"

- **How to say it:** Hurt, close to tears.
- **What it has to make people feel:** Voices the shame every viewer is feeling.

### Scene 6

*The moment:* Ms. Faye introduces the couple who make the black soap she uses. The founders explain why they made it.

**K6** · voice-over

> "Black soap? Mama's bars dried us out."

- **How to say it:** Skeptical.
- **What it has to make people feel:** The biggest objection, said by the hero.

### Scene 7

*The moment:* The origin. An elder soap maker in Ghana and a black seed farmer in Ethiopia. Back in the chair, Ms. Faye explains what makes this soap different.

**K7** · voice-over

*Cue, the line before yours:* Ms. Faye: "Sea moss: a mineral cushion, so you rinse soft, not tight. Black seed: smooth and nourished, even while you wash. And jojoba. It ain't even really an oil, baby. It's a liquid wax, close to what your own skin makes."

> "Huh. It don't feel tight."

- **How to say it:** Genuine surprise, rubbing her hand.
- **What it has to make people feel:** Proof on her own skin.

### Scene 8

*The moment:* Ms. Dee takes the washcloth and washes her grown daughter's face herself.

**K8** · voice-over

*Cue, the line before yours:* Ms. Dee: "I should've done this a long time ago."

> "Mama..."

- **How to say it:** Eyes closed, tears.
- **What it has to make people feel:** Forgiveness in one word.

### Scene 9

*The moment:* The rest of the routine: the facial oil and the body oil. Ms. Faye names every oil, and Kenya tests her wedding dress.

**K9** · voice-over

*Cue, the line before yours:* Ms. Faye: "Rosehip to smooth. Turmeric to brighten. Argan and almond, vitamin E. Calendula to soothe. Grapeseed, light as air. Jojoba and black seed, the family. And copaiba."

> "Co-pai-what?"

- **How to say it:** Comic confusion.
- **What it has to make people feel:** Makes the rare ingredient memorable.

**K10** · voice-over

*Cue, the line before yours:* Ms. Faye: "Then the body. Seven oils, face to feet. Absorbs fast."

> "Not a mark on this dress."

- **How to say it:** Touching the satin, relief.
- **What it has to make people feel:** The non-sticky proof every woman fears.

### Scene 10

*The moment:* Thirty nights later. Everyone has changed something, and Ms. Dee looks at herself in the mirror.

**K11** · on her phone screen

*Cue, the line before yours:* Ms. Faye: "Thirty nights."

> "Y'all... I been doing too much."

- **How to say it:** New video, no ring light, laughing at herself.
- **What it has to make people feel:** She becomes the honest voice for her followers.

**K12** · voice-over

*Cue, the line before yours:* Marcus: "Babe, where my oil go?"

> "What oil?"

- **How to say it:** Innocent, hiding the bottle.
- **What it has to make people feel:** The comic button.

### Scene 11

*The moment:* The wedding. The photographer calls the family in again, and this time Kenya pulls her mother to the front.

**K13** · on camera (we match the mouth to your read)

*Cue, the line before yours:* Photographer: "Family of the bride!"

> "Mama, I asked you to stand in the back once. Never again."

- **How to say it:** Steady, loving, holding her hand. A small break on 'never again.'
- **What it has to make people feel:** The payoff of the whole film.

## Kenya, 14

**Kenya in 2009.** One line that has to sting because it's so casual. An adult who can sound fourteen, or AI.

**Lines:** 1

### Scene 1

*The moment:* The film opens at Kenya's wedding. The photographer calls the family in, and the bride's mother, Ms. Dee, 56, slips out of the frame again. Then a flashback to June 2009: Ms. Dee rushes from a double shift to her daughter's eighth-grade graduation, still in her scrubs and sweating under the gym lights, and 14-year-old Kenya, embarrassed in front of her friends, asks her to stand in the back.

**K14** · on camera (we match the mouth to your read)

*Cue, the line before yours:* Ms. Faye: "June, two thousand nine. A double shift behind her, still in her scrubs. Sweat on her brow, and the grease on her edges giving up in the heat."

> "Mama... can you stand in the back?"

- **How to say it:** Quick, embarrassed, half under her breath, eyes on her friends.
- **What it has to make people feel:** The wound the whole film heals. It has to sting because it's so casual.

## Ms. Dee

**The mother, 56 (and 39 in the flashback).** Soft, low, worn but loving. She has said "take it without me" a hundred times. 4 lines, 1 on camera. Short but the emotional heart of the film.

**Lines:** 4

### Scene 1

*The moment:* The film opens at Kenya's wedding. The photographer calls the family in, and the bride's mother, Ms. Dee, 56, slips out of the frame again. Then a flashback to June 2009: Ms. Dee rushes from a double shift to her daughter's eighth-grade graduation, still in her scrubs and sweating under the gym lights, and 14-year-old Kenya, embarrassed in front of her friends, asks her to stand in the back.

**D1** · on camera (we match the mouth to your read)

*Cue, the line before yours:* Photographer: "Family of the bride! Everybody in!"

> "Take it without me, baby."

- **How to say it:** Soft, practiced, a smile that doesn't reach her eyes. She's said this a hundred times.
- **What it has to make people feel:** The gut punch: a mother removing herself from her own family picture.

### Scene 8

*The moment:* Ms. Dee takes the washcloth and washes her grown daughter's face herself.

**D2** · voice-over

> "Let me."

- **How to say it:** Barely above a whisper, holding out her hand.
- **What it has to make people feel:** The mother steps forward: the turn of the whole film.

**D3** · voice-over

*Cue, the line before yours:* Ms. Faye: "Same soap. Other side of the ocean."

> "I should've done this a long time ago."

- **How to say it:** Soft, while washing. Her apology without saying sorry.
- **What it has to make people feel:** The first emotional peak; the wound starts to close.

### Scene 10

*The moment:* Thirty nights later. Everyone has changed something, and Ms. Dee looks at herself in the mirror.

**D4** · voice-over

*Cue, the line before yours:* Ms. Faye: "And her mama took the longest to believe. Thirty nights. Then she did."

> "There you are."

- **How to say it:** Whispered to her own reflection.
- **What it has to make people feel:** She sees herself again. Second-highest emotional moment.

## Simone

**Maid of honor, 42, bank vice president.** A polished, professional voice that cracks when someone sees through it. 7 lines, 2 on camera.

**Lines:** 7

### Scene 3

*The moment:* 5:30 a.m. Simone, 42, a bank vice president, does her full face and hair like she's suiting up for battle. At 2 p.m. she's in the office bathroom touching it up while a colleague compliments her.

**S1** · on camera (we match the mouth to your read)

*Cue, the line before yours:* Ms. Faye: "Five-thirty in the morning, and Simone's already suiting up."

> "Armor on."

- **How to say it:** Whispered to the mirror. Resolve, no joy.
- **What it has to make people feel:** One word explains why she does it: it's survival at work.

**S2** · voice-over

*Cue, the line before yours:* Office colleague: "Girl, you always look so put together."

> "Thanks, girl."

- **How to say it:** Bright on the surface; the smile drops when the door closes.
- **What it has to make people feel:** The mask between who she is and who she has to be.

**S3** · voice-over

*Cue, the line before yours:* Ms. Faye: "New bump? Cover it. Long day? Layer it. Fall asleep in it. Then do it all again."

> "Armor on."

- **How to say it:** Next morning. Same words, wearier.
- **What it has to make people feel:** Repetition shows the cycle with no way out.

### Scene 4

*The moment:* Ms. Faye's makeup chair, the week before the wedding. Ms. Faye sees the layers on Kenya's skin and the bumps at her hairline, Simone admits she sleeps in her makeup, and the groomsmen tease the groom.

**S4** · voice-over

*Cue, the line before yours:* Kenya: "...Since nursing school."

> "Don't even start. Full face, ten hours a day, and it's gone by two."

- **How to say it:** Brisk, joking to deflect.
- **What it has to make people feel:** Relatable professional humor.

**S5** · on camera (we match the mouth to your read)

> "Don't. Nobody at work has seen my real skin in fifteen years."

- **How to say it:** The voice cracks halfway. Her hand covers her jaw.
- **What it has to make people feel:** The quiet emotional hit for every professional woman.

**S6** · voice-over

*Cue, the line before yours:* Ms. Faye: "And at night?"

> "...I sleep in it more than I'd admit."

- **How to say it:** A small, ashamed laugh.
- **What it has to make people feel:** The habit dermatologists warn about, said out loud.

### Scene 10

*The moment:* Thirty nights later. Everyone has changed something, and Ms. Dee looks at herself in the mirror.

**S7** · voice-over

*Cue, the line before yours:* Monday colleague: "Did you change something?"

> "I took something off."

- **How to say it:** Calm, smiling, lighter makeup.
- **What it has to make people feel:** Her freedom in four words.

## Jordan, 16

**Kenya's niece.** Excited, copies everything Auntie does. An adult who can sound sixteen, or AI.

**Lines:** 3

### Scene 2

*The moment:* Today. Kenya, now 31 and an ICU nurse, films a glass-skin get-ready video for her wedding countdown. Her niece Jordan copies every word. After a twelve-hour shift, Kenya sits alone in her car and breaks.

**J1** · voice-over

*Cue, the line before yours:* Ms. Faye: "Eleven bottles. Six hundred dollars. Chasing the same shine she was ashamed of at fourteen."

> "Step seven... seal it in."

- **How to say it:** Whispered to her own mirror, copying Kenya word for word.
- **What it has to make people feel:** Chilling echo: it's being passed down again, right now.

### Scene 4

*The moment:* Ms. Faye's makeup chair, the week before the wedding. Ms. Faye sees the layers on Kenya's skin and the bumps at her hairline, Simone admits she sleeps in her makeup, and the groomsmen tease the groom.

**J2** · voice-over

*Cue, the line before yours:* Simone: "...I sleep in it more than I'd admit."

> "Do mine just like Auntie's!"

- **How to say it:** Excited, bouncing in the chair.
- **What it has to make people feel:** The niece wants to copy the problem.

### Scene 10

*The moment:* Thirty nights later. Everyone has changed something, and Ms. Dee looks at herself in the mirror.

**J3** · voice-over

*Cue, the line before yours:* Kenya: "Y'all... I been doing too much."

> "Wash my edges every night. Auntie said."

- **How to say it:** Proud, at the sink.
- **What it has to make people feel:** The cycle breaks for the next generation.

## Marcus

**The groom, 33.** Easy, funny, a little clueless. 1 line.

**Lines:** 1

### Scene 10

*The moment:* Thirty nights later. Everyone has changed something, and Ms. Dee looks at herself in the mirror.

**M1** · voice-over

*Cue, the line before yours:* Simone: "I took something off."

> "Babe, where my oil go?"

- **How to say it:** Searching the bathroom.
- **What it has to make people feel:** A laugh, and men use it too.

## Groomsman

**Young Black man, dry comic timing.** 1 line.

**Lines:** 1

### Scene 4

*The moment:* Ms. Faye's makeup chair, the week before the wedding. Ms. Faye sees the layers on Kenya's skin and the bumps at her hairline, Simone admits she sleeps in her makeup, and the groomsmen tease the groom.

**G1** · voice-over

*Cue, the line before yours:* Ms. Faye: "Mm-mm. What you put on your hair don't stay on your hair."

> "Bro. Your ankles."

- **How to say it:** Dead serious, comic timing.
- **What it has to make people feel:** A laugh for the men, and ashiness named.

## Photographer

**Wedding photographer.** Bright, busy, calling across a crowd. 2 lines.

**Lines:** 2

### Scene 1

*The moment:* The film opens at Kenya's wedding. The photographer calls the family in, and the bride's mother, Ms. Dee, 56, slips out of the frame again. Then a flashback to June 2009: Ms. Dee rushes from a double shift to her daughter's eighth-grade graduation, still in her scrubs and sweating under the gym lights, and 14-year-old Kenya, embarrassed in front of her friends, asks her to stand in the back.

**P1** · voice-over

*Cue, the line before yours:* Ms. Faye: "Every family's got a picture. And some of us been hiding from ours for years."

> "Family of the bride! Everybody in!"

- **How to say it:** Bright, busy, slightly off-mic.
- **What it has to make people feel:** Sets the place and the stakes in one call.

### Scene 11

*The moment:* The wedding. The photographer calls the family in again, and this time Kenya pulls her mother to the front.

**P2** · voice-over

> "Family of the bride!"

- **How to say it:** Same call as the opening.
- **What it has to make people feel:** The setup returns.

## Office colleague

**Simone's coworker.** Friendly and sincere. 1 line.

**Lines:** 1

### Scene 3

*The moment:* 5:30 a.m. Simone, 42, a bank vice president, does her full face and hair like she's suiting up for battle. At 2 p.m. she's in the office bathroom touching it up while a colleague compliments her.

**C1** · voice-over

*Cue, the line before yours:* Ms. Faye: "She don't wear makeup. She wears armor. 'Cause the room she walks in don't forgive."

> "Girl, you always look so put together."

- **How to say it:** Friendly, sincere, at the next sink.
- **What it has to make people feel:** Shows the praise that keeps the armor on.

## Monday colleague

**Another coworker.** Curious, impressed. 1 line.

**Lines:** 1

### Scene 10

*The moment:* Thirty nights later. Everyone has changed something, and Ms. Dee looks at herself in the mirror.

**C2** · voice-over

*Cue, the line before yours:* Jordan, 16: "Wash my edges every night. Auntie said."

> "Did you change something?"

- **How to say it:** Curious, impressed.
- **What it has to make people feel:** Others notice.

## Wedding guest

**A guest at the wedding.** Leans in, half whisper. 1 line.

**Lines:** 1

### Scene 11

*The moment:* The wedding. The photographer calls the family in again, and this time Kenya pulls her mother to the front.

**GU1** · voice-over

*Cue, the line before yours:* Kenya: "Mama, I asked you to stand in the back once. Never again."

> "Okay... what's the routine?"

- **How to say it:** Leaning in, half whisper.
- **What it has to make people feel:** The stranger asks: social proof.

## How to record

- **Where:** a quiet room with soft surfaces. A closet full of clothes works well. No fans, AC, TV or music.
- **Mic:** a good USB mic if you have one; otherwise a phone voice-memo app at its highest quality. Keep the mic about 6 to 8 inches from your mouth, slightly off to the side.
- **Takes:** three takes of every line, each one a little different. Say the line ID before each take ("K1, take one"), then pause two seconds before the line.
- **Files:** WAV if possible (48 kHz), otherwise the original phone file. Name it with the role and line ID, for example "Kenya_K1.wav". Don't add effects, music or noise removal; we match every voice to one room afterward.
- **Lines marked on camera:** just play them naturally. We match the animated character's mouth to your recording.
