**The film:** *Forever Pictures*, a short animated film (Pixar-style 3D) for YO Skincare, a Black-owned, plant-based skincare brand. A mother has stood in the back of every family picture for seventeen years. At her daughter's wedding, she finally gets in the picture. The story is told by Ms. Faye, a makeup artist who has seen every woman, at every stage, in her chair.

A short role: three lines, one of them on camera.

## Ghana elder

**Who she is:** a Ghanaian woman in her 70s who has made black soap by hand her whole life, the way her grandmother taught her. A visitor from America has come to learn.

**Voice:** an older Ghanaian woman speaking English with her natural accent. Slow, certain, a little dry humor. She doesn't hurry and she doesn't need to convince anyone.

**Optional:** if you'd like to also record E3 in Twi or your own language, please do. We may use it with subtitles.

**Lines:** 3

### Scene 7

*The moment:* The origin. An elder soap maker in Ghana and a black seed farmer in Ethiopia. Back in the chair, Ms. Faye explains what makes this soap different.

**E1** · on camera (we match the mouth to your read)

*Cue, the line before yours:* Ms. Faye: "So he went to the source."

> "You want it fast, or you want it right?"

- **How to say it:** Slow, certain, looking straight at him.
- **What it has to make people feel:** The film's philosophy against eleven steps.

**E2** · voice-over

*Cue, the line before yours:* Amin: "Right."

> "Then you wait."

- **How to say it:** A small smile.
- **What it has to make people feel:** Craft, patience, quality.

**E3** · voice-over

> "My grandmother washed me with this. I washed her mother."

- **How to say it:** Over her washing her granddaughter's face. Tender.
- **What it has to make people feel:** Heritage: this is our original skincare.

## How to record

- **Where:** a quiet room with soft surfaces. A closet full of clothes works well. No fans, AC, TV or music.
- **Mic:** a good USB mic if you have one; otherwise a phone voice-memo app at its highest quality. Keep the mic about 6 to 8 inches from your mouth, slightly off to the side.
- **Takes:** three takes of every line, each one a little different. Say the line ID before each take ("F12, take one"), then pause two seconds before the line.
- **Files:** WAV if possible (48 kHz), otherwise the original phone file. Name it with the role and line ID, for example "MsFaye_F12.wav". Don't add effects, music or noise removal; we match every voice to one room afterward.
- **Lines marked on camera:** just play them naturally. We match the animated character's mouth to your recording.
