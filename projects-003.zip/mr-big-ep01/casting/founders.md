**The film:** *Forever Pictures*, a short animated film (Pixar-style 3D) for YO Skincare, a Black-owned, plant-based skincare brand. A mother has stood in the back of every family picture for seventeen years. At her daughter's wedding, she finally gets in the picture. The story is told by Ms. Faye, a makeup artist who has seen every woman, at every stage, in her chair.

These are the founders' own lines, in your own voices. All of them play over the picture, so nobody needs to match a mouth. Speak the way you'd tell a friend at the tent.

## Amin

**You:** the founder, fifteen years in the business. Calm, honest, a man who has seen behind the counter and decided to do it right.

**Lines:** 4

### Scene 6

*The moment:* Ms. Faye introduces the couple who make the black soap she uses. The founders explain why they made it.

**A1** · voice-over

*Cue, the line before yours:* Ms. Faye: "Not all black soap is the same. I asked the folks who make this one."

> "Fifteen years in this business, I watched them sell us more steps, smaller bottles, and labels nobody reads."

- **How to say it:** Calm, honest, a man who's seen behind the counter.
- **What it has to make people feel:** Insider truth builds trust.

**A2** · voice-over

> "Hair products that never once thought about our skin. So I went and got it myself."

- **How to say it:** Resolve on 'got it myself.'
- **What it has to make people feel:** Why YO exists, and the founder's commitment.

### Scene 7

*The moment:* The origin. An elder soap maker in Ghana and a black seed farmer in Ethiopia. Back in the chair, Ms. Faye explains what makes this soap different.

**A3** · voice-over

*Cue, the line before yours:* Ghana elder: "You want it fast, or you want it right?"

> "Right."

- **How to say it:** Quiet, respectful.
- **What it has to make people feel:** His values in one word.

### Scene 9

*The moment:* The rest of the routine: the facial oil and the body oil. Ms. Faye names every oil, and Kenya tests her wedding dress.

**A4** · voice-over

*Cue, the line before yours:* Kenya: "Co-pai-what?"

> "I didn't fly to the Amazon for this one. I studied it till I knew exactly why it belonged."

- **How to say it:** Honest, a little pride.
- **What it has to make people feel:** Point of difference, stated truthfully.

## Kimmy

**You:** co-founder, raised in your mother's esthetics room. Warm, proud and simple. Please confirm you're comfortable saying your mother is a master esthetician; if you'd like different words, tell me and I'll rewrite it.

**Lines:** 2

### Scene 6

*The moment:* Ms. Faye introduces the couple who make the black soap she uses. The founders explain why they made it.

**KM1** · voice-over

*Cue, the line before yours:* Amin: "Hair products that never once thought about our skin. So I went and got it myself."

> "I grew up in my mother's esthetics room. She's a master esthetician."

- **How to say it:** Warm, proud, smiling.
- **What it has to make people feel:** Expert lineage: real skin knowledge.

**KM2** · voice-over

> "Every woman who sat in her chair, she washed first. Then she fed the skin. That's how we built YO."

- **How to say it:** Simple, loving.
- **What it has to make people feel:** The method in one line: wash first, then feed.

## How to record

- **Where:** a quiet room with soft surfaces. A closet full of clothes works well. No fans, AC, TV or music.
- **Mic:** a good USB mic if you have one; otherwise a phone voice-memo app at its highest quality. Keep the mic about 6 to 8 inches from your mouth, slightly off to the side.
- **Takes:** three takes of every line, each one a little different. Say the line ID before each take ("F12, take one"), then pause two seconds before the line.
- **Files:** WAV if possible (48 kHz), otherwise the original phone file. Name it with the role and line ID, for example "MsFaye_F12.wav". Don't add effects, music or noise removal; we match every voice to one room afterward.
- **Lines marked on camera:** just play them naturally. We match the animated character's mouth to your recording.
