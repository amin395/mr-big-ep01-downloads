**The film:** *Forever Pictures*, a short animated film (Pixar-style 3D) for YO Skincare, a Black-owned, plant-based skincare brand. A mother has stood in the back of every family picture for seventeen years. At her daughter's wedding, she finally gets in the picture. The story is told by Ms. Faye, a makeup artist who has seen every woman, at every stage, in her chair.

This is the lead voice. Ms. Faye carries about 60% of the film's audio.

## Ms. Faye

**Who she is:** a Black makeup artist in her mid-50s, Atlanta, 25 years behind her chair. She has done the faces of brides, prom girls, nurses and executives. The auntie everybody trusts to tell them the truth.

**Voice:** low-to-mid alto with a smile in it. Southern and Atlanta warm, unhurried, close to the mic, as if she's talking just to you. Humor right under the surface. Never an announcer voice, never preachy.

**Two modes:** her narration is spoken word, with rhythm and a little rhyme. When she talks to someone in her chair, it's plain talk, the way you'd tell a niece the truth.

**Lines:** 42

### Scene 1

*The moment:* The film opens at Kenya's wedding. The photographer calls the family in, and the bride's mother, Ms. Dee, 56, slips out of the frame again. Then a flashback to June 2009: Ms. Dee rushes from a double shift to her daughter's eighth-grade graduation, still in her scrubs and sweating under the gym lights, and 14-year-old Kenya, embarrassed in front of her friends, asks her to stand in the back.

**F1** · voice-over

> "Every family's got a picture. And some of us been hiding from ours for years."

- **How to say it:** Warm, a little knowing, like starting a story on the porch.
- **What it has to make people feel:** Hooks the viewer in five seconds: this is about family, not a product.

**F2** · voice-over

*Cue, the line before yours:* Ms. Dee: "Take it without me, baby."

> "Seventeen years she been stepping out of frame. Let me tell you where it started."

- **How to say it:** Slower. The music drops under her.
- **What it has to make people feel:** Turns curiosity into a promise: you need to know why.

**F3** · voice-over

> "June, two thousand nine. A double shift behind her, still in her scrubs. Sweat on her brow, and the grease on her edges giving up in the heat."

- **How to say it:** Rhythmic, tender, no judgment of Ms. Dee.
- **What it has to make people feel:** Grounds the shine in work and heat, not vanity. Every working mother feels it.

**F4** · voice-over

*Cue, the line before yours:* Kenya, 14: "Mama... can you stand in the back?"

> "Kids say things quick. Mamas carry them long. She stood in the back. And that's where she stayed."

- **How to say it:** Quiet, almost a whisper on the last line.
- **What it has to make people feel:** The cost lands: seventeen years of pictures.

### Scene 2

*The moment:* Today. Kenya, now 31 and an ICU nurse, films a glass-skin get-ready video for her wedding countdown. Her niece Jordan copies every word. After a twelve-hour shift, Kenya sits alone in her car and breaks.

**F5** · voice-over

> "Now that baby's thirty-one. An ICU nurse, just like her mama. She takes care of everybody. Every body but her own."

- **How to say it:** Pride, then a beat of sadness on 'her own.'
- **What it has to make people feel:** Respect for Black women in healthcare, and the irony that sets up the problem.

**F6** · voice-over

*Cue, the line before yours:* Kenya: "Okay y'all, wedding countdown! Step seven: seal it in."

> "Eleven bottles. Six hundred dollars. Chasing the same shine she was ashamed of at fourteen."

- **How to say it:** Dry, a little rueful.
- **What it has to make people feel:** The irony that runs the film: grease then, glass now.

**F7** · voice-over

*Cue, the line before yours:* Jordan, 16: "Step seven... seal it in."

> "Somebody's always watching."

- **How to say it:** Low and simple.
- **What it has to make people feel:** The stakes move to the next generation.

**F8** · voice-over

*Cue, the line before yours:* Kenya: "I did everything they said."

> "Everything they said. Nobody said what was underneath."

- **How to say it:** Gentle, sets up the truth.
- **What it has to make people feel:** Promise of an answer.

### Scene 3

*The moment:* 5:30 a.m. Simone, 42, a bank vice president, does her full face and hair like she's suiting up for battle. At 2 p.m. she's in the office bathroom touching it up while a colleague compliments her.

**F9** · voice-over

> "Five-thirty in the morning, and Simone's already suiting up."

- **How to say it:** Crisp, matching the rhythm of the flat iron and brushes.
- **What it has to make people feel:** Introduces the professional woman with respect.

**F10** · voice-over

*Cue, the line before yours:* Simone: "Armor on."

> "She don't wear makeup. She wears armor. 'Cause the room she walks in don't forgive."

- **How to say it:** Proud and protective, a little edge on 'don't forgive.'
- **What it has to make people feel:** Every corporate Black woman feels seen.

**F11** · voice-over

*Cue, the line before yours:* Simone: "Thanks, girl."

> "New bump? Cover it. Long day? Layer it. Fall asleep in it. Then do it all again."

- **How to say it:** Rhythmic, faster, like a treadmill.
- **What it has to make people feel:** The cover-up cycle in four beats.

### Scene 4

*The moment:* Ms. Faye's makeup chair, the week before the wedding. Ms. Faye sees the layers on Kenya's skin and the bumps at her hairline, Simone admits she sleeps in her makeup, and the groomsmen tease the groom.

**F12** · voice-over

*Cue, the line before yours:* Kenya: "But my skin's healthy. Look at the glow!"

> "Baby, that ain't glow. That's layers."

- **How to say it:** Kind but firm. No laugh. Truth.
- **What it has to make people feel:** The headline truth of the film.

**F13** · voice-over

> "And these little bumps at your hairline? How long you been covering these?"

- **How to say it:** Softer, concerned, lifting Kenya's edges.
- **What it has to make people feel:** Names the hidden problem without shaming.

**F14** · voice-over

*Cue, the line before yours:* Simone: "Don't. Nobody at work has seen my real skin in fifteen years."

> "Baby, I've seen it. It's beautiful. It's just tired of carrying all that."

- **How to say it:** Very gentle. She lowers Simone's hand.
- **What it has to make people feel:** Compassion: her skin isn't the problem, the load is.

**F15** · voice-over

> "And at night?"

- **How to say it:** Knowing.
- **What it has to make people feel:** Sets up the confession.

**F16** · voice-over

*Cue, the line before yours:* Jordan, 16: "Do mine just like Auntie's!"

> "Mm-mm. What you put on your hair don't stay on your hair."

- **How to say it:** Holds up a finger shiny with edge gel. Playful, then pointed.
- **What it has to make people feel:** Edge control lands on the skin: the line people will quote.

**F17** · on camera (we match the mouth to your read)

*Cue, the line before yours:* Groomsman: "Bro. Your ankles."

> "Your mama called it grease. Your phone calls it glass. Baby, it's the same layers."

- **How to say it:** Holding the 2009 photo. Slow, every word placed.
- **What it has to make people feel:** The thesis of the film connecting two generations.

### Scene 5

*The moment:* Ms. Faye sets her brush down and talks about every woman she has seen in 25 years: a montage of portraits, from the prom girl to the grandmother.

**F18** · voice-over

*Cue, the line before yours:* Kenya: "So my mama was wrong... and I'm wrong too?"

> "Twenty-five years in this chair, I've seen every stage."

- **How to say it:** She sets her brush down. Calm authority.
- **What it has to make people feel:** Her credibility as the woman who has seen it all.

**F19** · voice-over

> "The prom girl with her edges laid like glue. The college girl in a shade that wasn't hers. The new mama who ain't washed her face since the baby came. The nurse off a night shift. The boss who never takes it off. The grandmama still using her mama's jar."

- **How to say it:** Over the portrait montage, one image per line, music swelling slightly.
- **What it has to make people feel:** Every woman at every life stage finds herself.

**F20** · voice-over

> "Different ages. Different jobs. Same story. We pile it on, 'cause nobody ever gave us the right thing to take it off."

- **How to say it:** Strong, a little anger for the women, not at them.
- **What it has to make people feel:** The big reframe: the problem is what was missing.

**F21** · voice-over

> "Your mama wasn't wrong, baby. Nobody made it for us. Not for our skin, not for our shifts, not for our sweat. So we made do. Grease was making do."

- **How to say it:** Tender. 'Making do' with love.
- **What it has to make people feel:** Absolution: shame becomes understanding.

**F22** · voice-over

> "And them videos? Most of 'em never even asked what kind of skin you got."

- **How to say it:** Dry, a little shade.
- **What it has to make people feel:** Credibility: those videos never thought about her skin.

**F23** · voice-over

> "You ain't doing too little. You doing too much of the wrong thing."

- **How to say it:** Clear and final.
- **What it has to make people feel:** Sets up the answer: start with the wash.

### Scene 6

*The moment:* Ms. Faye introduces the couple who make the black soap she uses. The founders explain why they made it.

**F24** · voice-over

*Cue, the line before yours:* Kenya: "Black soap? Mama's bars dried us out."

> "Not all black soap is the same. I asked the folks who make this one."

- **How to say it:** Confident, a little secret.
- **What it has to make people feel:** Transition to the founders.

**F25** · voice-over

*Cue, the line before yours:* Kimmy: "Every woman who sat in her chair, she washed first. Then she fed the skin. That's how we built YO."

> "Folks who know the business. Folks who know the skin."

- **How to say it:** Approval.
- **What it has to make people feel:** Seals trust.

### Scene 7

*The moment:* The origin. An elder soap maker in Ghana and a black seed farmer in Ethiopia. Back in the chair, Ms. Faye explains what makes this soap different.

**F26** · voice-over

> "So he went to the source."

- **How to say it:** Anticipation; music opens wide.
- **What it has to make people feel:** Launches the journey.

**F27** · voice-over

*Cue, the line before yours:* Ethiopian farmer: "Tikur azmud."

> "Black seed. Treasured for thousands of years. They even found it in King Tut's tomb. Rich in antioxidants, and it's in every YO bottle."

- **How to say it:** Wonder.
- **What it has to make people feel:** Value and heritage of the hero ingredient.

**F28** · voice-over

> "Your mama's bars dried you out 'cause plain black soap is just black soap. This one's got three things plain don't."

- **How to say it:** Back in the chair, counting on her fingers.
- **What it has to make people feel:** Answers the objection and sets up the trio.

**F29** · voice-over

> "Sea moss: a mineral cushion, so you rinse soft, not tight. Black seed: smooth and nourished, even while you wash. And jojoba. It ain't even really an oil, baby. It's a liquid wax, close to what your own skin makes."

- **How to say it:** One finger per ingredient, a beat between each.
- **What it has to make people feel:** The YO trio: what makes this soap different.

**F30** · voice-over

*Cue, the line before yours:* Kenya: "Huh. It don't feel tight."

> "Cleanses deep. Exfoliates. Tones. And you don't walk away stripped."

- **How to say it:** Satisfied, like a closing argument.
- **What it has to make people feel:** The Triple-Action promise.

### Scene 8

*The moment:* Ms. Dee takes the washcloth and washes her grown daughter's face herself.

**F31** · voice-over

*Cue, the line before yours:* Ms. Dee: "Let me."

> "Same soap. Other side of the ocean."

- **How to say it:** Whispered, music almost gone.
- **What it has to make people feel:** Ties the wash to the elder in Ghana: love handed down.

### Scene 9

*The moment:* The rest of the routine: the facial oil and the body oil. Ms. Faye names every oil, and Kenya tests her wedding dress.

**F32** · voice-over

> "Now we feed it. Ten oils. Two drops."

- **How to say it:** Lift in energy as the beat comes in.
- **What it has to make people feel:** Step two: replenish.

**F33** · voice-over

> "Rosehip to smooth. Turmeric to brighten. Argan and almond, vitamin E. Calendula to soothe. Grapeseed, light as air. Jojoba and black seed, the family. And copaiba."

- **How to say it:** Rhythmic roll call on the beat, one oil per cut.
- **What it has to make people feel:** Every ingredient's job, building value.

**F34** · voice-over

*Cue, the line before yours:* Amin: "I didn't fly to the Amazon for this one. I studied it till I knew exactly why it belonged."

> "Bet you never heard of it. That's the point."

- **How to say it:** A wink in the voice.
- **What it has to make people feel:** Exclusivity.

**F35** · voice-over

> "Glass sits on top. This sinks in."

- **How to say it:** Simple contrast over the side-by-side.
- **What it has to make people feel:** Glass versus glow, explained in six words.

**F36** · voice-over

> "Now THAT'S a canvas."

- **How to say it:** Delighted, brush gliding.
- **What it has to make people feel:** The payoff for makeup wearers: it holds.

**F37** · voice-over

> "Then the body. Seven oils, face to feet. Absorbs fast."

- **How to say it:** Smooth, confident.
- **What it has to make people feel:** Head-to-toe value.

**F38** · voice-over

*Cue, the line before yours:* Kenya: "Not a mark on this dress."

> "Ghana in the wash. Ethiopia in every bottle. A little Amazon in the glow. Mixed and bottled right here at home. Twenty plant ingredients. Three bottles. Face to feet. Thirty-seven ninety-seven."

- **How to say it:** Building like a closing chant, the price said plainly.
- **What it has to make people feel:** Origins, plant-based, made in America, and the price.

### Scene 10

*The moment:* Thirty nights later. Everyone has changed something, and Ms. Dee looks at herself in the mirror.

**F39** · voice-over

> "Thirty nights."

- **How to say it:** Calm.
- **What it has to make people feel:** Time passing.

**F40** · voice-over

*Cue, the line before yours:* Kenya: "What oil?"

> "And her mama took the longest to believe. Thirty nights. Then she did."

- **How to say it:** Very tender.
- **What it has to make people feel:** Ms. Dee's own change, so the ending is earned.

### Scene 11

*The moment:* The wedding. The photographer calls the family in again, and this time Kenya pulls her mother to the front.

**F41** · on camera (we match the mouth to your read)

*Cue, the line before yours:* Wedding guest: "Okay... what's the routine?"

> "It ain't your skin. It ain't your fault. It's what you stacked on it. Wash it off. Feed it right. Then get in the picture."

- **How to say it:** To camera, direct, warm, unhurried.
- **What it has to make people feel:** The message and the call to action.

**F42** · voice-over

> "YO. Your Original Skincare. The Complete Routine, thirty-seven ninety-seven. Online, or at your beauty supply."

- **How to say it:** Over the end card, clear and friendly.
- **What it has to make people feel:** What to buy, the price and where.

## How to record

- **Where:** a quiet room with soft surfaces. A closet full of clothes works well. No fans, AC, TV or music.
- **Mic:** a good USB mic if you have one; otherwise a phone voice-memo app at its highest quality. Keep the mic about 6 to 8 inches from your mouth, slightly off to the side.
- **Takes:** three takes of every line, each one a little different. Say the line ID before each take ("F12, take one"), then pause two seconds before the line.
- **Files:** WAV if possible (48 kHz), otherwise the original phone file. Name it with the role and line ID, for example "MsFaye_F12.wav". Don't add effects, music or noise removal; we match every voice to one room afterward.
- **Lines marked on camera:** just play them naturally. We match the animated character's mouth to your recording.
