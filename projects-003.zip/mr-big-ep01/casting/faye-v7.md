**The film:** *Forever Pictures*, a short animated film (Pixar-style 3D) for YO Skincare, a Black-owned, plant-based skincare brand. A mother has stood in the back of every family picture for seventeen years. At her daughter's wedding, she finally gets in the picture. An original anthem carries the emotion, and Ms. Faye tells the whole story.

**This is the lead voice.** Ms. Faye is the only narrator. She tells the story, says what the other characters said, and explains the products. Almost every spoken word in the film is hers.

## Ms. Faye

**Who she is:** a Black makeup artist in her mid-50s, Atlanta, 25 years behind her chair. She has done the faces of brides, prom girls, nurses and executives. The auntie everybody trusts to tell them the truth.

**Voice:** low-to-mid alto with a smile in it. Southern and Atlanta warm, unhurried, close to the mic, as if she's talking just to you. Humor right under the surface. Never an announcer voice, never preachy.

**Three modes:**
- **Storytelling:** spoken word with rhythm, over music. Let the music breathe between lines.
- **Quoting someone:** when she says what another character said, she shifts her voice only slightly, the way you'd retell a story on the porch. No impressions.
- **Product talk:** confident and rhythmic, like a roll call. Every word clear.

**Lines:** 40. Most play over the picture; two are on camera, where we match the animated mouth to your recording.

### Scene 1: the picture she keeps walking out of

*The moment:* the film opens at a wedding. The photographer calls the family in, and the bride's mother, Ms. Dee, slips out of the frame again: "Take it without me, baby."

**F1** · voice-over

> "Every family's got a picture. And some of us been hiding from ours for years."

- **How to say it:** warm and knowing, like starting a story on the porch.
- **What it has to make people feel:** this is about family. Lean in.

**F2** · voice-over

> "Seventeen years she been stepping out of frame. Let me tell you where it started."

- **How to say it:** slower. The music drops under you.
- **What it has to make people feel:** you need to know why.

*The moment:* flashback to June 2009. Ms. Dee comes straight from a double shift to her daughter's eighth-grade graduation, still in scrubs.

**F3** · voice-over

> "June, two thousand nine. A double shift behind her, still in her scrubs. Sweat on her brow, and the grease on her edges giving up in the heat."

- **How to say it:** rhythmic and tender, no judgment of Ms. Dee.
- **What it has to make people feel:** the shine came from work and heat, not vanity.

*Then 14-year-old Kenya says, "Mama... can you stand in the back?"*

**F4** · voice-over

> "Kids say things quick. Mamas carry them long."

- **How to say it:** quiet, almost a whisper on "long."
- **What it has to make people feel:** the cost of one careless sentence.

### Scene 2: the back row

*The moment:* the anthem plays over seventeen years of photos, then Kenya, now 31, an ICU nurse filming a glass-skin video. The song cuts out on her crying alone in her car after a twelve-hour shift.

**F5** · voice-over, as the song begins

> "Now that baby's thirty-one. An ICU nurse, just like her mama. She takes care of everybody. Every body but her own."

- **How to say it:** pride, then a beat of sadness on "her own."
- **What it has to make people feel:** respect for Black women in healthcare, and the irony.

**F6** · voice-over, over her eleven-bottle routine

> "Eleven bottles. Six hundred dollars. Chasing the same shine she was ashamed of at fourteen."

- **How to say it:** dry, a little rueful.
- **What it has to make people feel:** grease then, glass now: the same mistake, more expensive.

**F7** · voice-over, into the silence in the car

> "She did everything they said. Nobody said what was underneath."

- **How to say it:** gentle and close, as if you're sitting in the passenger seat.
- **What it has to make people feel:** there's an answer coming.

### Scene 3: the armor

*The moment:* Simone, 42, a bank vice president, suits up at 5:30 a.m. and touches up in the office bathroom at 2 p.m. The song breaks off on her face in the mirror.

**F8** · voice-over

> "She don't wear makeup. She wears armor. 'Cause the room she walks in don't forgive."

- **How to say it:** proud and protective, a little edge on "don't forgive."
- **What it has to make people feel:** every professional Black woman feels seen.

**F9** · voice-over

> "New bump? Cover it. Long day? Layer it. Fall asleep in it. Then do it all again."

- **How to say it:** rhythmic and a little faster, like a treadmill.
- **What it has to make people feel:** the cover-up cycle, with no way out.

### Scene 4: the chair

*The moment:* Ms. Faye's makeup chair, the week before the wedding.

**F10** · voice-over

> "Kenya sat down proud. 'Look at my glow.' Baby, that ain't glow. That's buildup."

- **How to say it:** a light, proud voice for Kenya's words, then kind but firm on "that's buildup."
- **What it has to make people feel:** the headline truth of the film.

**F11** · voice-over

> "I lifted her edges. Saw them little bumps at the hairline. I said, 'How long?' She said, 'Since nursing school.'"

- **How to say it:** softer, concerned. A small pause before "since nursing school."
- **What it has to make people feel:** years of hiding in two words.

**F12** · voice-over

> "Mm-mm. What you put on your hair don't stay on your hair."

- **How to say it:** playful, then pointed. This is the line people will quote.
- **What it has to make people feel:** "oh... that's me."

**F13** · voice-over

> "Simone said, 'Full face, ten hours a day, and it's gone by two.' I said, and at night? She laughed. 'I sleep in it more than I'd admit. Nobody at work has seen my real skin in fifteen years.'"

- **How to say it:** her joke first, then let the laugh fall away on "fifteen years."
- **What it has to make people feel:** the professional woman's secret, said out loud.

**F14** · voice-over

> "I told her, baby, I've seen it. It's beautiful. It's just tired of carrying all that."

- **How to say it:** very gentle. Slow down on "it's beautiful."
- **What it has to make people feel:** her skin isn't the problem; the load is.

**F15** · on camera (we match the mouth to your read)

> "Your mama called it grease. Your phone calls it glass. Baby, it's the same buildup."

- **How to say it:** holding up the old 2009 photo. Slow, every word placed.
- **What it has to make people feel:** the thesis of the film, connecting two generations.

### Scene 5: every stage

*The moment:* a fast montage of portraits, one image per line.

**F16** · voice-over

> "Twenty-five years in this chair, I've seen every stage. The prom girl with her edges laid like glue. The new mama who ain't washed her face since the baby came. The nurse off a night shift. The boss who never takes it off. The grandmama still using her mama's jar."

- **How to say it:** calm authority, one beat per portrait, the music swelling slightly.
- **What it has to make people feel:** every woman, at every stage, finds herself.

**F17** · voice-over

> "Different ages. Same story. We pile it on, 'cause nobody ever gave us the right thing to take it off. Nobody made it for us. Not for our skin, not for our shifts, not for our sweat."

- **How to say it:** a little fire for the women, not at them.
- **What it has to make people feel:** the problem was what was missing, not her.

**F18** · voice-over

> "Your mama wasn't wrong, baby. Grease was making do."

- **How to say it:** tender. Say "making do" with love.
- **What it has to make people feel:** the shame turns into understanding.

**F19** · voice-over

> "And them videos? Most of 'em never even asked what kind of skin you got. You ain't doing too little. You doing too much of the wrong thing."

- **How to say it:** dry, a little shade, then clear and final.
- **What it has to make people feel:** permission to stop, and curiosity about what's right.

### Scene 6: the source

*The moment:* Ms. Faye introduces the couple who make the soap she uses, and the film travels to Ghana and Ethiopia.

**F20** · voice-over

> "Not all black soap is the same. And washing's only half of it. Wash it right, then feed it right. One without the other don't work."

- **How to say it:** confident, like sharing a secret, then firm on "one without the other."
- **What it has to make people feel:** this is a method, not one product.

**F21** · voice-over

> "Him? Fifteen years in this business, watching them sell us more steps, smaller bottles, and hair products that never once thought about our skin. Her? Raised in her mama's esthetics room. Every woman in that chair got washed first, then fed. So he went to the source."

- **How to say it:** approving, a little edge on "never once." Music opens up on "the source."
- **What it has to make people feel:** trust in the people behind the bottle.

*After this, an elder in Ghana says, "You want it fast, or you want it right?" and a farmer in Ethiopia pours black seed into his palm: "Tikur azmud."*

**F22** · voice-over

> "Black seed. Treasured for thousands of years. They even found it in King Tut's tomb. Rich in antioxidants. And it's in every YO bottle."

- **How to say it:** wonder.
- **What it has to make people feel:** this ingredient is special, and it runs through the whole routine.

### Scene 7: the wash

*The moment:* back in the chair. Ms. Faye counts on her fingers.

**F23** · voice-over

> "Your mama's bars dried you out, 'cause plain black soap is just black soap. Theirs is made in Ghana, with three things plain don't have."

- **How to say it:** knowing, a little playful.
- **What it has to make people feel:** the old objection, answered.

**F24** · voice-over

> "Sea moss: a mineral cushion, so you rinse soft, not tight. Black seed: smooth and nourished, even while you wash. And jojoba. It ain't even really an oil, baby. It's a liquid wax, close to what your own skin makes."

- **How to say it:** one finger per ingredient, a beat between each.
- **What it has to make people feel:** what makes this soap different from every other black soap.

**F25** · voice-over

> "It helps lift the buildup: the edge control, the sweat from that double, yesterday's makeup. Cleanses deep. Exfoliates. Tones. Face and body. And you don't walk away stripped."

- **How to say it:** satisfied, like a closing argument.
- **What it has to make people feel:** step one, done right.

**F26** · voice-over

> "Kenya rubbed her hands together. 'Huh. It don't feel tight.' Then she smelled it. 'Is that peppermint?'"

- **How to say it:** amused, as if you knew she'd say that.
- **What it has to make people feel:** proof on her own skin.

*The anthem's bridge plays as Ms. Dee takes the washcloth: "Let me." She washes her grown daughter's face. Then a cut to the elder in Ghana washing her granddaughter's face.*

**F27** · voice-over, a whisper at the end of the bridge

> "Same soap. Other side of the ocean."

- **How to say it:** a whisper, the music almost gone.
- **What it has to make people feel:** love handed down on both sides of the ocean.

### Scene 8: the feed

*The moment:* the beat kicks in, one oil per cut, with shots of two drops sinking into the skin.

**F28** · voice-over

> "Now we feed it. This is where it all comes together. Ten oils. Two drops."

- **How to say it:** a lift in energy as the beat lands.
- **What it has to make people feel:** step two is just as important as step one.

**F29** · voice-over, on the beat

> "Rosehip, for that smooth feel under Simone's foundation. Turmeric, for the bright Kenya was chasing with eleven bottles. Argan and almond, vitamin E, for the new mama running on no sleep. Calendula to soothe, after a long, hot shift. Grapeseed, light as air under a mask. Jojoba and black seed, the family, in every bottle. And copaiba."

- **How to say it:** a rhythmic roll call, one oil per beat.
- **What it has to make people feel:** every ingredient has a job.

**F30** · voice-over

> "Co-pai-what? Exactly. Bet you never heard of it. That's the point. From South America. He studied it till he knew exactly why it belonged."

- **How to say it:** a wink, then sincere on the last sentence.
- **What it has to make people feel:** rare, chosen on purpose.

**F31** · voice-over

> "Glass sits on top. This sinks in. The wash clears the way. The oils feed it and seal the deal."

- **How to say it:** simple contrast, then satisfied.
- **What it has to make people feel:** why both steps matter: glow, not glare.

**F32** · voice-over, brushing on foundation

> "Now THAT'S a canvas."

- **How to say it:** delighted, as an artist.
- **What it has to make people feel:** the payoff for every woman who wears makeup all day.

**F33** · voice-over

> "Then the body. Seven oils, face to feet. Absorbs fast. Even the groom's ankles."

- **How to say it:** smooth, then a laugh on the ankles.
- **What it has to make people feel:** head to toe, for the whole family, men too.

**F34** · voice-over, as Kenya slips on her wedding dress

> "Not a mark on that dress."

- **How to say it:** satisfied, a little proud.
- **What it has to make people feel:** it won't stick to your clothes.

**F35** · voice-over

> "Ghana in the wash. Ethiopia in every bottle. A little South America in the glow. Mixed and bottled right here at home. Twenty plant ingredients. Three bottles. Face to feet. Thirty-seven ninety-seven. And the women who tried it? Five stars. One of 'em just wrote, 'Black gold.'"

- **How to say it:** building like a closing chant. Say the price plainly.
- **What it has to make people feel:** it's real, it's complete, and it's affordable.

### Scene 9: thirty nights

*The moment:* the first full chorus of the anthem over a montage of everyone thirty nights later.

**F36** · voice-over, under the chorus

> "Thirty nights. Wash, then feed. Every night."

- **How to say it:** calm, keeping time with the music.
- **What it has to make people feel:** it's simple enough to keep doing.

**F37** · voice-over

> "And her mama took the longest to believe. Thirty nights. Then she did."

- **How to say it:** very tender, almost under the music.
- **What it has to make people feel:** Ms. Dee's own change, so the ending is earned.

### Scene 10: get in the picture

*The moment:* the wedding portrait. Kenya catches her mother's hand: "Mama, I asked you to stand in the back once. Never again." Flash. The final chorus.

**F38** · on camera (we match the mouth to your read)

> "It ain't your skin. It ain't your fault. It's what you stacked on it. Wash it off. Feed it right. Then get in the picture."

- **How to say it:** straight to camera, direct, warm, unhurried.
- **What it has to make people feel:** the whole message, and permission.

### End card

**F39** · voice-over

> "YO. Your Original Skincare. Black-owned. Family-founded. Wash and feed, face to feet. The Complete Routine, thirty-seven ninety-seven."

- **How to say it:** clear and friendly, over the brand song.
- **What it has to make people feel:** what to buy, and the price.

**F40** · voice-over

> "Online, or at your beauty supply."

- **How to say it:** easy and friendly.
- **What it has to make people feel:** it's easy to get.

## How to record

- **Where:** a quiet room with soft surfaces. A closet full of clothes works well. No fans, AC, TV or music.
- **Mic:** a good USB mic if you have one; otherwise a phone voice-memo app at its highest quality. Keep the mic about 6 to 8 inches from your mouth, slightly off to the side.
- **Takes:** three takes of every line, each one a little different. Say the line ID before each take ("F10, take one"), then pause two seconds before the line.
- **Files:** WAV if possible (48 kHz), otherwise the original phone file. Name it with the line ID, for example "MsFaye_F10.wav". Don't add effects, music or noise removal.
- **On-camera lines (F15, F38):** just play them naturally. We match the animated character's mouth to your recording.
