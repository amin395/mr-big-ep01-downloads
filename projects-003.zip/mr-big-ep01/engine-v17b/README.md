# FOREVER PICTURES mix engine, v17b (exact state of the 08:22 UTC 11-15 master)

Run everything from this folder (engine-v17b/) as the working directory.

## Rebuild the master exactly
    STEMS=1 python3 v17/build.py v17      # writes v17/v17-v17-pre.wav, v17/map-v17.json, v17/stems/*
    python3 v17/master.py                 # -> v17/FOREVER-PICTURES-v17-master.wav (-14 LUFS, -1 dBTP) + music-only
    python3 v15/qc.py v17/FOREVER-PICTURES-v17-master.wav v17/map-v17.json   # holes / jumps
    python3 v17/entrycheck.py             # music level under every spoken entry
(VOCONLY=1 python3 v17/build.py v17 writes v17/voconly.wav = singer-only in film order, for join ASR.)

## Inputs
- Song stems (absolute paths): /mnt/project-files/mr-big-ep01/music-suno/35M2-INSTRUMENTAL.wav, 35M2-get-in-the-picture.wav, 35M2-VOCALS.wav
- Raw voice lines (before cleaning): v16/lines/, takes/lines/ (loader order v16 -> v13 -> takes; v13 is empty here, nothing reads from it)
- ETB/AT2 are new takes cut from the Drive files: clean/make_eth.py (cut times inside) writes clean/lines/ETB.wav + AT2.wav (already cleaned with chain.py).

## Where the voice cleanup happens (swap point)
v17/build.py, function _ln(i):
    x = tighten(raw)            # trims silences; this sets every line's LENGTH and therefore every cue
    y = clean(x, 'heavy'|'light')[:len(x)]   # clean/chain.py -> REPLACE THIS CALL with the new cleaner
    return y * level-match
Rules for a drop-in cleaner: output must be the SAME LENGTH as x (sample-exact, 44.1 kHz mono float), and no added latency/offset. Then no cue moves.
'heavy' = KIM, AMIN2, AH (real recordings); 'light' = all others (ElevenLabs/TTS).
ETB and AT2 bypass this: they are read pre-cleaned from clean/lines/ (re-run clean/make_eth.py with the new cleaner, keeping the same cut times; length change there moves only the Faye V3 bed by up to a beat).

## Timing rules baked in (do not change)
- Word-exact sung cuts (song time): E_V1 104.749/S_V2 104.755, E_P2 145.215/S_BR 145.225, E_BR 177.016 (+ringout)/S_BU 177.025, E_BU 189.905/S_FI 189.915, E_FI 224.020 (end of closing hum).
- place(): any line that would start on a music hit / climax tail is delayed until the bed settles (fwd-median +6 dB rule). Currently moves FV2a +0.47 s, FV3a +0.45 s, KIM +0.15 s.
- Ethiopia moment: bed goes dry (no room pad) and dips -6 dB under ETB/AT2.
