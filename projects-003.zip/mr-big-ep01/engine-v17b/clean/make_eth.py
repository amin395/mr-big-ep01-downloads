# Rebuilds clean/lines/ETB.wav (elder) and AT2.wav (Amin) from the raw Drive takes, then cleans them.
import sys; sys.path.insert(0,'clean'); from chain import clean,SR
import librosa,soundfile as sf
V='/mnt/project-files/mr-big-ep01/voices/'
E_=librosa.load(V+'ethiopian-man-blackseed-drive.mp3',sr=SR)[0]
A_=librosa.load(V+'founders/amin-howlong-thisistheone-drive.mp3',sr=SR)[0]
cut=lambda x,a,b: x[int((a-0.08)*SR):int((b+0.15)*SR)]
RAW={'ETB_0':(1.40,2.58),'ETB_17':(39.79,40.96),'ETB_1':(3.29,4.49)}   # ETB = ETB_0 (in the mix)
for n,(a,b) in RAW.items():
    sf.write(f'clean/lines/{n}.wav',clean(cut(E_,a,b),'heavy',hp=60,lowmid=-1.0,pres=-1.5,air=-1.0),SR,subtype='PCM_24')
sf.write('clean/lines/AT2.wav',clean(cut(A_,43.44,44.23),'heavy',hp=90,lowmid=-3.5,pres=3.0,air=2.0),SR,subtype='PCM_24')
import shutil; shutil.copy('clean/lines/ETB_0.wav','clean/lines/ETB.wav')
