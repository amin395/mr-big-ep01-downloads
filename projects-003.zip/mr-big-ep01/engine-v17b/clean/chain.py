import numpy as np, librosa, noisereduce as nr
from nara_wpe.wpe import wpe
from nara_wpe.utils import stft, istft
from pedalboard import Pedalboard, HighpassFilter, PeakFilter, HighShelfFilter, Compressor, Limiter, LowShelfFilter, NoiseGate
SR=44100
def dereverb(x,taps=12,delay=3,it=4):
    S=stft(x[None,:],size=1024,shift=256)          # (1,T,F)
    Y=S.transpose(2,0,1)                            # (F,1,T)
    Z=wpe(Y,taps=taps,delay=delay,iterations=it,statistics_mode='full')
    z=istft(Z.transpose(1,2,0),size=1024,shift=256)[0]
    return z[:len(x)] if len(z)>=len(x) else np.pad(z,(0,len(x)-len(z)))
def clean(x,strength='heavy',hp=80,lowmid=-3.0,pres=2.0,air=1.5):
    x=x.astype(np.float64); x=x/ (np.abs(x).max()+1e-9)*0.5
    pad=int(0.3*SR); x=np.pad(x,(pad,pad))
    if strength=='heavy':
        x=dereverb(x,taps=14,delay=2,it=5)
        x=nr.reduce_noise(y=x,sr=SR,stationary=True,prop_decrease=0.85,n_fft=2048)
        x=nr.reduce_noise(y=x,sr=SR,stationary=False,prop_decrease=0.5,n_fft=1024,time_constant_s=0.4)
    elif strength=='medium':
        x=dereverb(x,taps=10,delay=3,it=3)
        x=nr.reduce_noise(y=x,sr=SR,stationary=True,prop_decrease=0.7,n_fft=2048)
    else:
        x=nr.reduce_noise(y=x,sr=SR,stationary=True,prop_decrease=0.5,n_fft=2048)
    x=x[pad:-pad].astype(np.float32)
    b=Pedalboard([HighpassFilter(hp),PeakFilter(320,lowmid,1.0),PeakFilter(4200,pres,0.9),HighShelfFilter(10000,air,0.7),
                  NoiseGate(threshold_db=-50,ratio=4,attack_ms=2,release_ms=120),
                  Compressor(threshold_db=-22,ratio=2.5,attack_ms=8,release_ms=120),Limiter(-1.0,80)])
    y=b(x,SR)
    return y/(np.abs(y).max()+1e-9)*0.7
