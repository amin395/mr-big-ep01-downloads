import numpy as np,soundfile as sf,json,sys
y,sr=sf.read(sys.argv[1]); m=json.load(open(sys.argv[2]))
print('nan',np.isnan(y).sum(),'dur',round(len(y)/sr,1))
def r(a,b):
    z=y[max(0,int(a*sr)):int(b*sr)]; return 20*np.log10(np.sqrt(np.mean(z**2))+1e-9)
print('join: 2s before | 2s after | step')
for t,l in m['marks']:
    if t==0: continue
    b,a=r(t-2,t),r(t,t+2); print(f"{t:6.1f} {l[:28]:28s} {b:6.1f} {a:6.1f} {a-b:+5.1f}")
c=[r(i,i+1) for i in range(int(len(y)/sr))]
gaps=[i for i,v in enumerate(c) if v<-45]; print('near-silent seconds',gaps)
jumps=[(i,round(c[i]-c[i-1],1)) for i in range(1,len(c)) if abs(c[i]-c[i-1])>8]; print('1s jumps >8dB',jumps)
