import soundfile as sf,numpy as np,json
y,sr=sf.read('v17/stems/0-music-no-ducking.wav'); b=json.load(open('v17/map-v17.json'))
def lev(a,w=0.05): z=y[int(a*sr):int((a+w)*sr)]; return 20*np.log10(np.sqrt(np.mean(z**2))+1e-9)
bad=0
for k,(s,e) in zip(b['voxid'],b['vox']):
    fw=[lev(s+0.6+i*0.1) for i in range(30)]; med=np.median(fw)
    pk=max(lev(s+i*0.05) for i in range(-1,5))
    flag=pk>med+6
    bad+=flag
    print(f"{k:6s} {s:8.2f} fwd-med {med:6.1f} entry-peak {pk:6.1f} {'<< ON A HIT' if flag else 'ok'}")
print('flags',bad)
