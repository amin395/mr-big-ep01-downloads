import numpy as np,soundfile as sf,librosa,json,os,sys
SR=44100; db=lambda v:10**(v/20); B=0.41796; BAR=4*B
L=lambda p: librosa.load(p,sr=SR,mono=True)[0]
D='/mnt/project-files/mr-big-ep01/music-suno/'
INST=L(D+'35M2-INSTRUMENTAL.wav'); MIX=L(D+'35M2-get-in-the-picture.wav'); VOC=L(D+'35M2-VOCALS.wav')
n=min(len(INST),len(MIX),len(VOC)); INST,MIX,VOC=INST[:n],MIX[:n],VOC[:n]; END=n/SR
VOCONLY=os.environ.get('VOCONLY')
def arms(x):
    f=librosa.feature.rms(y=x,frame_length=2048,hop_length=512)[0]; d=20*np.log10(f+1e-9); a=d[d>d.max()-30]; return 10*np.log10(np.mean(10**(a/10)))
LV=arms(VOC[int(52*SR):int(70*SR)])
if VOCONLY: MIX=VOC; INST=INST*0
LINES=sys.argv[1] if len(sys.argv)>1 else 'temp'
_cache={}
def tighten(x,maxgap=0.5,keep=0.36,edge=0.03):
    iv=librosa.effects.split(x,top_db=38,frame_length=1024,hop_length=256)
    if len(iv)==0: raise SystemExit('SILENT LINE')
    e=int(edge*SR); f=int(0.02*SR); parts=[]; a0=max(0,iv[0][0]-e)
    cur=[a0,iv[0][1]]
    for a,b in iv[1:]:
        if (a-cur[1])/SR>maxgap: parts.append(cur); cur=[a,b]
        else: cur[1]=b
    parts.append(cur); parts[-1][1]=min(len(x),parts[-1][1]+e)
    y=np.zeros(0,np.float32); k=int(keep*SR)
    for j,(a,b) in enumerate(parts):
        if j: a=max(0,a-k//2)
        if j<len(parts)-1: b=min(len(x),b+k//2)
        c=x[a:b].copy(); c[:f]*=np.linspace(0,1,f); c[-f:]*=np.linspace(1,0,f); y=np.concatenate([y,c])
    return y
def ln(i):
    if i in _cache: return _cache[i]
    _cache[i]=_ln(i); return _cache[i]
def _ln(i):
    if i in ('ETB','AT2'):
        x=tighten(L('clean/lines/'+i+'.wav')); return x*db(LV-0.5-arms(x))
    for p in ['v16/lines/'+i+'.wav','v13/lines/'+i+'.wav','takes/lines/'+i+'.wav']:
        if os.path.exists(p): x=L(p); break
    x=tighten(x)
    sys.path.insert(0,'clean'); from chain import clean
    y=clean(x,'heavy' if i in ('KIM','AMIN2','AH') else 'light')[:len(x)]
    return y*db(LV-0.5-arms(y))
def sung(a,b,fin=0.01,fout=0.03,tx=0.0):
    x=seg(MIX,a,b)
    if fin>0: k=int(fin*SR); x[:k]*=np.linspace(0,1,k)
    if fout>0 and tx<=0: k=int(fout*SR); x[-k:]*=np.linspace(1,0,k)
    if tx>0: x=with_tail(seg(VOC,a,b),seg(INST,a,b),b,tx,fout)
    return x
def with_tail(v,i,b,tx,fout):
    # the sung word ends at b (vocal fades fout); the music keeps playing tx s past it so the next bed crossfades in under it
    k=int(fout*SR); v=v.copy(); v[-k:]*=np.linspace(1,0,k)
    return np.concatenate([v+i,seg(INST,b,b+tx)])
def ringout(v,t=0.9,lvl=-14):
    from scipy.signal import fftconvolve as fc
    tt=np.arange(int(t*SR))/SR; ir=np.random.default_rng(11).standard_normal(len(tt))*np.exp(-tt/0.22); ir=np.convolve(ir,np.ones(16)/16,'same'); ir/=np.sqrt(np.sum(ir**2))
    last=v[-int(0.35*SR):]; w=fc(last,ir)[len(last):]; w*=db(lvl)*np.sqrt(np.mean(last**2))/max(1e-9,np.sqrt(np.mean(w[:int(0.05*SR)]**2)))
    k=int(0.1*SR); w[-k:]*=np.linspace(1,0,k)
    return np.concatenate([v,w.astype(np.float32)])
seg=lambda src,a,b: src[int(round(a*SR)):int(round(b*SR))].copy()
out=np.zeros(0,np.float32); vox=[]; rows=[]; marks=[]; duck=[]; zones=[]
def emit(x,label=None,xf=B,bed=False):
    global out
    x=x.astype(np.float32); k=int(xf*SR) if len(out) else 0; k=min(k,len(x),len(out)); st=len(out)-k
    if label: marks.append((round(st/SR,3),label))
    if k:
        t=np.linspace(0,np.pi/2,k); out=np.concatenate([out[:-k],out[-k:]*np.cos(t)+x[:k]*np.sin(t),x[k:]])
    else: out=np.concatenate([out,x])
    if bed: duck.append((st,st+len(x)))
    return st
GAPX=0.0
PRE={'D2':0.60,'AT2':0.35}
def place(ids,start,gap=0.42):
    global GAPX; gap=gap+GAPX; GAPX=0.0
    c=int(start); lim=len(out)
    xs=[ln(k) for k in ids]
    for j,k in enumerate(ids):
        if j: c+=int(PRE.get(k,0)*SR)
        x=xs[j]
        # never start a voice on a music hit or a climax tail: wait for the bed to settle (bounded by the slack left in this bed)
        rest=sum(len(z) for z in xs[j+1:])+int(gap*SR)*(len(ids)-1-j)+int(0.25*SR)
        room=lim-(c+len(x)+rest)
        if room>0 and lim>c:
            h=int(0.05*SR)
            lv=lambda a: 20*np.log10(np.sqrt(np.mean(out[a:a+h]**2))+1e-9)
            fw=[lv(c+int((0.6+i*0.1)*SR)) for i in range(30) if c+int((0.6+i*0.1)*SR)+h<len(out)]
            if fw:
                med=float(np.median(fw)); cap=min(room,int((1.2 if j==0 else 0.6)*SR))
                if max(lv(c+i*h) for i in range(-1,5))>med+6:
                    d=0
                    while d<cap and not all(lv(c+d+i*h)<=med+3 for i in range(3)): d+=h//2
                    if d<cap: c+=d; SHIFTS.append((k,round(d/SR,2)))
        vox.append((c,x)); rows.append((round(c/SR,1),k)); c+=len(x)+int(gap*SR)
    return c
SHIFTS=[]
def need(ids,gap=0.42): return sum(len(ln(k))/SR for k in ids)+gap*(len(ids)-1)+sum(PRE.get(k,0) for k in ids[1:])
LEAD_MIN=0.25*B; TAIL_MIN=0.5*B
def plan(ids,unit=2,lead_min=LEAD_MIN,tail_min=TAIL_MIN):
    nd=need(ids); nd+=np.ceil(nd/(8*BAR))*B; N=int(np.ceil((nd+lead_min+tail_min)/BAR/unit))*unit; slack=N*BAR-nd-lead_min-tail_min
    lead=lead_min+min(slack,0.3); rest=slack-min(slack,0.3)
    global GAPX; GAPX=min(0.2,rest/max(1,len(ids)))  # spread the rest as a little more breath between lines (max +0.35 s)
    return N, lead
bars=lambda s,mult=4: int(np.ceil(s/BAR/mult))*mult
# join points (song time), found from the vocal stem: singer is between words here
J_INTRO=13.42; J_SONGEND=229.25
# word-exact cuts (35M2 vocal stem): E = last sung word ends, S = next sung word starts
E_V1=104.749; S_V2=104.755; E_P2=145.215; S_BR=145.225; E_BR=177.016; S_BU=177.025; E_BU=189.905; S_FI=189.915; E_FI=224.020
TX=0.45; V_INTRO=1.03; V_V2END=0.0; V_BRIDGE=0.02; V_BUILD=0.0
def zone(a,ref_t,pad):
    b2=len(out); bed_l=arms(out[a+int(1.2*SR):b2]); ref=arms(MIX[int(ref_t*SR):int((ref_t+6)*SR)])
    zones.append((a,b2,4.0 if ref_t==16.0 else float(np.clip(ref-4-bed_l,-6,12)),pad))
def back_bed(X,ids,lo,label,lead=None,pad=0.0,ref=None):  # passes that END at X; first pass = remainder, rest whole phrases
    N,ld=plan(ids,lead_min=(LEAD_MIN if lead is None else lead)); lead=ld; mmax=int((X-lo)/BAR)//4*4; first=None
    ms=[N%mmax] if N%mmax else []; ms+= [mmax]*(N//mmax)
    for m in ms:
        s=emit(seg(INST,X-m*BAR,X),label if first is None else None,bed=True); first=s if first is None else first
    place(ids,first+int(lead*SR)); zone(first,X if ref is None else ref,pad)
def fwd_bed(P,ids,hi,label,lead=BAR*0.5,pad=0.0,ref=None,src=None):
    N,lead=plan(ids,lead_min=lead); mmax=int((hi-P)/BAR)//4*4; first=None
    while N>0:
        m=min(N,mmax); s=emit(seg(INST if src is None else src,P,P+m*BAR),label if first is None else None,bed=True,xf=(2*B if first is None else B)); first=s if first is None else first; N-=m
    place(ids,first+int(lead*SR)); zone(first,P if ref is None else ref,pad)
def _split(N,mmax):
    q,r=divmod(N,mmax); ms=([r] if r else [])+[mmax]*q
    if ms[0]<6 and len(ms)>1: ms[0]+=4; ms[-1]-=4
    return ms
def back_bed2(X,ids,lo,label,lead=0.28,tail=0.30,pad=0.0,ref=None,xf_in=0.06,tl=0.0):
    # bed of INST passes ending at song time X; lines start `lead` s after the previous section ends and finish `tail` s before this bed ends
    global GAPX
    nd=need(ids); mmax=max(8,int((X-lo)/BAR)//4*16)
    target=nd+lead+tail+xf_in-tl
    for N in range(6,5000):
        ms=_split(N,mmax); Lb=N*B-(len(ms)-1)*B
        if Lb>=target: break
    slack=Lb-target; gx=min(0.12,0.5*slack/max(1,len(ids)-1)) if len(ids)>1 else 0.0
    lead+= (slack-gx*(len(ids)-1))/2
    first=None
    for j,m in enumerate(ms):
        s_=emit(seg(INST,X-m*B,X),label if first is None else None,bed=True,xf=(xf_in if j==0 else B)); first=s_ if first is None else first
    GAPX=0.0; place(ids,first+int((xf_in-tl+lead)*SR),gap=0.42+gx); zone(first,X if ref is None else ref,pad)
    print('bed',label,'beats',N,'lead',round(lead,2),'gx',round(gx,3))
def fwd_bed2(P,ids,hi,label,lead=0.28,tail=0.30,pad=0.0,ref=None,xf_in=0.06,tl=0.0,share=0.5):
    global GAPX
    nd=need(ids); mmax=int((hi-P)/BAR)//4*16
    target=nd+lead+tail+xf_in-tl
    for N in range(6,5000):
        q,r=divmod(N,mmax); ms=[mmax]*q+([r] if r else [])
        if len(ms)>1 and ms[-1]<6: ms[-1]+=4; ms[-2]-=4
        Lb=N*B-(len(ms)-1)*B
        if Lb>=target: break
    slack=Lb-target; gx=min(0.12,0.5*slack/max(1,len(ids)-1)) if len(ids)>1 else 0.0
    lead+= (slack-gx*(len(ids)-1))*share
    first=None
    for j,m in enumerate(ms):
        s_=emit(seg(INST,P,P+m*B),label if first is None else None,bed=True,xf=(xf_in if j==0 else B)); first=s_ if first is None else first
    GAPX=0.0; place(ids,first+int((xf_in-tl+lead)*SR),gap=0.42+gx); zone(first,P if ref is None else ref,pad)
    print('bed',label,'beats',N,'lead',round(lead,2),'gx',round(gx,3))
V1=['FV1a','KG','FV1b','KN','FV1c']
V2=['FV2a','AH','E1N','FV2b','NKL','NK31','D2']
V3=['FV3a','ETB','AT2','FV3b2']
# 1 intro with hum, F1 F2
X0=J_INTRO-B-need(['P1','D1','F1'],0.55)-0.30; _o=seg(MIX,X0,J_INTRO); _f=int(0.08*SR); _o[:_f]*=np.linspace(0,1,_f)
s=emit(_o,'Cold open: the wedding',xf=0,bed=True); place(['P1','D1','F1'],s+int(0.30*SR),0.55); print('X0',X0)
# 2 2009 (lines may run into the song's instrumental pickup before the singer)
emit(seg(INST,J_INTRO,J_INTRO+0.001),None,xf=0)
back_bed2(J_INTRO,['F2','K14','F4'],J_INTRO-4*BAR,'Here is where it started: 2009',lead=0.45,tail=0.30-V_INTRO,pad=0.75,ref=14.0)
# 3 sung V1 through "still felt broke"
emit(sung(J_INTRO,E_V1,fin=0.0,fout=0.012,tx=TX),'SUNG V1, Pre1, Ch1, Post1, V2',xf=0.06)
# 4 FAYE V1 over the Verse 2 groove
back_bed2(S_V2,V1,78.5,'FAYE V1: the problem (V2 groove)',pad=0.6,ref=90.0,tail=0.30-V_V2END,xf_in=TX,tl=TX)
# 5 sung Pre2 > Ch2 > Post2, through the last "get in"
emit(sung(S_V2,E_P2,fout=0.012,tx=TX),'SUNG Pre2, Ch2, Post2',xf=0.03)
# 6 FAYE V2 over the Verse 1 groove (bar phase matched to J_BRIDGE)
back_bed2(S_BR-int(os.environ.get('K2','66'))*BAR,V2,13.42,'FAYE V2: the source (Verse 1 groove)',ref=20.0,tail=0.25-V_BRIDGE,xf_in=TX,tl=TX)
# 7 sung bridge from "Wash it off" through the end of "finally me"
_bv=seg(VOC,S_BR,E_BR); _bi=seg(INST,S_BR,E_BR); _fi=int(0.01*SR); _bv[:_fi]*=np.linspace(0,1,_fi); _fo=int(0.012*SR); _bv[-_fo:]*=np.linspace(1,0,_fo); _bv=ringout(_bv); _g=np.ones(len(_bi),np.float32)
_k1=int(0.45*SR); _k2=int(0.9*SR); _g[:_k1]=db(-10); _g[_k1:_k2]=np.linspace(db(-10),1,_k2-_k1)
emit(np.concatenate([_bv[:len(_bi)]+_bi*_g,seg(INST,E_BR,E_BR+TX)+_bv[len(_bi):len(_bi)+int(TX*SR)]]),'SUNG Bridge (wash it off)',xf=0.03)
# 8 FAYE V3 over the Verse 2 groove (bar phase matched to J_BUILD)
back_bed2(S_BU-44*BAR,V3,78.5,'FAYE V3: the proof (Verse 2 groove)',pad=0.3,ref=90.0,tail=0.30-V_BUILD,xf_in=TX,tl=TX)
# 9 sung build through "showin' up for me", then the drop
emit(sung(S_BU,E_BU,fout=0.012),'SUNG Build: 30 nights',xf=0.03)
from scipy.signal import fftconvolve as _fc
GAP_P2=0.30; GAP_K=0.22; GAP_SING=0.28
hold=GAP_P2+len(ln('P2'))/SR+GAP_K+len(ln('K13'))/SR+GAP_SING
tt=np.arange(int((hold+1.0)*SR))/SR; rg=np.random.default_rng(3); ir2=rg.standard_normal(len(tt))*np.exp(-tt/1.1); ir2/=np.sqrt(np.sum(ir2**2))
last=seg(MIX,E_BU-BAR,E_BU); wet=_fc(last,ir2)[len(last):len(last)+int(hold*SR)]
wet*=db(-14)*np.sqrt(np.mean(last**2))/max(1e-9,np.sqrt(np.mean(wet[:int(0.3*SR)]**2)))
fo=int(0.15*SR); wet[-fo:]*=np.linspace(1,0,fo)
st=len(out); place(['P2'],st+int(GAP_P2*SR)); place(['K13'],st+int((GAP_P2+len(ln('P2'))/SR+GAP_K)*SR))
emit(wet.astype(np.float32),'DROP: Family of the Bride! / Never again',xf=0)
# 10 final chorus + post, through the last "get in"
fi=sung(S_FI,E_FI,fout=0.012,tx=1.0)
emit(fi,'SUNG Final Chorus + Post',xf=0)
from scipy.signal import fftconvolve
# 11 straight from the climax: price + where to buy, then the founders, on the calm Verse 1 piano (no voice over the peak)
fwd_bed2(14.68,['KIM','AMIN2','F39P'],14.68+16*BAR,'Founders, then price + where to buy (Verse 1 piano)',ref=16.0,pad=0.6,tail=3.2,share=0.0,xf_in=1.0,tl=1.0)
y=out.copy()
if VOCONLY:
    pass
from scipy.signal import fftconvolve
t=np.arange(int(2.6*SR))/SR; rng=np.random.default_rng(7); ir=rng.standard_normal(len(t))*np.exp(-t/0.7); ir=np.convolve(ir,np.ones(24)/24,'same'); ir/=np.sqrt(np.sum(ir**2))
y_dry=y.copy()
for a,b2,gd,pad in zones:
    r=int(0.4*SR); env=np.ones(b2-a,np.float32)*db(gd); 
    ramp=np.linspace(1,db(gd),min(r,(b2-a)//2)); env[:len(ramp)]=ramp; env[-len(ramp):]=ramp[::-1]
    seg_=y[a:b2]*env
    s0=seg_.copy()
    if pad>0:
        wet=fftconvolve(seg_,ir)[:len(seg_)]; wet*=np.sqrt(np.mean(seg_**2))/max(1e-9,np.sqrt(np.mean(wet**2)))
        seg_=seg_*(1-pad*0.4)+wet*pad
    # fill holes in the bed: slow upward leveler toward the zone median (max +10 dB)
    hop=int(0.05*SR); fr=np.sqrt(np.convolve(seg_**2,np.ones(int(0.4*SR))/int(0.4*SR),'same')[::hop])+1e-9; dd=20*np.log10(fr)
    tgt=np.median(dd)-3; g=np.clip(tgt-dd,0,10); g=np.convolve(g,np.ones(5)/5,'same')
    gi=np.interp(np.arange(len(seg_)),np.arange(len(g))*hop,g); seg_=seg_*db(gi)
    y_dry[a:b2]=s0*db(gi)
    y[a:b2]=seg_
    print('zone',round(a/SR,1),round(b2/SR,1),'gain',round(gd,1),'pad',pad)
ETH=[ (c,c+len(x)) for (c,x),(_,k) in zip(vox,rows) if k in ('ETB','AT2')]
if ETH:
    a0=min(a for a,b in ETH)-int(0.35*SR); b0=max(b for a,b in ETH)+int(0.35*SR)
    g=np.ones(len(y),np.float32); r=int(0.25*SR)
    g[a0:b0]=db(-6); g[a0-r:a0]=np.linspace(1,db(-6),r); g[b0:b0+r]=np.linspace(db(-6),1,r)
    mk=(1-g)/(1-db(-6)); y=(y*(1-mk)+y_dry*mk)*g  # crossfade to the dry bed (no room pad) and dip it under the two outdoor lines
sp=np.zeros(len(y),np.float32)
for c,x in vox: sp[c:c+len(x)]=1
w=int(0.35*SR); sp=np.convolve(sp,np.ones(int(1.0*SR)),'same')>0; sp=sp.astype(np.float32); sp=np.clip(np.convolve(sp,np.ones(w)/w,'same'),0,1)
z=np.zeros(len(y),np.float32)
for a,b2 in duck: z[a:b2]=1
y_raw=y.copy(); y=y*(1-z*sp*(1-db(-6)))
y_duck=y.copy()
sf.write('v17/bedonly.wav',y,SR)
for c,x in vox: m=min(len(x),len(y)-c); y[c:c+m]+=x[:m]
vo=np.zeros(len(y),np.float32)
for c,x in vox: m=min(len(x),len(y)-c); vo[c:c+m]+=x[:m]
sf.write('v17/voxonly.wav',vo,SR)
fo=int(3*SR); y[-fo:]*=np.linspace(1,0,fo); GN=0.89/np.abs(y).max(); y=y*GN
if os.environ.get('STEMS'):
    os.makedirs('v17/stems/lines',exist_ok=True); fade=np.ones(len(y),np.float32); fade[-fo:]=np.linspace(1,0,fo)
    ST={'0-music-as-mixed':y_duck,'0-music-no-ducking':y_raw}
    for (c,x),(_,k) in zip(vox,rows):
        who='3-founders' if k in ('KIM','AMIN2','AMIN3') else ('1-faye' if k.startswith('F') else '2-characters')
        a=ST.setdefault(who,np.zeros(len(y),np.float32)); m=min(len(x),len(y)-c); a[c:c+m]+=x[:m]
        sf.write(f'v17/stems/lines/{int(c/SR//60)}m{c/SR%60:05.2f}s_{k}.wav',(x*GN).astype(np.float32),SR,subtype='PCM_24')
    for k,a in ST.items(): sf.write(f'v17/stems/{k}.wav',(a*fade*GN).astype(np.float32),SR,subtype='PCM_24')
json.dump({'rows':sorted(rows),'marks':marks,'vox':[(c/SR,(c+len(x))/SR) for c,x in vox],'voxid':[r[1] for r in sorted(rows)]},open(f'v17/map-{LINES}{"-voc" if VOCONLY else ""}.json','w'))
if VOCONLY: sf.write('v17/voconly.wav',out,SR); sys.exit()
sf.write(f'v17/v17-{LINES}-pre.wav',y,SR)
print('total',round(len(y)/SR,1)); print('SHIFTS',SHIFTS); print(marks)
