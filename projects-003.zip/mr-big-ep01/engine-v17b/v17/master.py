import soundfile as sf,numpy as np,pyloudnorm as pl
from pedalboard import Pedalboard,Limiter,Compressor
y,sr=sf.read('v17/v17-v17-pre.wav'); m=pl.Meter(sr); L0=m.integrated_loudness(y)
g=10**((-14.0-L0)/20); print('LUFS in',round(L0,2),'gain dB',round(20*np.log10(g),2))
B=Pedalboard([Compressor(threshold_db=-16,ratio=1.6,attack_ms=30,release_ms=250),Limiter(threshold_db=-1.2,release_ms=120)])
def mst(x): 
    z=B((x*g).astype(np.float32),sr); return z*(10**(-1.0/20)/max(1e-9,np.abs(z).max()))
ym=mst(y); print('out LUFS',round(m.integrated_loudness(ym),2),'peak dB',round(20*np.log10(np.abs(ym).max()),2))
sf.write('v17/FOREVER-PICTURES-v17-master.wav',ym,sr,subtype='PCM_24')
mo,_=sf.read('v17/stems/0-music-no-ducking.wav'); GN0=np.abs(y).max()  # stems already carry GN
mm=mst(mo); sf.write('v17/FOREVER-PICTURES-v17-music-only.wav',mm,sr,subtype='PCM_24'); print('music LUFS',round(m.integrated_loudness(mm),2))
