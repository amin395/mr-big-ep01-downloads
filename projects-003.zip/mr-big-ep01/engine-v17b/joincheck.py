"""Measure every sung<->spoken join on the vocal-only (voconly.wav) and spoken-only (voxonly.wav) builds.
Rule (Amin): no overlap; spoken starts ~0.28-0.45 s after the last sung trace, sung starts ~0.25-0.35 s after the last spoken trace.
usage: python3 joincheck.py <dir with voconly.wav voxonly.wav>"""
import sys,soundfile as sf,numpy as np
d=sys.argv[1]
def load(f):
  y,sr=sf.read(f'{d}/{f}'); return (y.mean(1) if y.ndim>1 else y),sr
v,sr=load('voconly.wav'); x,_=load('voxonly.wav')
h=int(0.01*sr)
def act(y,th=-50):
  n=len(y)//h; e=np.sqrt((y[:n*h].reshape(n,h)**2).mean(1)+1e-12)
  return 20*np.log10(e)>th
av,ax=act(v),act(x)
def runs(a,minlen=8,bridge=60):
  r=[];i=0;n=len(a)
  while i<n:
    if a[i]:
      j=i
      while j<n and (a[j] or (j+bridge<n and a[j:j+bridge].any())): j+=1
      if j-i>=minlen: r.append((i/100,j/100))
      i=j
    else: i+=1
  return r
RV=runs(av,bridge=150); RX=runs(ax,bridge=150)
ev=[(s,e,'SUNG') for s,e in RV]+[(s,e,'SPOKEN') for s,e in RX]
ev.sort()
bad=0
for (s1,e1,k1),(s2,e2,k2) in zip(ev,ev[1:]):
  if k1==k2: continue
  gap=s2-e1
  ok = 0.22<=gap<=0.6 if k2=='SUNG' else 0.25<=gap<=0.8
  if not ok: bad+=1
  m=lambda t:f"{int(t//60)}:{t%60:06.3f}"
  print(f"{'OK ' if ok else 'BAD'} {k1:>6} ends {m(e1)} -> {k2:<6} starts {m(s2)}  gap {gap:+.2f} s")
print('BAD joins:',bad)
