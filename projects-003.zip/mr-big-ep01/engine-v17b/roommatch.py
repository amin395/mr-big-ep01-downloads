import librosa,numpy as np,soundfile as sf
from scipy.signal import firwin2,fftconvolve
sr=44100
bands=[(80,200),(200,500),(500,1500),(1500,4000),(4000,8000),(8000,14000)]
def ltas(x):
    S=np.abs(librosa.stft(x,n_fft=4096))**2; fr=librosa.fft_frequencies(sr=sr,n_fft=4096)
    r=librosa.feature.rms(y=x,frame_length=4096,hop_length=1024)[0]; d=20*np.log10(r+1e-9); act=d>d.max()-25
    m=S[:,act[:S.shape[1]]].mean(1); return fr,m
def tilt(x):
    fr,m=ltas(x); lv=np.array([10*np.log10(m[(fr>=a)&(fr<b)].mean()+1e-20) for a,b in bands]); return lv-lv[2]
def eqto(x,tgt_tilt,maxg=9):
    t=tilt(x); g=np.clip(tgt_tilt-t,-maxg,maxg)
    cf=[np.sqrt(a*b) for a,b in bands]
    f=[0]+cf+[sr/2]; gg=[g[0]]+list(g)+[g[-1]]
    h=firwin2(2049,np.array(f)/(sr/2),10**(np.array(gg)/20)); return fftconvolve(x,h,'same')
K,_=librosa.load('v16/lines/KIM.wav',sr=sr); A,_=librosa.load('v16/lines/AMIN.wav',sr=sr)
tk,ta=tilt(K),tilt(A); tgt=(tk+ta)/2; tgt[5]=min(tgt[5],-28); tgt[4]=min(tgt[4],-22)
K2=eqto(K,tgt); A2=eqto(A,tgt)
# one shared small room
t=np.arange(int(0.6*sr))/sr; rng=np.random.default_rng(11); ir=rng.standard_normal(len(t))*np.exp(-t/0.11)
ir=fftconvolve(ir,np.ones(30)/30,'same'); ir/=np.sqrt(np.sum(ir**2))
def room(x,wet=0.16):
    w=fftconvolve(x,ir)[:len(x)+int(0.3*sr)]; y=np.concatenate([x,np.zeros(int(0.3*sr))])
    y=y+wet*w*np.sqrt(np.mean(x**2))/np.sqrt(np.mean(w**2)+1e-12); return y
K3,A3=room(K2),room(A2)
for n,y in [('KIM_m',K3),('AMIN_m',A3)]:
    y=y/np.abs(y).max()*0.9; sf.write(f'v16/lines/{n}.wav',y.astype(np.float32),sr)
print('before',np.round(tk,1),np.round(ta,1)); print('after ',np.round(tilt(K3),1),np.round(tilt(A3),1))
