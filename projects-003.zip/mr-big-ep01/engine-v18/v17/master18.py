# v18 master: -14 LUFS integrated, true peak <= -1.0 dBTP (4x oversampled check), same chain for full + music-only
import sys,soundfile as sf,numpy as np,pyloudnorm as pl,soxr
from pedalboard import Pedalboard,Limiter,Compressor
TAG=sys.argv[1] if len(sys.argv)>1 else 'v18'
y,sr=sf.read(f'v17/v17-{TAG}-pre.wav'); m=pl.Meter(sr)
def tp(z): u=soxr.resample(z.astype(np.float64),sr,4*sr); return 20*np.log10(np.abs(u).max()+1e-12)
def chain(th): return Pedalboard([Compressor(threshold_db=-16,ratio=1.6,attack_ms=30,release_ms=250),Limiter(threshold_db=th,release_ms=120)])
def tplim(z,ceil=-1.0):
    # true-peak safe: limit at 4x oversampling with a hard ceiling, then back to 44.1k
    u=soxr.resample(z.astype(np.float64),sr,4*sr); c=10**(ceil/20)
    from scipy.ndimage import maximum_filter1d, uniform_filter1d
    a=np.abs(u) if u.ndim==1 else np.abs(u).max(1)
    need=np.minimum(1.0,c/np.maximum(a,1e-9)); w=int(0.002*4*sr)
    gmin=-maximum_filter1d(-need,size=2*w+1)            # look-ahead/behind min gain
    gs=uniform_filter1d(gmin,size=w)                    # smooth attack/release
    gs=np.minimum(gs,gmin*0+1); u=u*(gs if u.ndim==1 else gs[:,None])
    return soxr.resample(u,4*sr,sr)[:len(z)].astype(np.float32)
def mst(x):
    g=10**((-14.0-m.integrated_loudness(x))/20)
    for _ in range(8):
        z=tplim(chain(-1.2)((x*g).astype(np.float32),sr),-1.1); L=m.integrated_loudness(z)
        if abs(L+14)<0.05: break
        g*=10**((-14-L)/20)
    return z,g
ym,g=mst(y); print('full LUFS %.2f TP %.2f dBTP'%(m.integrated_loudness(ym),tp(ym)))
sf.write(f'v17/FOREVER-PICTURES-{TAG}-master.wav',ym,sr,subtype='PCM_24')
mo,_=sf.read('v17/stems/0-music-no-ducking.wav'); mm,_=mst(mo)
print('music LUFS %.2f TP %.2f dBTP'%(m.integrated_loudness(mm),tp(mm)))
sf.write(f'v17/FOREVER-PICTURES-{TAG}-music-only.wav',mm,sr,subtype='PCM_24')
