# DeepFilterNet3 denoise, sample-aligned, same length. usage: python dfn.py atten_db in.wav out.wav [...]
import sys, torch, soundfile as sf, numpy as np, soxr
from df.enhance import init_df, enhance
M='/tmp/claude-0/-home-user/3874b11f-661d-56e8-b564-35aaeabbb3e4/scratchpad/models/dfn3'
m, st, _ = init_df(M, log_level='ERROR')
att=float(sys.argv[1]); a=sys.argv[2:]
for i in range(0,len(a),2):
    x,sr=sf.read(a[i],dtype='float32'); x=x.mean(1) if x.ndim>1 else x
    x48=soxr.resample(x,sr,48000)
    y=enhance(m, st, torch.from_numpy(x48)[None], pad=True, atten_lim_db=(att if att>0 else None))[0].numpy()
    y=soxr.resample(y,48000,sr)
    y=np.pad(y,(0,max(0,len(x)-len(y))))[:len(x)]
    sf.write(a[i+1],y.astype(np.float32),sr,subtype='FLOAT')
    c=np.correlate(x[:min(len(x),88200)],y[:min(len(x),88200)],'full'); lag=c.argmax()-(min(len(x),88200)-1)
    r=x-y; print(a[i],'lag',lag,'removed %.1f dB'%(10*np.log10((r**2).sum()/((y**2).sum()+1e-12))),flush=True)
