# Studio de-reverb with anvuew BS-Roformer (SDR 22.5) or Mel-Band Roformer (mono SDR 20.4).
# Mask-based STFT model: output is sample-aligned with input (no latency). Same length guaranteed.
import sys, yaml, numpy as np, torch
sys.path.insert(0, '')
from audio_separator.separator.uvr_lib_v5.roformer.bs_roformer import BSRoformer
from audio_separator.separator.uvr_lib_v5.roformer.mel_band_roformer import MelBandRoformer
M = '/tmp/claude-0/-home-user/3874b11f-661d-56e8-b564-35aaeabbb3e4/scratchpad/models/'
torch.set_num_threads(4)

class _L(yaml.SafeLoader): pass
_L.add_constructor('tag:yaml.org,2002:python/tuple', lambda l, n: tuple(l.construct_sequence(n)))

_models = {}
def load(kind='bs'):
    if kind in _models: return _models[kind]
    if kind == 'bs':
        cfg = yaml.load(open(M + 'bs_config.yaml'), Loader=_L); ck = M + 'dereverb_bs_roformer_anvuew_sdr_22.5050.ckpt'; C = BSRoformer
    else:
        cfg = yaml.load(open(M + 'dereverb_mel_band_roformer_anvuew.yaml'), Loader=_L); ck = M + 'dereverb_mel_band_roformer_mono_anvuew_sdr_20.4029.ckpt'; C = MelBandRoformer
        if kind == 'mel': ck = M + 'dereverb_mel_band_roformer_anvuew_sdr_19.1729.ckpt'
    mc = dict(cfg['model'])
    sd = torch.load(ck, map_location='cpu', weights_only=False)
    if 'state_dict' in sd: sd = sd['state_dict']
    if kind == 'mono': mc['stereo'] = False
    for zdc in (False, True):
        try:
            m = C(**mc, zero_dc=zdc); m.load_state_dict(sd, strict=True); break
        except Exception as e:
            err = e
    else:
        raise err
    m.eval()
    _models[kind] = (m, cfg)
    return _models[kind]

@torch.no_grad()
def dereverb(x, kind='bs'):
    """x: mono float 44.1k. returns (dry, reverb) same length."""
    m, cfg = load(kind)
    ch = 1 if kind == 'mono' else 2
    C = int(cfg['audio']['chunk_size']); N = 2; step = C // N
    x = np.asarray(x, np.float32); L = len(x)
    if L <= C - 44100:  # short line: one pass over the whole line (+0.5 s silence each side)
        p = 22050; seg = torch.from_numpy(np.stack([np.pad(x, (p, p))] * ch))[None]
        y = m(seg)
        if y.dim() == 4: y = y[:, 0]
        dry = y[0].mean(0).numpy()[p:p + L]
        return dry.astype(np.float32), (x - dry).astype(np.float32)
    pad = C // 2
    xp = np.pad(x, (pad, pad + C))
    mix = torch.from_numpy(np.stack([xp] * ch))
    out = torch.zeros_like(mix); cnt = torch.zeros(mix.shape[-1])
    win = torch.hann_window(C, periodic=False) + 1e-3
    for s in range(0, mix.shape[-1] - C + 1, step):
        seg = mix[:, s:s + C][None]
        y = m(seg)
        if y.dim() == 4: y = y[:, 0]
        out[:, s:s + C] += y[0] * win; cnt[s:s + C] += win
    out = out / cnt
    dry = out.mean(0).numpy()[pad:pad + L]
    return dry.astype(np.float32), (x - dry).astype(np.float32)

if __name__ == '__main__':
    import soundfile as sf, time
    for f in sys.argv[2:]:
        x, sr = sf.read(f, dtype='float32'); x = x.mean(1) if x.ndim > 1 else x
        t = time.time(); d, r = dereverb(x, sys.argv[1])
        o = f.rsplit('.', 1)[0] + f'_{sys.argv[1]}_dry.wav'
        sf.write(o, d, sr); sf.write(o.replace('_dry', '_rev'), r, sr)
        print(f, 'len ok' if len(d) == len(x) else 'LEN MISMATCH', f'{time.time()-t:.1f}s',
              'reverb/dry dB %.1f' % (10 * np.log10((r**2).sum() / (d**2).sum() + 1e-12)))
