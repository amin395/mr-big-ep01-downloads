# per line: DNSMOS (raw tight vs v17 old chain vs v18) + voiced fraction kept
import sys,os,glob,numpy as np,soundfile as sf,librosa
sys.path.insert(0,'.'); from dnsmos import score
sys.path.insert(0,'eng/clean'); from chain import clean
def voiced(x):
    f0,v,_=librosa.pyin(x,fmin=60,fmax=500,sr=44100,frame_length=2048,hop_length=512); return np.mean(v)
names=sys.argv[3:] ; A,B=sys.argv[1],sys.argv[2]
HEAVY={'KIM','AMIN2','AH','AT2','ETB'}
print('%-7s %-17s %-17s %-17s %s'%('line','raw SIG/BAK/OVRL','v17 SIG/BAK/OVRL','v18 SIG/BAK/OVRL','voiced raw->v18'))
for n in names:
    x=sf.read(f'{A}/{n}.wav',dtype='float32')[0]; y=sf.read(f'{B}/{n}.wav',dtype='float32')[0]
    o=clean(x,'heavy' if n in HEAVY else 'light')[:len(x)]
    import pyloudnorm as pl; M=pl.Meter(44100,block_size=0.2)
    nm=lambda z: z*10**((-23-M.integrated_loudness(z))/20)
    s0,s1,s2=score(nm(x),44100),score(nm(o),44100),score(nm(y),44100)
    vx,vy=voiced(x[:44100*8]),voiced(y[:44100*8])
    flag='' if vy>=vx-0.03 else '  <-- VOICING LOSS'
    print('%-7s %s  %s  %s  %.2f->%.2f%s'%(n,'/'.join('%.2f'%v for v in s0),'/'.join('%.2f'%v for v in s1),'/'.join('%.2f'%v for v in s2),vx,vy,flag),flush=True)
