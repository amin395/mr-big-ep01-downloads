# DNSMOS P.835 (SIG = speech quality, BAK = background/room cleanliness, OVRL). Scale 1-5.
import sys, numpy as np, soundfile as sf, soxr, onnxruntime as ort
S = ort.InferenceSession('/tmp/claude-0/-home-user/3874b11f-661d-56e8-b564-35aaeabbb3e4/scratchpad/models/sig_bak_ovr.onnx', providers=['CPUExecutionProvider'])
LS = int(9.01 * 16000)
p_ovr = np.poly1d([-0.06766283, 1.11546468, 0.04602535]); p_sig = np.poly1d([-0.08397278, 1.22083953, 0.0052439]); p_bak = np.poly1d([-0.13166888, 1.60915514, -0.39604546])
def score(x, sr):
    x = np.asarray(x, np.float32); x = x.mean(1) if x.ndim > 1 else x
    a = soxr.resample(x, sr, 16000) if sr != 16000 else x
    while len(a) < LS: a = np.append(a, a)
    hops = max(1, int(np.floor(len(a) / 16000) - 9.01) + 1); r = []
    for i in range(hops):
        seg = a[i * 16000:i * 16000 + LS]
        if len(seg) < LS: continue
        o = S.run(None, {'input_1': seg[None].astype(np.float32)})[0][0]
        r.append((p_sig(o[0]), p_bak(o[1]), p_ovr(o[2])))
    return np.mean(r, 0)
if __name__ == '__main__':
    for f in sys.argv[1:]:
        x, sr = sf.read(f, dtype='float32'); s = score(x, sr)
        print('%-40s SIG %.2f BAK %.2f OVRL %.2f' % (f.split('/')[-1], *s))
