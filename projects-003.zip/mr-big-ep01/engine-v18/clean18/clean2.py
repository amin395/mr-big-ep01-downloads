# v18 studio voice cleaner. Every stage is sample-aligned and length-preserving.
#  1. De-reverb: anvuew BS-Roformer dereverb (SDR 22.5), removes room reflections/tail.
#  2. De-noise: DeepFilterNet3 (48 kHz), attenuation-limited so it never eats voicing.
#  3. Tone: linear-phase match EQ toward a booth reference (real recordings only), de-box, presence.
#  4. Dynamics: gentle compression, de-ess, no gate.
# usage: python clean2.py <in_dir> <out_dir> [names...]
import sys, os, json, subprocess, numpy as np, soundfile as sf
from scipy.signal import firwin2, fftconvolve, welch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from derev import dereverb
from pedalboard import Pedalboard, HighpassFilter, PeakFilter, HighShelfFilter, Compressor
SR = 44100
HERE = os.path.dirname(os.path.abspath(__file__))
REAL = {'KIM', 'AMIN2', 'AH', 'AT2', 'ETB'}           # real mic recordings (phone / room)
MALE = {'AMIN2', 'AH', 'AT2', 'ETB', 'E1N', 'P1', 'P2'}

def dfn(x, att):
    tmp = os.path.join(HERE, 'tmp_dfn'); os.makedirs(tmp, exist_ok=True)
    a, b = tmp + '/in.wav', tmp + '/out.wav'
    sf.write(a, x, SR, subtype='FLOAT')
    subprocess.run([HERE + '/venv2/bin/python', HERE + '/dfn.py', str(att), a, b], check=True, capture_output=True)
    y = sf.read(b, dtype='float32')[0]; assert len(y) == len(x); return y

BANDS = np.array([80, 100, 125, 160, 200, 250, 315, 400, 500, 630, 800, 1000, 1250, 1600, 2000, 2500, 3150, 4000, 5000, 6300, 8000, 10000, 12500])
def ltas(x):
    f, p = welch(x, SR, nperseg=4096)
    act = x  # band levels in dB, 1/3-octave
    out = []
    for c in BANDS:
        lo, hi = c / 2 ** (1 / 6), c * 2 ** (1 / 6); m = (f >= lo) & (f < hi)
        out.append(10 * np.log10(p[m].mean() + 1e-20))
    out = np.array(out); return out - out[BANDS.tolist().index(1000)]

def match_eq(x, ref=None, maxdb=6.0):
    # de-box: flatten resonant bumps of the room/phone against the voice's own smooth spectral trend
    lv = ltas(x); lf = np.log2(BANDS); m = (BANDS >= 160) & (BANDS <= 6300)
    trend = np.polyval(np.polyfit(lf[m], lv[m], 2), lf)
    d = np.clip(trend - lv, -maxdb, 3.0); d[~m] = 0
    d = np.convolve(np.pad(d, 1, mode='edge'), [0.25, 0.5, 0.25], 'valid')  # smooth
    d[BANDS < 120] = np.minimum(d[BANDS < 120], 0)   # never boost rumble
    d[BANDS > 9000] = np.minimum(d[BANDS > 9000], 3)  # never boost hiss hard
    fr = np.concatenate([[0], BANDS, [SR / 2]]) / (SR / 2)
    g = 10 ** (np.concatenate([[d[0]], d, [d[-1]]]) / 20)
    h = firwin2(2047, fr, g)  # linear phase, delay 1023
    y = fftconvolve(x, h)[1023:1023 + len(x)]
    return y.astype(np.float32), d

def deess(x, f0=5500, thr_db=-30, maxcut=6):
    # split-band de-esser: attenuate only the >f0 band when it spikes over the broadband level
    from scipy.signal import butter, sosfiltfilt
    sos = butter(4, f0, 'hp', fs=SR, output='sos'); hi = sosfiltfilt(sos, x); lo = x - hi
    w = 512; e_hi = np.sqrt(np.convolve(hi ** 2, np.ones(w) / w, 'same') + 1e-12); e = np.sqrt(np.convolve(x ** 2, np.ones(w) / w, 'same') + 1e-12)
    r = 20 * np.log10(e_hi / e)  # how much of the energy is sibilance
    cut = np.clip((r + 6) * 1.0, 0, maxcut)  # sibilance louder than -6 dB rel -> cut
    return (lo + hi * 10 ** (-cut / 20)).astype(np.float32)

def clean2(name, x, ref):
    x = np.asarray(x, np.float32); L = len(x); pk = np.abs(x).max() + 1e-9; x = x / pk * 0.5
    real = name in REAL
    d, r = dereverb(x, 'bs')
    info = {'room_removed_db': round(float(10 * np.log10((r ** 2).sum() / ((d ** 2).sum() + 1e-12) + 1e-12)), 1)}
    y = dfn(d, 18 if real else 8)
    if real:
        y, eq = match_eq(y); info['eq'] = np.round(eq, 1).tolist()
    hp = 75 if name in MALE else 90
    b = Pedalboard([HighpassFilter(hp), Compressor(threshold_db=-24, ratio=2.2, attack_ms=10, release_ms=140)])
    y = b(y.astype(np.float32), SR)
    y = deess(y)
    y = y[:L]; y = np.pad(y, (0, L - len(y)))
    return (y / (np.abs(y).max() + 1e-9) * 0.7).astype(np.float32), info

def refs(lines_dir):
    # booth references: the clean studio/TTS lines of each voice type
    get = lambda n: sf.read(f'{lines_dir}/{n}.wav', dtype='float32')[0]
    fem = np.concatenate([get(n) for n in ('FV1a', 'FV1b', 'F1', 'F2', 'K13', 'D1')])
    mal = np.concatenate([get(n) for n in ('E1N', 'P1', 'P2')])
    return {'female': ltas(fem), 'male': ltas(mal)}

if __name__ == '__main__':
    src, dst = sys.argv[1], sys.argv[2]; os.makedirs(dst, exist_ok=True)
    names = sys.argv[3:] or sorted(f[:-4] for f in os.listdir(src) if f.endswith('.wav'))
    R = None; log = {}
    for n in names:
        x = sf.read(f'{src}/{n}.wav', dtype='float32')[0]
        y, info = clean2(n, x, R); sf.write(f'{dst}/{n}.wav', y, SR, subtype='FLOAT'); log[n] = info
        print(n, 'ok', len(y) == len(x), info, flush=True)
    json.dump(log, open(f'{dst}/clean2-log.json', 'w'))
