# FOREVER PICTURES mix engine, v18 (studio voice pass, 2026-11-15)
Built on engine-v17b. Run from a copy of engine-v17b/ with v17/build.py + v17/master18.py replaced by the ones here.
    C2=<engine-v18>/clean18/lines ETHDIR=<engine-v18>/clean18/eth STEMS=1 python3 v17/build.py v18
    python3 v17/master18.py v18        # -14 LUFS, true peak <= -1 dBTP (4x oversampled limiter)
    VOCONLY=1 (same env) python3 v17/build.py v18 ; then joincheck.py on voconly.wav + voxonly.wav
## Voice cleaner (clean18/clean2.py), applied AFTER tighten(), sample-exact same length, zero latency
1. De-reverb: anvuew BS-Roformer dereverb (huggingface.co/anvuew/dereverb_bs_roformer, SDR 22.5) via derev.py
2. De-noise: DeepFilterNet3 (huggingface.co/fal/DeepFilterNet3), atten limit 18 dB real recordings / 8 dB TTS (dfn.py, separate venv numpy<2)
3. De-box EQ (real recordings KIM, AMIN2, AH, AT2, ETB only): linear-phase FIR flattening resonant bumps vs the voice's own smooth trend (cuts up to 6 dB, 160 Hz-6.3 kHz)
4. HPF 75/90 Hz, compressor 2.2:1 @ -24, split-band de-esser. NO noise gate, NO non-stationary noisereduce (it stripped voicing in v17).
Ethiopia: ETB = Amin's pick Andre voice change (clean/raw/ETB_vc.wav) + warm EQ; AT2 = clean/raw/AT2_raw.wav + presence EQ. Both dry.
## Timing change vs v17 (place())
Settle delays now come out of the pauses inside a block (gaps shrink, never below 0.30 s, PRE holds kept), never out of the join. Every spoken->sung join reserves JOIN=0.31 s (0.28 gap + 0.03 xf). Partial settle shifts allowed. Section marks identical to v17.
Quality report: clean18/eval.txt (DNSMOS raw / v17 / v18 per line), clean18/resid.txt (room left).
