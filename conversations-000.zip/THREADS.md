# MR BIG BEAUTY project: conversation threads (as of 2026-11-17)

| Thread | Started | Last activity | Messages | State |
|---|---|---|---|---|
| Mr. Big Beauty brief review | 2026-10-14 | 2026-10-23 | 775 replies | closed (session got stuck 10-23) |
| Buried concept review (Forever Pictures production) | 2026-10-23 | 2026-11-17 | many hundreds | open, waiting on Amin (17 + 20 card) |
| Studio-clean the Forever Pictures voices | 2026-11-15 | 2026-11-15 | short | done |
| Package project downloads as zips | 2026-11-17 | 2026-11-17 | this one | working |

Full word-for-word transcripts of these threads and the project chat are not in this zip.
They come from Claude's own account export: claude.ai > Settings > Privacy > Export data.
That export arrives by email as zips named like conversations-000.zip, projects-000.zip,
memories-000.zip and claude_code_cloud-000.zip. Only the account owner can request it.

What this zip does hold: the list of every review page (PROJECT-PAGES.md), the thread list
above, and the running production history notes kept in project memory
(history/forever-pictures-history-*.md), which log every decision by date.
