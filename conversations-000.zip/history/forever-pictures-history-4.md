---
name: forever-pictures-history-4
description: Archived Forever Pictures status log part 4 (11-04: voic back to Files: voic)
metadata:
  type: project
---
- 11-04: voice auditions GO'd (see VOICES). Pending Amin: Higgsfield photo uploads (Kimmy 3-5, his 3 selfies, booth photo); Ms. Faye actor recording.
- 10-28 04:10: CURRENT = Forever Pictures v8 timed cut 7:19 https://claude.ai/artifact/CUZ8qinHfoThgHHGPxoKy5 (song master 35M2 + stems in mr-big-ep01/music-suno/), ~900 cr, awaiting runtime pick + phase 1 GO.
- 10-26 17:05: CASTING docs sent (Amin casts real voices first; AI only for unfilled roles he names). 10-26: SCRIPT every line https://claude.ai/artifact/38vCap2nhiFTxT4Pu9ed8u (10 lip-sync ~65 cr). 10-24 21:20: Forever Pictures v6 https://claude.ai/artifact/PWXH8nDpQ4hKfzzNRKnjth. Never invent habits: back every problem beat with a source. [[yo-fresh-storylines]]
- 10-24 05:20: Forever Pictures full story v2 https://claude.ai/artifact/8VcCYhFcq1oBn9j1jSxMVm. Redacted certs (2 COA + Ethiopia phyto) in mr-big-ep01/coa/; no certs on screen.
- 10-23 17:57: Amin wants origin + wedding MIXED into ONE film (not two standalones); separate origin film maybe later.
- 10-23 15:10: Wedding v3 https://claude.ai/artifact/1cDUcxhtGDP531QtzHcpq6. Say "20 plant ingredients".
- Origin draft "Straight to the Source" https://claude.ai/artifact/BCkgva1LtGhmeu64CNs664 (merged with wedding).
- STORY "BURIED" 90-96s hero (pack https://claude.ai/artifact/TTALSiixy6RtrW1rGh4Bez). Style GO'd: stylized 3D Pixar.
- Market research doc https://claude.ai/artifact/9dTbfpHsEnRF2nBzsei8Ec ("Break the cycle").
- Superseded: Storytime, Madame SINGS, "The Napkin", "THE SPY", skit cuts (on hold).
- Files: voices/_ROOM-MATCHED/, sfx/, CLIPS-EP01.md, Higgsfield sandbox ~/edit pipeline.
