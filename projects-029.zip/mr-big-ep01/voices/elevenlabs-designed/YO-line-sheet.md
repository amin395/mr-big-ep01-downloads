# YO line sheet (ElevenLabs)

**How to use:** in ElevenLabs Text to Speech, pick the voice, paste one box at a time, and generate 2 takes. Leave the line breaks in: they give the natural pauses I cut on. Download and drop the takes here, and say which scene or role each one is.

Words in [brackets] are acting directions. ElevenLabs reads the tone and doesn't speak them.

## Short roles

Paste each line in its own box. They're short, so 2 or 3 takes of each.

**Ms. Dee (YO – Ms. Dee 1)**

```
[softly, tired, gently brushing it off] Take it without me, baby.
```

```
[tender, almost a whisper] Let me.
```

**Kenya at 14 (YO – Kenya 14)**

```
[embarrassed, quiet, hesitant] Mama... can you stand in the back?
```

**Kenya at 31 (YO – Kenya 31)**

```
[emotional, voice catching, then firm] Mama, I asked you to stand in the back once. Never again.
```

```
[tender, soft] Let me, Mama.
```

**Photographer (YO – Photographer)**

```
[excited, projecting to a crowd] Family of the bride! Everybody in!
```

```
[warm, calling out] Family of the bride!
```

**Ghana elder (YO – Ghana Elder)**

```
[calm, knowing, a little teasing] You want it fast, or you want it right?
```

**Ethiopian farmer (YO – Ethiopian Farmer)**

```
[proudly, slowly] T'ikur azmud.
```

## Ms. Faye (YO – Ms. Faye)

38 lines, one box per scene (numbered to match the film). Paste the whole box and generate 2 takes.

**Scene 1: The picture she keeps walking out of**

```
[warm, storytelling, unhurried] Every family's got a picture. Some of us been hiding from ours for years.
Seventeen years out of frame. Here's where it started.
June, two thousand nine. Off a double, still in scrubs, her edges sweatin' out in the heat.
Kids say things quick. Mamas carry them long.
```

**Scene 3: The armor**

```
[knowing, a little heavy] Now that baby's an ICU nurse. Takes care of every body but her own.
Eleven bottles. Six hundred dollars. Chasing the shine she was ashamed of at fourteen.
She did everything they said. Nobody said what was underneath.
She don't wear makeup. She wears armor. 'Cause the room don't forgive.
Cover it. Layer it. Sleep in it. Do it again.
```

**Scene 4: The chair**

```
[sassy, loving, blunt] Kenya sat down proud. 'Look at my glow.' Baby, that ain't glow. That's buildup.
Little bumps at the hairline. 'How long?' 'Since nursing school.'
Creams, gels, waxes. What you put on your hair don't stay on your hair.
Simone ain't let nobody at work see her real skin in fifteen years.
I told her, it's beautiful. It's just tired of carrying all that.
Back then they called it shine. Now your phone calls it glass. Baby, it's the same buildup.
```

**Scene 5: Every stage**

```
[warm, testifying] Twenty-five years in this chair. The prom girl. The new mama. The nurse off nights. The boss. The grandmama still doing what her mama did. Same story.
Nobody made it for our skin, our shifts, our sweat. So we piled it on. Your mama wasn't wrong. She was making do.
And them videos never asked what skin you got. You ain't doing too little. You doing too much of the wrong thing.
```

**Scene 6: The source**

```
[proud, clear, teaching] Not all black soap is the same. And washing's only half. Wash it right, then feed it right. One without the other don't work.
Him: fifteen years in this business. Her: raised in her mama's esthetics room, where every woman got washed first, then fed. So he went to the source.
That plain bar left you tight. This one's made in Ghana, with three things plain don't have. Sea moss, so you rinse soft, not tight. Black seed, to nourish while you wash. And jojoba, a liquid wax close to what your own skin makes.
It helps lift the buildup: the creams, the gels, the sweat, yesterday's makeup. Cleanses, exfoliates, tones. Face and body. Never stripped.
Ethiopian black seed. Found in King Tut's tomb. Lab-tested at over four percent TQ, the antioxidant black seed is prized for. Most oils tested on the market came in under two. And it's in every YO bottle.
Kenya rubbed her hands. 'Huh. It don't feel tight.' Then, 'Is that peppermint?'
```

**Scene 7: Wash it off**

```
[soft, reverent] Same soap. Other side of the ocean.
```

**Scene 8: Feed it**

```
[rhythmic, on the beat, playful] Now we feed it. Ten oils. Two drops.
Rosehip, smooth under foundation. Turmeric, for that warm radiance. Argan, almond, vitamin E, for the mama on no sleep. Calendula, after a hot shift. Grapeseed, light under a mask. Jojoba and black seed, the family. And copaiba.
Co-pai-what? Exactly. From South America. He studied it till he knew why it belonged.
Glass sits on top. This sinks in. The wash clears the way. The oils feed it and seal the deal.
Now that's a canvas.
Then the body. Seven oils, face to feet. Absorbs fast. Even the groom's ankles.
Not a mark on that dress.
Ghana in the wash. Ethiopia in every bottle. Mixed and bottled right here at home. Twenty plant ingredients. Three bottles. Thirty-seven ninety-seven. Five stars. One review just said, 'Black gold.'
```

**Scene 9: Thirty nights**

```
[warm, satisfied] Thirty nights. Wash, then feed.
Her mama took the longest to believe. Then she did.
```

**Scene 10: Get in the picture**

```
[to camera, slow, every word lands] It ain't your skin. It ain't your fault. It's the buildup sitting on it. Wash it off. Feed it right. Then get in the picture.
```

**Scene 11: The exit**

```
[bright, proud] YO. Your Original Skincare. Black-owned. Family-founded. The Complete Routine, thirty-seven ninety-seven.
Online, or at your beauty supply.
```
