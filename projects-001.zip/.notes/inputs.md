# Inputs notes (written by sessions; information only)

## Mr. Big Ep01 reference images (uploaded 2026-10-14, thread "Mr. Big Ep01 brief review")
All PNG, 1520x2688 portrait collages unless noted.
- char_mr-big_Referance.png: heavyset Black man, glossy curly top + fade, goatee, black/gold damask 3-piece suit, giant diamond Cuban chain; medallion text is GARBLED AI lettering ("BIG BAGS BEAUTY"), fix before use. Extreme oily skin.
- char_ms-mark-up_Referance.png: Madame Markup. Ivory jacquard coat-dress, big black curls, gold hoops, ivory handbag, red-soled ivory pumps; emerald marble + gold office background. Radiant non-greasy skin.
- char_mr-big-assistant_Referance.png: bald muscular man, mustache, black sleeveless valet vest w/ green piping, white gloves, silver tray (gold fan, mirror, lint roller, green towel). Oily.
- char_ms-anylist_Referance.png: Marketing Analyst ("Ms. Anylist"). Short curly updo, emerald double-breasted suit, ivory blouse, tablet. Oily.
- char_mr-12-steps_Referance.png: older man, glasses, grey beard, green frock coat, strapped w/ LED mask, vials, gadgets. NOT in original brief; proposed as new character.
- prop_oily-shiney-sticky-skin / prop_glowing-skin (1536x838): SAME two models oily vs glowing. Texture refs only; never show side by side in ads (before/after policy risk).
Deliverables: /mnt/project-files/mr-big-ep01/
Shared copies in /mnt/project-files/uploads/hearth/ (no extension, ID prefix matches): a4af2dbf=mr-big, 1e5ebfb7=ms-mark-up, 6009d379=assistant, 3dc0033d=ms-anylist, d7f37bc9=mr-12-steps, 66cd79fa=oily-skin, dccf6dec=glowing-skin.

## YO SKINCARE product photos (uploaded 2026-10-14)
Copied with clear names to /mnt/project-files/mr-big-ep01/products/. Front, back (ingredients) and side (benefits) for Peppermint African Black Soap (9 fl oz), SUPA GLO 10 Oil Facial Elixir (2 fl oz) and SUPA GLO Body Oil (8 fl oz).
- Elixir and Body Oil fronts: 4750x4750 RGBA, real transparency.
- Soap front: 1254x1254 RGB with a FAKE checkerboard baked in (no alpha). Needs a real transparent version before compositing.
- 2026-10-14 later: Lemongrass + Unscented soap front/back/side (real RGBA transparency), YO circle logo (500x500 RGBA, small), in products/. Skyline refs in mr-big-ep01/skyline-refs/: sky1 (Getty watermark) and sky4 (Dreamstime watermark) DO NOT USE; sky2 aerial downtown (597x335) is the chosen Step 1 reference; sky3 Midtown aerial; sky5 freeway. All are small, likely stock.

## YO SKINCARE brand songs from Amin's Google Drive (pulled 2026-10-20 via Drive connector)
Folder: /mnt/project-files/mr-big-ep01/music-drive/ (MP3, 44.1k). Songs by Amin and Kimmy (founders). All are vocal hip-hop, R&B or dance tracks with brand lyrics. Instrumental stretches are noted in brackets.
- We_Don_t_Play_Memphis_HipHop (147.8s): the "We Don't Play About the Brand" song family. Hook "We don't play about the brand" ~44-64s and 112-128s; "yo yo yo skincare" 136-144s.
- Glow_Tonight_Disco (108.3s, ~123 BPM): disco. [0-8s, 32-40s, 64-72s, 88-104s].
- Glow_Like_Dat_Kimmy (105.6s): 7.6-16.4s sings "Keep yourself beautiful, don't gotta go broke for that" (matches the tagline).
- Dead_Glo_Lil_Baby (154.1s, ~136 BPM): trap. Has "Don't gotta go broke to shine". [120-128s, 144-152s].
- YO_Da_Real_Deal (111.7s): [32-48s, 88-111s outro]. Identical file to YO_OG_Supa_Glo.
- YO_Anthem_Amapiano (89.2s): identical file to YO_Remember_It_Well.
- Also: YO_From_The_Founders (125.2s), YO_Is_Back_15_Months (90.2s), We_Da_Purist (132.4s), Come_Back_To_It_R_B (70.8s, slow R&B).
- Lyric transcripts (ASR, rough) are in the session scratchpad only. Auditions are in music-drive/auditions/.
