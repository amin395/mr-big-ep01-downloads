# Scene 4 video plan (V18 to V21): the enemy, the inside job, the punchline, the exit. Pre-checked 2026-10-15 17:48

Model: Kling 3.0 Pro, 9:16, sound off, start frame only. **Total 38.5 cr = HARD CAP.** Nothing runs before Amin's clear GO on this number.

| Shot | Start frame | Length | Cost | What happens |
|---|---|---|---|---|
| V18 "The enemy" | F1-stern (media bad4886e) | 5s | 8.75 | Mr. Big at the button, balcony behind, Assistant behind with BIG SHINE. Full-body rage, shaking, chain swinging, points straight ahead down the table at Madame: "You brought the ENEMY into MY boardroom?!" Never smiling. |
| V19 "Inside job" | F6 (media 3bd08c80) | 5s | 8.75 | In her end chair, exit doors behind. She stands up unhurried, picks up the green Telfar bag by its handles (logo visible), and says with a cool little smile: "Baby, it's an inside job." Smooth, matter-of-fact. |
| V20 The punchline | F7 (job 573accb4) | 6s | 10.5 | Standing in front of her chair at the far end, bag on her arm, doors behind, Mr. Big's back in the foreground. Slow push-in on her. She looks straight down the table and says in one smooth, emphatic line, no pauses: "I mark it up. I DON'T PAY the markup." with the stress landing on "DON'T PAY" (Amin 18:05) Holds a satisfied beat. |
| V21 The exit | F7 (job 573accb4) | 6s | 10.5 | In F7 her chair sits behind her right shoulder and the path to the doors on her left is clear. She simply turns and walks straight back to the exit doors on that open side, never touching or moving the chair (Amin: "walks straight out, no chair weirdness"), opens one, walks out, and the door swings shut. Nobody else moves; executives stare. Chair stays put. |
| V21 hold (free) | F8 (job 127b64aa) | still | 0 | Slow push on the empty chair and closed doors for the "door click" beat. |

Rules applied: Madame's glow boosted in the edit on V19 to V21 (glowvid.py, free). Green Telfar bag in every Madame shot. Nobody stands on the table; she exits through the doors behind her end chair. Mr. Big from the stern frame, never smiling.

## Run (Amin GO 18:06, cap 38.5)
- Jobs: V18 2fa88ae8, V19 6e7e5131, V20 dd711874, V21 ea7f6990.

## Results (QC 18:14). Spent 38.5 of 38.5. Balance 187.35.
| Shot | Job | Result | Edit media |
|---|---|---|---|
| V18 | 2fa88ae8 | PASS: full-body rage, points down the table, never smiling, balcony + Assistant with BIG SHINE behind | raw |
| V19 | 6e7e5131 | PASS: rises from end chair, picks up green Telfar (logo visible) | 732fe221 (glow boosted) |
| V20 | dd711874 | PASS: punchline standing at her end, bag on arm; reflections only on table | 63383e6f (glow boosted + slow push-in) |
| V21 | ea7f6990 | PASS: walks straight out the doors, chair untouched | raw, then hold 8e2a0d48 (2s push on empty chair, door-click beat) |
