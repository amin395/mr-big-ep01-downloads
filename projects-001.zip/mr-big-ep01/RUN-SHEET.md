# Mr. Big Ep01: Run Sheet (Claude runs Higgsfield directly)

Updated 14 Oct 2026. Claude submits every job through the Higgsfield connector. Amin's only jobs are to **say go once per batch** and to **attach the picks** in the thread. Claude can't open Higgsfield links, so it can only check images that are attached. The fix for that is under "Speed fix" below.

## How a batch runs
1. Claude posts one line: what's in the batch and its estimated credits. Estimates are 2x Higgsfield's quote, because the quote has run low.
2. Amin says go. That one go covers the whole batch.
3. Claude submits every job in the batch in parallel.
4. Amin opens the result links, picks the winners, and attaches them in the thread.
5. Claude checks each attachment against its pass check. Passes go to `approved/` and `ASSETS.md`. A fail is re-run with one change.

## Batch 1: stills (Nano Banana Pro, 2K)
| Asset | Step | Higgsfield job(s) | Refs used | Status |
|---|---|---|---|---|
| IMG-04 boardroom | 3 | 0239b8e8 | Madame + Ms. Anylist elements (materials) | ✅ Locked |
| IMG-06 medallion | 2 | 8075ba61 (Fix 3) | edit of 0a693347 | ✅ Locked, Element EP01_MrBig_Medallion |
| IMG-05 button insert | 6 | 0f6a7ed9 (blank plate) | IMG-04 | ✅ Locked |
| IMG-07 BIG SHINE | 6 | 30c81577 | none, 1:1 | ✅ Locked, Element EP01_BigShine |
| IMG-08 handbag plate | 6 | 8eaa73dc | Madame element | ✅ Locked |
| IMG-09 end-card background | 6 | 9a497aa1 | none | ✅ Locked |
| IMG-02 aerial start frame | 5 | (blocked) | needs IMG-01 in Higgsfield | Waiting on tower upload |
| IMG-03 balcony + Mr. Big | 4 | (blocked) | needs IMG-01 + fixed Mr. Big | Waiting on tower upload and IMG-06 |

**Tower note:** the locked IMG-01 doesn't match any Higgsfield job. The jobs 3711bf60 and c57bf8e2 don't have the Bank of America spire or the ball-tipped crown, so they aren't it. IMG-01 has to be uploaded into Higgsfield once, by Amin or by Claude after the speed fix.

## Batch 2: Elements (free, no credits)
Done 14 Oct: EP01_MrBig_Medallion (eaf71b23), EP01_Boardroom (546e0a6a), EP01_BigShine (3c9ba29f). Still to make: Tower and Balcony, once IMG-01 is in Higgsfield.

## Batch 3: test shot V03 (Cinema Studio Video 3.0)
The connector offers Cinema Studio Video 3.0 (4.0 isn't listed). V03 settings: 9:16, 1080p, 6s, comedy, audio on (guide voice for lip shapes), start frame IMG-04, Elements MrBig and oily skin. Quote: 78 credits for 2 takes. It's a gate: nothing else runs until V03 passes.

## Batch 4 onward: V01 to V22 in groups of 3 to 5
Same pattern. Voices go to ElevenLabs (file 03) and can run any time, outside Higgsfield.

## Speed fix (do once)
This workspace's network blocks `upload.higgsfield.ai`, `d2ol7oe51mr4n9.cloudfront.net` and `d8j0ntlcm91z4.cloudfront.net`.

- **Where to fix it:** add those three hosts in Project settings, then Cloud environment, then Add cloud environment, then Network access, then Allowed domains.
- **What it fixes:** Claude can then see every render itself and upload local files such as IMG-01 and the product photos. Amin no longer has to attach anything.
- **Docs:** https://code.claude.com/docs/en/cloud-environments#network-access

## TinyFish
TinyFish can open Higgsfield links, but it misreads small lettering. In testing it read the same medallion three different ways. Use it only for "is X in the picture" checks, never for spelling.

## Video pricing (checked 14 Oct)
- Higgsfield's price check quotes **one take** even when count is 2. V03 was quoted 78 credits and actually cost 156 for 2 takes.
- Cinema Studio Video 3.0: about **13 credits per second at 1080p** and **5 per second at 720p**, per take.
- V03 rendered: take A is job e92f6c81, take B is job de3f9f6f. Balance after V03: 2,559.5.
- The remaining 21 clips (V01, V02, V04 to V22) add up to about 121 seconds. One take at 1080p is about 1,575 credits.

## Budget options (priced 14 Oct, per take, per second)
| Model | Credits per second | 121 seconds |
|---|---|---|
| Cinema Studio Video 3.0, 1080p | 13 | ~1,575 |
| Cinema Studio Video 3.0, 720p | 5 | ~605 (plus Topaz upscale, which has no price check) |
| Cinema Studio Video 3.0, 480p | 3.5 | ~425 |
| Seedance 2.0, 720p | 4.5 | ~545 (1080p is 12/s) |
| Kling 3.0 Pro | 2.5 | ~300 (needs a start image to use elements) |
| Cinema Studio Video 2 Pro | 2 | ~240 (Std is 1.5/s) |

Recommended hybrid: Cinema Studio 3.0 at 1080p for the 8 dialogue close-ups (V06, V09, V12, V14, V15, V18, V19, V20; about 48 seconds), and Cinema Studio Video 2 Pro for the rest. That's about 960 credits with re-runs. Decision card posted to Amin.
Video 2 Pro test running: V04 is job 12c6973c, V07 is job 3cb235d5. Note: Video 2 can return a preset suggestion instead of a job. Re-submit with declined_preset_id when it does.
Clip packet: packets/batch4_boardroom_clips.json (18 clips, prompts already contain the element placeholders).

## Batch 4 submitted (hybrid, 14 Oct)
Balance went from 2,552 to 1,836.5, so this batch cost 715.5 credits.
- **Cinema Studio 3.0, 1080p, audio on:** V06 73b25e05, V09 d6093565, V12 60a0f092, V14 483333ad, V15 e9b72f8c, V18 b1efb568, V19 1e05f86b, V20 4868d33a.
- **Video 2 Pro:** V04 b5413642, V05 62a06e7a, V08 696d1841, V10 f78fd5ea, V11 c68b2eba, V13 d0d5c20e, V16 3a2f97c8, V21 f4115c7a, V22 541df139.
- V12, V21 and V22 needed declined_preset_id 24bae836 ("IN THE DARK") to submit.
- V03 passed QC and is filed (approved/video/V03_v1.mp4). V07 is usable (approved/video/V07_v1_csv2.mp4).

## Skin rule (Amin, 14 Oct, applies to every shot)
Every boardroom cast member except Madame Markup must have the same very oily, greasy, shiny skin. Madame alone keeps the natural satin glow.
- **For every new prompt:** put the oil description first, use the OilySkin element (0df61f80), and name each non-Madame person in frame as greasy.
- **Video 2 Pro wide shots ignore a short "skin glistens" line.** V07 v1 came out with every executive matte, which fails this rule. V07 v1 is pulled from approved. The re-run with oil-first wording is job 6286ecb9.
- **V03 passes:** Mr. Big is dripping with oil.
- **Check carefully at QC:** V04 and V07 (wide shots on Video 2 Pro), V21 (background executives), and V22 (Ms. Anylist's prompt had the element but no oily wording).

## Consistency QC checklist (Amin's standing rule, 14 Oct)
Every new asset, prompt and clip must match what is already approved and directed. The reference is approved/ plus the locked decisions. Any mismatch is flagged before it goes into the cut.
- **Characters:** faces match their Elements. Mr. Big has his curly hair, goatee, and black-and-gold floral suit.
- **Medallion:** reads BIG BAGS / BEAUTY / MR. BIG'S.
- **Skin:** everyone is oily except Madame, who has an intense natural glow and wears no makeup.
- **Wardrobe:**
  - Madame: ivory coat-dress, red-sole pumps.
  - Assistant: black vest, white gloves.
  - Mr. 12 Steps: green frock coat.
- **Set:** emerald and gold marble boardroom, as in IMG-04, with the city through the balcony doors. Lighting is warm prestige-sitcom.
- **Full table:** the table is full of greasy executives, 8 to 10 of them down both sides. Characters sit in chairs, never in or on the table. Madame is visible whenever a line is aimed at her.
- **Props:**
  - Red button on a gold base (IMG-05).
  - BIG SHINE gold mister (IMG-07).
  - Ivory handbag (IMG-08).
- **Lines:** match the script word for word.
- **Prices:** $9.99, $15.99, $13.99, and $37.97 for the routine.
- **No stray text or gibberish lettering** in frame.

## Amin's notes on Batch 4 (14 Oct, 14:56)
- **V13 is terrible.** Mr. 12 Steps was placed in the table, with only two board members visible.
- **V14 is terrible.** Mr. Big was in the table, there were no board members, and Madame's face wasn't visible.
- **New consistency rule:** every boardroom shot shows the table full of greasy executives, 8 to 10 of them seated down both sides. Each character sits in a chair, never in or on the table. When a line is aimed at Madame, her face is visible.
- **Re-runs** use Cinema Studio 3.0 at 1080p, 6s, with the full-table wording: V13 is job b19586d7, V14 is job 391228f1. Expect about 156 credits.
- Balance before the re-runs was 1,829. The V07 re-run cost 7.5.
- **V15 line change (Amin, 14:59):** "grease spill" is now "oil spill". The change is made in 02, 03 and the packets. V15 was re-run on CS 3.0 at 1080p, 7s, with a full table behind Madame (job 4ffe6a07, ~91 credits).
- **Captions for V15** must read word for word: "I discovered the difference between a glow and an oil spill." The voice keeps the lead-in "Because, darling..." unless Amin cuts it.
- **V18 (Amin, 15:01): not over the top enough.** He just yelled and pointed. The re-run is a full meltdown: chair flies back, fists slam, his body trembles, oil flies, with a full table in shot. CS 3.0 at 1080p, 6s, job e84b0eec, about 78 credits. **Direction rule:** Mr. Big rage beats are always cartoonishly over the top.
- **Madame glow (Amin, 15:02): her glow must be much more intense, noticeable and radiant.** V15 v3 uses glow-first wording and beauty-ad lighting (job 40aa3395, about 91 credits). V15 v2 (job 4ffe6a07) has the weaker glow and is a fallback only. V19 and V20 will be matched to V15 v3 once Amin approves that look. **Rule:** Madame is always luminous and lit from within, never greasy.
- **V20 (Amin, 15:04): terrible, because Madame walks on the table.** The re-run has her standing on the floor beside her chair, the intense glow, the handbag, and a full greasy table behind her. CS 3.0 at 1080p, 6s, job 44b6204b, about 78 credits. **Prompt rule:** always say "on the floor beside the table, never on the tabletop". The model keeps putting people on or in the table.
- **V21 (Amin, 15:04): terrible, because Madame walks on the table.** The re-run moved to CS 3.0 at 1080p, 6s, with her walking on the floor past the end of the table toward the exit, and a full greasy table turning to stare. Job 1798cd2d, about 78 credits.
- **V22 (Amin, 15:05): terrible.** There were several Mr. Bigs at the end of the table and the board members were gone. The re-run is on CS 3.0 at 1080p, 5s, with exactly one Mr. Big at the head of the table and 8 to 10 distinct greasy executives (job 405dda70, about 65 credits). **Prompt rule:** say "exactly one Mr. Big; every executive is a different person".

## Oil level (Amin, 15:07, all clips)
Executive skin is far too dry in every clip. The target is refs/oil-level-reference.jpg: faces dripping wet, with thick glossy streaks and oil running down the neck and chest. This is the same image as the OilySkin element, media 17fd7802.

**Plan: an oil edit pass on the existing clips instead of re-rendering.** Kling 3.0 Omni Edit (kling_video_edit, pro) takes the clip and the oil reference image, at about 10 credits per 5s clip. FLUX 3 Video Edit is about 15 credits for the same clip. Seedance 2.5 edit costs 101, so it's ruled out.

**Tests:**
| Test | Model | Job |
|---|---|---|
| V04 | Kling edit | 23c82325 |
| V04 | FLUX | 1c0e2aca |
| V09 | Kling edit | 13d534a6 |

Per-clip notes and latest takes: BATCH4-PICKS.md.
- **Oil pass decision (Amin, 15:32): FLUX 3 Video Edit gives the best oil.** Use FLUX, about 15 credits per clip, for any oil pass on finished clips.

## Rule added 2026-10-14 16:52 (Amin)
- Entrance orientation: when Mr. Big comes in through the balcony door, everyone at the table stays in their own seat and turns toward that door. Seat positions never change between shots. Every executive is a distinct person (no twins or replicas in a frame). All faces oily except Madame.
