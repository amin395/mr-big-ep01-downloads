# Mr. Big Beauty Ep01: Start Here

> **14 Oct update:** Claude now runs Higgsfield directly. The live tracker is RUN-SHEET.md. The ChatGPT blocks below are backup only.

One step at a time. **You don't move to the next step until the current one is approved in the Claude thread.**

## Who does what
| Who | Job |
|---|---|
| **Claude (this thread)** | Writes each step, then checks every image or clip you bring back. Gives the next step only after approval. |
| **ChatGPT** | Receives each step's paste block, checks settings, keeps the Production Log. |
| **TinyFish** | Does the clicking inside Higgsfield: picks the model, sets the ratio, pastes the prompt, attaches files, downloads. |
| **You** | Type **GO** to approve credit spend. Post each result file in the Claude thread. |

## "Done" means done (verification rule)
A step is done only when all four are true:
1. Before Generate, ChatGPT or TinyFish showed you a **screenshot of the settings** (model, ratio, resolution, references) and you typed **GO**.
2. The result is **downloaded with the exact file name** the step gives.
3. You **posted that file in the Claude thread**.
4. Claude replied **"Step N approved."**

ChatGPT saying "done" is not proof. The file is the proof.

## The sequence
| # | Step | Tool / model | Output file | Status |
|---|---|---|---|---|
| **1** | **Tower master (IMG-01)** | Higgsfield Image · Nano Banana Pro | IMG-01_tower_v1.png | ✅ Approved 14 Oct (approved/) |
| 2 | Mr. Big medallion fix (IMG-06) | Higgsfield Image · Nano Banana (edit) | IMG-06_mrbig-medallion_v1.png | ✅ Approved 14 Oct (Fix 3) |
| 3 | Boardroom master (IMG-04) | Nano Banana Pro | IMG-04_boardroom_v1.png | ✅ Approved 14 Oct (approved/) |
| 4 | Balcony with Mr. Big (IMG-03) | Nano Banana Pro | IMG-03_balcony_v1.png | |
| 5 | Aerial start frame (IMG-02) | Nano Banana Pro | IMG-02_aerial_v1.png | |
| 6 | Props: button, BIG SHINE bottle, handbag plate, end-card background (IMG-05, 07, 08, 09) | Nano Banana Pro + your product photos | IMG-05…09 | |
| 7 | Create Higgsfield Elements (characters, rooms, props) | Higgsfield Elements | list of Element names | |
| 8 | Voices: 5 voices, about 20 lines | ElevenLabs (Eleven v3) | VO_[character]_[shot].wav | You can do this any time |
| 9 | **Test shot V03** (button slam) | Cinema Studio 3.0 | V03_v1.mp4 | ✅ Passed 14 Oct |
| 10–14 | Remaining shots in batches of 3–5 | Cinema Studio 4.0 | V01…V22 | |
| 15 | Music: brand-song clip + Suno stings | Your song + Suno | MUS_*.wav | |
| 16 | Edit the ~78s hero, captions, end card | CapCut / Premiere | EP01_hero_v1.mp4 | |
| 17 | Cut the 30s, 15s A, 15s B + 4:5 crop | Same | EP01_30s / 15A / 15B | |
| 18 | Final check vs. acceptance list, upload with AI disclosure | Meta, TikTok, YouTube | | |

All prompts live in `02_higgsfield-prompt-pack.md`. Voices and music are in `03_voices-and-music.md`. Product photos are in `products/`.

---

## STEP 1: paste this whole block into ChatGPT

```
You are my production assistant for a Higgsfield project called "Mr. Big Beauty Ep01." Today we do ONE task only: STEP 1, create the tower master image. Follow these rules exactly.

RULES
1. Do not rewrite, shorten, translate or improve the PROMPT text. Paste it exactly as written between the lines START PROMPT and END PROMPT (do not include those two marker lines).
2. Settings go in Higgsfield's controls, never in the prompt box.
3. Never tell me something is done unless you can show proof (a screenshot or the image itself). If you cannot see or control the screen, give me or TinyFish exact click-by-click steps and wait.
4. Before clicking Generate, stop and show me a screenshot or exact readout of: model, aspect ratio, resolution, number of images, attached reference images (should be NONE), and the credit cost. Wait until I type GO.
5. Do only Step 1. Do not start any other step.
6. Keep a "Production Log" table for the whole project with these columns: Step | File name | Model | Aspect | Resolution | References attached | Credits used | Result. Add a row for Step 1 when it's finished.

TINYFISH CLICK STEPS (if TinyFish is operating the browser)
1. Go to higgsfield.ai and sign in.
2. Open Image (image generation).
3. In the model dropdown, select: Nano Banana Pro
4. Set aspect ratio: 9:16. If 9:16 is not available, STOP and report which vertical ratios are offered.
5. Set resolution: 2K
6. Set number of images: 2 (if that option exists; otherwise 1)
7. Make sure NO reference images are attached. Remove any that are.
8. Click into the prompt box, clear it, and paste the PROMPT below exactly.
9. Screenshot the full settings panel and the prompt box. Show me. Wait for GO.
10. After GO: click Generate and wait for the images to finish.
11. Screenshot the results.

START PROMPT
Photorealistic aerial photograph of the downtown Atlanta, Georgia skyline on a clear, bright afternoon, taken from a helicopter level with the upper floors. Dense green tree canopy between the buildings and a wide multi-lane interstate freeway curving through the bottom of the frame, typical of Atlanta. In the center stands one enormous, bulky, ostentatious corporate skyscraper, clearly wider and taller than every building around it, filling the frame from the street to the top. Its facade is black mirrored glass with polished gold vertical trim running the full height. The lower floors are black-and-cream marble with monumental columns at the entrance. At the very top sits a massive sculpted gold crown. Just below the crown, a huge penthouse balcony with a marble floor and gold railings wraps the front of the tower. On the facade directly below the balcony, giant polished gold three-dimensional letters, each several stories tall, read exactly "MR. BIG'S BEAUTY" in a bold, elegant serif typeface, perfectly spelled, centered and level. Excessive billionaire-vanity architecture that still looks structurally real. Natural sunlight, accurate shadows, realistic glass reflections of the sky and neighboring buildings, light haze, sharp detail, premium architectural photography. No other signs, logos or text anywhere in the image.
END PROMPT

AFTER IT GENERATES
1. Show me every image.
2. Check each image honestly against this list and give me PASS or FAIL for each item:
   a) Vertical 9:16
   b) The gold letters read exactly MR. BIG'S BEAUTY, apostrophe included, no extra or missing letters
   c) A gold crown on top and a big balcony with gold railings just below it
   d) Black glass, gold trim, and a marble base with columns
   e) The tower clearly dominates an Atlanta-looking skyline (trees, freeway)
   f) No other text or logos anywhere
   g) No bent, melted or warped building lines or windows
3. Download the best image and name it exactly: IMG-01_tower_v1.png
4. If item (b) fails on both images: generate ONE more time with the same settings. If it fails again, switch the model to GPT Image, keep everything else the same, show me the credit cost, and wait for GO.
5. Add the Step 1 row to the Production Log, show me the log, and STOP. I will get Step 1 approved before we continue.
```

**Step 1 add-on (14 Oct, after Amin uploaded skyline photos):** send this message to ChatGPT right after the block above.

```
STEP 1 UPDATE: Attach exactly ONE reference image before generating: sky2_aerial-downtown.png (the wide aerial of downtown Atlanta with the freeway). Use it only as a reference for the Atlanta skyline and camera angle. Do NOT attach any image that has a watermark (Getty, Dreamstime or any other). Everything else in Step 1 stays the same, including the prompt. Show me the attached reference in the settings screenshot before I type GO.
```

**Then:** post `IMG-01_tower_v1.png` in the Claude thread. Claude checks it and sends Step 2.
