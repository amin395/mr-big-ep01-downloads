# Ep01 fix plan: keyframe-first (14 Oct)

## Why the clips feel segmented
1. **Every clip was invented from text alone.** Each video model rebuilt the room, the cast and the seating from scratch. That is why tables come out empty, people appear twice, and people stand in or on the table.
2. **There is no master shot of who sits where**, so nothing ties one shot to the next.
3. **The opening is missing.** The HQ exterior (V01) and Mr. Big's balcony entrance (V02) are still blocked, because the locked tower image (IMG-01) can't get into Higgsfield from here.
4. **Video 2 Pro** drops instructions, such as how oily the skin is and how the room is laid out.

## The fix: lock pictures first, then animate them
| Step | What | Cost (credits) | Amin's job |
|---|---|---|---|
| 1 | **Master cast plate.** One wide still of the full boardroom with fixed seats (map below), skin matched to the oil photo, and Madame glowing. | ~10 | Approve 1 image |
| 2 | **Storyboard.** One start frame per shot, each cut from the master plate: 22 stills, shown as one contact sheet in story order. | ~100 | Approve or flag each panel |
| 3 | **Opening.** The HQ exterior and the balcony entrance, built from IMG-01. | ~40 | Upload IMG-01 to Higgsfield once (see below) |
| 4 | **Animate each approved frame** with Kling 3.0 Pro, using it as the start image. The start image fixes the room, the seats and the skin. Any dialogue close-up that fails lip sync gets re-run on Cinema Studio 3.0. | ~300, plus ~150 for re-runs | Pick takes |
| 5 | **FLUX oil pass (Amin picked FLUX)** only on shots that still read too dry. | ~15 per clip | Name the clips |

**Total:** about 600 credits. The balance is about 1,160.

## Seating map (locked once Step 1 is approved)
- **Head of the table, in front of the balcony doors:** Mr. Big **stands** directly behind the red-button pedestal, so the button is always in front of him and the balcony doors are always behind him (Amin, 16:06 and 16:17). He does not sit. There is only one Mr. Big.
- **Standing directly behind Mr. Big:** the Assistant, holding BIG SHINE, in every shot that shows Mr. Big (Amin, 16:57). He and Mr. Big are the only people ever framed against the balcony.
- **Left side, second seat from Mr. Big:** Ms. Anylist, with her tablet.
- **Right side, middle seat:** Mr. 12 Steps, with his gadgets.
- **Remaining seats:** six other executives, all different people.
- **Far end of the table:** Madame Markup, with a SOLID opaque walnut-and-gold exit door behind her. There is no glass and no balcony at her end; the balcony exists only behind Mr. Big (Amin, 16:17).

Everyone except Madame is dripping with oil, as in refs/oil-level-reference.jpg. Madame alone has an intense, radiant glow.

**Orientation rules (Amin, 16:52 and 16:54):**
- Mr. Big enters from the balcony. From that moment every main character is already in the seat above and stays there to the end. Madame leaves only in V21.
- On his entrance everyone turns toward the balcony door.
- Only Mr. Big, with his Assistant behind him, is ever framed against the balcony. Anyone at the table talking to him is shot from Mr. Big's end looking down the table, so the room and Madame's exit doors are behind them.
- Every shot looking down the table from Mr. Big shows the four main seats filled: Ms. Anylist (left, second seat), Mr. 12 Steps (right, middle seat), Madame (far end, exit doors behind her; empty only after V21), plus the other distinct executives.
- Every executive is a different person. No twins or replicas in a frame.

## Story order: the cut follows the brief
1. HQ exterior (V01)
2. Mr. Big's balcony entrance (V02)
3. Button slam (V03, keep)
4. Panic (V04)
5. Assistant (V05)
6. "Affordable!" with the spray (V06)
7. The room freezes (V07)
8. Ms. Anylist's data (V08)
9. "Thirteen ninety-nine?!" (V09)
10. Assistant (V10)
11. Ms. Anylist (V11)
12. "$37.97?" (V12)
13. Mr. 12 Steps (V13)
14. "Why your face ain't shining?" (V14)
15. Madame's "oil spill" line (V15)
16. Greasy close-up (V16)
17. Handbag and products (V17)
18. Mr. Big's meltdown (V18)
19. "Inside job" (V19)
20. "I mark it up" (V20)
21. Madame's exit (V21)
22. The tablet tap (V22)
23. End card

## Getting IMG-01 into Higgsfield (one of these)
- **Option A (fastest):** Amin uploads approved/IMG-01_tower_v1.png into his Higgsfield assets. Claude then finds it there.
- **Option B:** allowlist upload.higgsfield.ai and the two cloudfront hosts. Then Claude can upload files and watch the renders directly.

## Step 1 results: master cast still (14 Oct, 15:35)
| Take | Job | Layout | Oil |
|---|---|---|---|
| A, oiled edit (recommended) | a9b30988 | 1 Mr. Big, 8 seated, Assistant standing, Madame's face visible, nobody on the table | Mixed: one side is wet, the rest only shiny |
| B, oiled edit | 4b1f4d6a | 1 Mr. Big, 7 seated, 1 empty chair | Slightly shiny |
| A, original | 59a7ab70 | Same as A, table full | Slightly shiny |

Faces are small in a wide master, so the oil can't read at the reference level here. Each close-up storyboard frame is built from this master with the oil photo attached, and that is where the dripping shows. A FLUX pass on the finished video covers any leftovers.

## Step 3: opening (14 Oct, 15:50)
- **Tower is in Higgsfield.** Element prop_ep01_tower_Master is a709c9e7, media fcb64861. Amin uploaded it.
- **V01 (HQ exterior)** is animated straight from IMG-01 on Kling 3.0 Pro, 6s, silent, about 10.5 credits a take. Takes: 9009ee13 and 6d8d6a31. IMG-02 is skipped because the tower image already works as the start frame.
- **IMG-03 (balcony master)** uses the tower, Mr. Big and oil elements: takes 91d95145 and 36aea5a5. V02 follows from the approved take.
- **IMG-03 balcony checks:**
  - Take 91d95145 **fails**: wrong Mr. Big (dreadlocks, medallion reads "RICH AS GOLD").
  - Take 36aea5a5 **passes on identity**: one heavyset Mr. Big at the gold railing over the city. His skin reads dry, but his face is mostly turned away. It is used as the V02 start frame.
- **V02 balcony turn** on Kling 3.0 Pro, 5s, silent: takes fe98f30a and f87a104a, about 9 credits each.
- **V01 takes are done:** 9009ee13 and 6d8d6a31.
- **V02 takes done:** fe98f30a (turns and strides) and f87a104a (spins and flings the doors open). Waiting on Amin to pick V01, V02 and the master still.
- **V21 (Amin, 16:01):** the CS 3.0 re-run walks left and right and never exits. **Storyboard rule:** any shot with movement through the room gets BOTH a start frame and an end frame (Kling 3.0 start_image + end_image). V21 runs from Madame rising at her seat to Madame at the exit doors with the table staring after her.
- **V20 delivery (Amin, 16:03):** "I mark it up. I don't pay the markup!" is one smooth, matter-of-fact, emphatic statement. Not choppy, no pauses. The change is made in 03, 02 and the packets. The final voice is ElevenLabs. The video's own audio is only a lip-sync guide.
- **All Madame lines are smooth, matter-of-fact and confident, with no choppy pauses.** V15 and V19 are rewritten to match in 03.
- **Madame's look (Amin, 16:04): no makeup, or close to none, in every shot.** Her skin is naturally, extremely glowing and radiant: the YO SKINCARE result, with none of Mr. Big's "hoopla". "Smoky eye makeup" is removed from every prompt and replaced with "bare-faced, no makeup". Storyboard frames for her must show bare, luminous skin. A heavy-makeup look is a QC fail.

## Re-blocking (Amin, 16:06)
- **V14 failed again:** Madame wasn't in the shot.
- **New blocking:** Madame sits at the end of the table by the exit, and Mr. Big stands beside the red button.
- **Two masters:**
  - **Master A2** (from the foot looking toward the head): take A edited so Mr. Big stands at the button. Job ff9e5141.
  - **Reverse master R** (from the head, behind Mr. Big, looking down the table to Madame and the exit doors behind her). Job de12cb16.
- **Every storyboard frame comes from one of these two masters.**
- **Checks (TinyFish, 16:10):**
  - **A2** (ff9e5141): Mr. Big standing beside the red button. 1 Mr. Big, 7 seated, no empty chairs, nobody on the table. Madame's face is visible with natural makeup.
  - **R** (de12cb16): 1 Mr. Big, 8 seated, Madame at the far end with doors behind her, nobody on the table. Executives read matte at this distance, so the oil gets pushed in the close-up frames.
- **V11 line (Amin, 16:09; he commented on V10, but the line is Ms. Anylist's in V11):** "It gets worse. Their Complete Routine is only thirty-seven ninety-seven. Sea moss, black seed oil, and jojoba. And about seventeen potent botanical oils. And five-star Google reviews." "Other" was dropped from "seventeen other": the kit has a 10-oil Elixir plus a 7-oil Body Oil, which is 17 oils that already include black seed and jojoba.
- **V11 claim check (yoskincare.com combo page, 16:12):**
  - Jojoba is in both the Elixir and the Body Oil, so the kit has at most 16 *distinct* oils, not 17. The page doesn't show the full ingredient lists.
  - Sea moss is in the soap ("African Black Soap blended with Sea Moss, Ethiopian Black Seed Oil and Jojoba").
  - **Recommended accurate line:** "...Sea moss, black seed oil, and jojoba. A ten-oil face elixir. A seven-oil body oil. And five-star Google reviews." **Locked by Amin, 16:16 (Ten and seven).**
- **V08 line (Amin, 16:12):** "Sir, the company's called YO SKINCARE. Their Triple-Action cleanser, exfoliator and toner is nine ninety-nine. SUPA GLO Facial Elixir, fifteen ninety-nine. SUPA GLO Body Oil, thirteen ninety-nine." **Claim flag:** the combo page supports "cleanse" and "gentle exfoliation" but never calls the cleanse a toner. Amin needs to confirm the label says toner, or the line drops it. It runs about 10s, longer than the 8s shot.
- **16:17 correction:** the reverse master showed balcony glass behind Madame, which is wrong.
  - **A3** (c07df507): Mr. Big directly behind the button, with the balcony behind him.
  - **R2** (92988755): solid exit door behind Madame, and the button in front of Mr. Big.

## Ending options (Amin asked 16:18; no new settings, everything stays in the boardroom)
**A. "The Defection" (recommended).** Madame's line (V20), then she walks out (V21), and the door clicks shut.
1. Silence. Ms. Anylist secretly taps Add to Cart (V22, with the chime).
2. NEW V23: chime, chime, chime. Around the table, the greasy executives quietly order on their phones. The Assistant lowers BIG SHINE and orders too. Mr. 12 Steps unstraps his LED mask.
3. NEW V24: Mr. Big, alone at the button, dripping oil: "...What are y'all DOING?!" Mr. 12 Steps, without looking up: "Step one, sir."
4. End card: $37.97, YOSKINCARE.COM, and the brand song. Madame VO: "Keep yourself beautiful. And don't go broke to be beautiful."

Why A: it shows the product winning (social proof), it pays off the 12-steps gag ("it's 3 steps"), and the villain is left alone. It adds 2 shots, about 20 credits on Kling.

**B. "Mr. Big caves."** After the exit, the Assistant raises BIG SHINE and Mr. Big swats it away: "Put that down." Then he leans over Ms. Anylist's tablet: "...Does it come in my size?" Funny, and it costs 1 shot. But it ends on the villain, not on the product.

**C. "Door slam."** End on Madame's line, the door shutting, and the end card. It's the cheapest, but the weakest finish and has no buying moment.

The 30s and 15s cuts keep their current endings (V20, the chime, then the end card) under every option.
- **Checks (16:22):**
  - **A3** (c07df507) **passes:** Mr. Big stands behind the button, with the balcony behind him and no other glass in the room. 9 seated; the 1 empty chair is his own.
  - **R2** (92988755): solid opaque doors behind Madame and the button in front of Mr. Big, but **3 empty chairs**. An edit is running to fill them.
  - **R3** (3dcd3d97) **passes:** 11 seated, no empty chairs, solid doors behind Madame, the button in front of Mr. Big, nobody on the table, 1 Mr. Big. **A3 and R3 go to Amin for approval.**

## Ending, revised (Amin, 16:23): one defector per episode
**Series arc:**
- Ep01: Madame has already left, and Ms. Anylist defects quietly.
- Next episode: the Assistant.
- Last: Mr. 12 Steps.

In Ep01, the Assistant and Mr. 12 Steps stay loyal. Keep Ms. Anylist's chime. No mass defection.

**Proposed Ep01 ending** (one speaker per shot, all in the boardroom):
1. V20: Madame's line. V21: she walks out, and the door clicks shut.
2. V22: silence. Ms. Anylist secretly taps Add to Cart. *Chime.*
3. NEW V23: Mr. Big whips around at the button: "What was THAT?!"
4. NEW V24: Ms. Anylist slides the tablet face down, deadpan: "...Calendar reminder, sir."
5. NEW V25 (teases the next episode): Mr. Big snaps "Somebody SHINE me!" The Assistant raises BIG SHINE, then hesitates for one beat and glances at the door Madame walked out of. He sprays anyway. Mr. Big doesn't notice.
6. End card: $37.97 and YOSKINCARE.COM, with the brand song and Madame's tagline VO.

That's 3 new short shots, about 25 credits on Kling.

## Ending: LOCKED (Amin, 16:32)
1. V20: Madame's line. V21: she walks out, and the door clicks shut.
2. V22: silence. Ms. Anylist secretly taps Add to Cart. *Chime.*
3. **NEW V23:** *chime... chime, chime.* Several generic greasy executives sneak taps on their phones under the table, then look around innocently as if nothing happened. The Assistant and Mr. 12 Steps do NOT buy; they stay loyal.
4. **NEW V24:** Mr. Big whips around behind the button: "What was THAT?!"
5. **NEW V25:** Ms. Anylist, deadpan, slides her tablet face down: "...Calendar reminders, sir."
6. **NEW V26 (teases the next episode):** Mr. Big: "Somebody SHINE me!" The Assistant raises BIG SHINE, hesitates one beat, and glances at the door Madame left through. Then he sprays.
7. End card: $37.97 and YOSKINCARE.COM, with the brand song and Madame's tagline VO.

That's 4 new short shots, about 35 credits on Kling.
