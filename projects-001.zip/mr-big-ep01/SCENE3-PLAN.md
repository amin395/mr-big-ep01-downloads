# Scene 3 video plan (V13 to V16): 12 Steps, the glow line, the refusal. Pre-checked 2026-10-15 15:58

Model: Kling 3.0 Pro, 9:16, sound off, start frame only. Prices from get_cost. **Total 43 cr = HARD CAP.** Nothing runs before Amin's clear GO.

| Step | Start frame | Length | Cost | What happens |
|---|---|---|---|---|
| F1-stern (new frame) | F1 (job 910cf1db) | image | 2.75 | F1 has a toothy smile baked in (checked 15:55), which is why V06/V09/V12 kept grinning. Change ONLY his expression: mouth closed, no smile, brows down, intense glare. Patched back onto F1 locally so the suit, medallion text, Assistant and BIG SHINE stay pixel-identical. Used for V14, V16 and every later Mr. Big shot. |
| V13 Mr. 12 Steps | F5 (job 2e7af211) | 5s | 8.75 | Seated, burgundy coat, full gear. All gadgets beep and blink at once; the white LED mask slips off its strap and clatters onto the table. Frozen, wide-eyed, quietly: "...I'm on step nine, sir. Same oil as step eight." |
| V14 Mr. Big notices Madame | F1-stern | 6s | 10.5 | Standing at the button, balcony behind, Assistant behind with BIG SHINE. Stops mid-panic, squints straight down the table toward the far end (Madame), leans in slightly: "Hold on. Madame Markup... why your face ain't shining like a glazed doughnut? ...Are you GLOWING?" (Amin 16:50 added "Are you glowing?"; said like an accusation of a crime, eyes narrowing.) Suspicious, never smiling. A drop of oil slides down his temple. |
| V15 Madame, glow vs. grease | F6 (media 3bd08c80) | 7s | 12.25 | Seated in her end chair, exit doors behind, green Telfar bag on the table. Snaps her gold compact shut, looks up toward the head of the table with amused calm: "Because, darling, I discovered the difference between a glow and an oil spill." Smooth, matter-of-fact, emphatic, no choppy pauses. Bare face, intense natural glow, never greasy. PROPOSED (16:55, pending GO): after the line she stays seated, rests one hand on the green Telfar bag sitting on the table right beside her, and pulls its top open so the opening faces down the table (she does NOT reach toward Mr. Big; he is at the far end; nothing is lifted out; labels warp), then hard cut to V17 (built real-photo reveal, $37.97 pop-up). Same 7s, same cost. |
| V16 The refusal | F1-stern | 5s | 8.75 | Silent. The Assistant steps forward from behind him and raises BIG SHINE toward his face. Mr. Big slowly turns his eyes to the bottle, then slowly pushes the Assistant's gloved hand down and away. Humiliated realization, never smiling. Balcony behind, button in front. |

Changes from the prompt pack (later rules win):
- V13: burgundy coat (approved change), not the pack's green.
- V14/V16: start from F1-stern, "never smiling" (fixes the grin root cause).
- V15: green Telfar bag (not ivory); her line delivered smoothly with no long pauses (Madame voice rule).
- V16: the bottle is the approved BIG SHINE prop held by the Assistant who is already in the frame, not a hand from off-screen.
- V17 already built (free).
- EDIT ORDER (16:55 proposal): V15 (she opens the bag) -> V17 (real-product reveal, $37.97) -> V16 (Mr. Big, having seen the products, refuses BIG SHINE) -> V18. V16 and V17 swapped so the reveal follows the bag opening directly.

## Run (Amin GO 17:03, cap 43)
- F1-stern: GPT Image a370572e (2.75), face-only feathered patch onto F1 -> uploaded media bad4886e. No smile, everything else pixel-identical. Use for every later Mr. Big shot.
- Jobs: V13 44b497f5, V15 2ab7e1fa, V14 5cca1e1f, V16 100e7898.
- Amin 17:04: Madame's glow must be radiant and very noticeable in ALL her clips. If a clip reads weak, apply glow2.py highlight bloom in the edit (free, no skin-tone lift).

## Results (QC 17:12). Spent 43 of 43. Balance 225.85.
| Shot | Job | Result | Edit media |
|---|---|---|---|
| V13 | 44b497f5 | PASS: deadpan, gadgets blink, LED mask drops on the table, burgundy coat | raw |
| V14 | 5cca1e1f | PASS with edit: 3.0-4.5s squint-grimace with teeth could read as a laugh; cut out. Uses 0-2.75s + 4.5-6.04s ("Are you GLOWING?" wide-eyed) = 4.3s | fc116932 |
| V15 | 2ab7e1fa | PASS with edit: highlights-only glow boost (glowvid.py k=1.8, face box) so her glow is clearly noticeable; trimmed at 6.4s because she starts pulling white tissue out of the bag at ~6.5s. Hands on the bag handles opening it at the end, logo intact | f049cecd |
| V16 | 100e7898 | PASS with edit: Assistant steps in with BIG SHINE, a faint puff at ~2.8s while Mr. Big flinches, then he pushes the hand away (~3.3s). Trimmed at 3.6s, before the empty background | 4d5f7f84 |

## V13 new line fit (10-16 12:2x)
- Amin kept the longer V13 line (~7s). V13 (5.04s) shows his mouth moving only ~2.0-5.0s; V14 edit (4.29s) has Mr. Big talking from the first frame, so there is no silent gap to carry the tail.
- Proposed free fix (A): V13 slowed to ~75%; first two sentences on camera; "However... its potency has been diluted, to reduce our costs." over a punch-in on his vial bandolier cropped from V13; hard cut to V14 "Hold on." Paid alt (B, ~8.75 cr): 5s Kling continuation from V13's last frame. Awaiting Amin; finalize timing after the voice is recorded.
- 12:40 10-16 Amin chose A. Built free: V13 slowed to 75% by frame repeat, no interpolation (sandbox anim/V13_slow.mp4, 6.71s); vial close-up cropped from V13 3.0s-end at 75%, slow push-in, mouth never in frame (V13_vials.mp4, 2.71s, v13vials.py); then V14 edit fc116932. Silent preview V13 -> vials -> V14: media 2348d97c (13.7s). Audio placement: on-camera sentences over V13's talking section (~2.7-6.7s slowed); "However... diluted, to reduce our costs." over the vials; "Hold on." at the top of V14. Exact timing gets locked once his voice is recorded.
