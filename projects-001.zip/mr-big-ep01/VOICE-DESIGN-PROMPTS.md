# Custom cast voices: ElevenLabs Voice Design (paste-ready)
Why: Higgsfield's 114 ready-made voices have no accent or ethnicity labels, and telling them "Black American, Atlanta accent" in the line made 2 of 5 test takes read the direction out loud (14:30 test). So each character gets a designed voice.

How (about 2 minutes per character):
1. ElevenLabs > Voices > Add a new voice > Voice Design.
2. Paste the DESCRIPTION into the prompt box and the SAMPLE into the text box. Generate.
3. Of the 3 previews, keep the one that sounds most like the character. Save it with the character's name.
4. Download that preview (mp3) and post all 5 in this thread. I'll clone each one into Higgsfield and record every line there against the voice bible.

---
## 1. Mr. Big
DESCRIPTION: A Black American man in his early 50s from Atlanta, Georgia. A raspy, gravelly, soulful voice with a thick Southern accent. Flamboyant, theatrical showman, outraged and over the top. His normal register is a raspy mid-range, and when he panics his voice cracks up into a high, raspy, almost falsetto screech. Studio quality, close mic.
SAMPLE: Ladies and gentlemen, welcome to the top of the tower. Now listen to me. Somebody out there is making beautiful skin AFFORDABLE! Affordable! Do you know what that does to my business? Somebody get me my shine, right now!

## 2. Madame Markup
DESCRIPTION: A Black American woman in her mid 40s from the American South. A smooth, warm, low alto voice, polished and expensive, with gentle Southern charm. Calm, unbothered and matter-of-fact, with a hint of a smile. Never breathy, never sultry, never loud. Speaks every sentence in one smooth flowing breath. Studio quality, close mic.
SAMPLE: Because, darling, I discovered the difference between a glow and an oil spill. Baby, it's an inside job. I mark it up. I don't pay the markup. Now if you'll excuse me, I have somewhere much more beautiful to be.

## 3. The Assistant
DESCRIPTION: A big Black American man in his late 30s. A very deep, gravelly bass voice, like a serious bodyguard. Short, clipped, urgent, military delivery, completely serious. American accent with a light Southern edge. Studio quality, close mic.
SAMPLE: Sir! Who hit us? A lawsuit? The government? Somebody find the CFO! Lock the doors. Nobody leaves this room until we know who did this. Big. Skin. Shine.

## 4. Ms. Anylist (Marketing Analyst)
DESCRIPTION: A Black American woman in her early 30s, a polished Atlanta corporate professional. A clear, articulate, confident mid-range voice. Deliberate and measured, every word and number crisp and easy to understand, never rushed. Calm authority, grounded and warm. American accent. Studio quality, close mic.
SAMPLE: Sir, the company is called YO SKINCARE. Their cleanser is nine ninety-nine. The facial elixir is fifteen ninety-nine. The body oil is thirteen ninety-nine. Their complete routine is only thirty-seven ninety-seven, with five-star Google reviews.

## 5. Mr. 12 Steps (the Professor)
DESCRIPTION: An older Black American man in his 60s, a university professor and chemist. A thinner, precise, highly educated voice. Proper, over-enunciated, slightly stuck-up and condescending, eccentric and deadpan, as if every sentence is a lecture. American accent. Studio quality, close mic.
SAMPLE: Sir, I am on step nine of twelve. Chemically speaking, it is the same oil as step eight. However, its potency has been diluted, to reduce our costs. As any educated person would understand, step ten is, of course, considerably more sophisticated.

---
# SUNO ROUTE (Amin 16:37): make each character's voice sample in Suno, Claude clones it in Higgsfield
How: Suno > Create > Custom. Paste STYLE into "Style of Music" and LYRICS into "Lyrics". Instrumental OFF. Generate, keep the take that sounds most like the character.
If any music or effects sneak in: open the song menu > Get Stems > download the VOCALS stem only. Post the mp3/wav here (30-60 seconds is ideal).
Use the SAMPLE text from each character above as the lyrics, after the [Spoken Word] tag.

- Mr. Big STYLE: spoken word, a cappella, no music, no instruments, no beat, dry close-mic studio vocal, raspy gravelly Black Southern man in his 50s, thick Atlanta accent, flamboyant theatrical showman, outraged, voice cracks high when shouting
- Madame Markup STYLE: spoken word, a cappella, no music, no instruments, no beat, dry close-mic studio vocal, smooth warm low alto Black Southern woman in her 40s, polished, calm, unbothered, matter-of-fact
- Assistant STYLE: spoken word, a cappella, no music, no instruments, no beat, dry close-mic studio vocal, very deep gravelly bass Black man in his 30s, bodyguard, short clipped urgent military delivery, dead serious
- Ms. Anylist STYLE: spoken word, a cappella, no music, no instruments, no beat, dry close-mic studio vocal, clear confident articulate Black woman in her 30s, Atlanta corporate professional, deliberate and measured
- Mr. 12 Steps STYLE: spoken word, a cappella, no music, no instruments, no beat, dry close-mic studio vocal, older Black man in his 60s, university professor, proper, over-enunciated, slightly stuck-up, deadpan, eccentric

LYRICS format example (Mr. Big):
[Spoken Word]
Ladies and gentlemen, welcome to the top of the tower. Now listen to me. Somebody out there is making beautiful skin AFFORDABLE! Affordable! Do you know what that does to my business? Somebody get me my shine, right now!

---
# SUNO FULL-SCRIPT ROUTE (Amin 19:46): load each character's real ad lines into Suno
One generation per character holds ALL of that character's lines, so the voice stays identical; Claude cuts each line out and fits it to its clip. Same Style as above. Blank line between lines = pause. [Brackets] are directions, not spoken.
Full line text: VOICE-BIBLE.md. Lyrics blocks posted in thread 19:48.

---
# SUNO ONE VOICE AT A TIME (Amin 2026-10-17 02:44). Order: Mr. Big, Madame, Ms. Anylist, Assistant, Mr. 12 Steps, Executives.
## VOICE 1: MR. BIG (sent 02:46)
STYLE: Spoken word comedy voice performance, a cappella, no music. African-American Black man, age 52, from Atlanta, Georgia. Thick Black Southern Atlanta accent, drawn-out vowels, dropped g's, loose Southern grammar. Voice: raspy, gravelly, soulful, smoky mid-range, a flamboyant old-school soul showman. Attitude: billionaire beauty mogul who thinks he is royalty; vain, eccentric, theatrical, a little unhinged. Cadence: swaggering sing-song rhythm when in control, then short explosive bursts; when shocked or angry his voice shoots up into a high raspy almost-falsetto screech on the key word, then drops back down. Over-the-top outrage, never calm, never smug, never laughing. Every word clear and understandable. Dry close-mic studio recording, no reverb, no echo.
EXCLUDE: music, instruments, beat, drums, bass, piano, singing, melody, rap flow, choir, background vocals, reverb, echo, autotune
SETTINGS: Instrumental off; Weirdness about 20%; Style Influence about 80%.
LYRICS: as posted in thread 02:46 (Mr. Big's 8 lines from VOICE-BIBLE.md with bracketed directions).

## MR. BIG, LINE BY LINE (Amin 03:20: each line gets its own delivery). Supersedes the 02:46 block.
Method: one Suno generation per line. Style = BASE + that line's DELIVERY. After the first take that nails his voice, Create Persona "Mr Big" from it and use that Persona for every later line so the voice stays identical.
BASE: Spoken word comedy voice acting, a cappella, no music. African-American Black man, 52, from Atlanta. Thick Black Southern accent, dropped g's. Raspy, gravelly, soulful mid-range voice; flamboyant showman, billionaire who thinks he is royalty. Every word clear. Dry close-mic studio, no reverb.
EXCLUDE: music, instruments, beat, singing, melody, rap flow, background vocals, reverb, echo, autotune
Lines and deliveries: as posted in thread 03:22 (V03, V06, V09, V12, V14, V18, V24, V26).

## MR. BIG IN SUNO SPEECH (BETA) BUILDER (Amin 04:04 screenshot). Supersedes the Songs-tab method for voices.
Fields seen: Simple/Advanced; Tone ("Describe the delivery: tone, pacing, mood and setting"); Advanced > Vocal Gender (Male/Female), Background music (Off/On), Variety slider (default Normal). Script box is above (not in screenshot).
Settings: Advanced mode; Vocal Gender Male; Background music OFF; Variety one or two notches LEFT of Normal (steadier voice).
One line per Create: Script = the line only; Tone = identity + that line's delivery. Tone texts as posted in thread 04:06.

## SCRIPT CHANGE (Amin 10-18 02:57): Madame gets a 4th line, V21 exit: "Ladies... you don't have to go broke to be beautiful." (punchline V20 unchanged). Include it when Madame's Suno Speech prompts are written. Tone: warm, knowing, sisterly, said over her shoulder while walking away, small beat after "Ladies", energy 3.
