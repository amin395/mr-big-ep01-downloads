# Scene 1 video plan (V04 to V07), pre-checked 2026-10-15 07:05

Model: Kling 3.0 Pro, 9:16, sound off, start frame only (no moves through the room). Quoted with get_cost: 38.5 cr total = HARD CAP.

| Shot | Start frame | Length | Cost | What happens |
|---|---|---|---|---|
| V04 panic wide | Master B v2 (media e59a0f83) | 5s | 8.75 | Red emergency light pulses. Seated executives panic in their chairs: arms flail, papers fly, mouths agape, chairs swivel. ONE unnamed executive jumps up and dives UNDER the table (Amin 07:08). Nobody stands or walks ON the table. Madame calm and still in her end chair. Mr. Big and Assistant stay put. |
| V05 Assistant | F2 (job 5f80a2c9) | 6s | 10.5 | Assistant behind Mr. Big, balcony behind, BIG SHINE in his gloved hand: "Sir! Who hit us? A lawsuit? The government? Somebody find the CFO!" |
| V06 "Affordable" | F1 (job 910cf1db) | 6s | 10.5 | Mr. Big at the button, full-body meltdown (fists, trembling, oil flying): "Worse! Somebody out there is making beautiful skin... affordable!" Voice cracks on "affordable". Assistant sprays his face twice with BIG SHINE; he doesn't blink. |
| V07 the scoff | Master A (media 52dddd8b) | 5s | 8.75 | CHANGED (Amin 07:23, option C): seated executives chuckle, roll eyes and wave it off; background mutters ("That'll never work." "Good luck with that." "Affordable? Please."). Then ONE unnamed executive (foreground, right side) leans in: "Well... what do they consider affordable?" Madame does not scoff: small knowing smile. Ms. Anylist already looking at her tablet. Mr. Big not the focus. Static camera. |

Changes from the prompt pack, per Amin's later rules (later rules win):
- V04: pack had all executives jumping up. Now they panic in their seats, except ONE unnamed executive who jumps up and dives under the table (Amin 07:08 asked to keep that gag). Main characters stay seated.
- V05: pack had a silver tray (fan, mirror, towel, generic mister) and "rushes into frame". Now he already stands behind Mr. Big and holds only the approved BIG SHINE bottle (props rule 02:19).
- V06: rage upgraded to a full-body meltdown (performance rule 15:01). The spray is BIG SHINE.

**Mr. Big's voice (Amin 07:14):** eccentric and raspy, jumping high-pitched in moments of extreme emotion (in V06: raspy on "Worse!", screeching high on "...affordable!"). The voice itself is made later in ElevenLabs (03_voices-and-music.md, MrBig_VoiceB updated). The Kling clip is silent; the prompt asks for the matching mouth and face (wide-open shriek on "affordable").

**Pen drop moved (Amin 07:23):** the gold pen drop is now a ~1s insert right AFTER Ms. Anylist's last price in V08 (new clip V08b, 5s, 8.75 cr), run with the Ms. Anylist scene, not in Scene 1. Scene 1 cap unchanged: 38.5 cr.

## Results 2026-10-15 07:30 (38.5 cr spent, balance 370.35)
- V04 PASS: job b44f59a7
- V05 PASS: job ada3e885
- V06 FAIL: job 3fe9ccc1 (grins instead of meltdown; BIG SHINE mist turns hair gray; suit turns plain gold in lunge). Redo 10.5 cr awaiting Amin GO; fix prompt: never smiling, mist on cheek only, no lunge.
- V06 RETAKE PASS: job 1ce8ac14 (furious from frame 1, no grin, fists, wide-open shriek on "affordable", BIG SHINE mist passes for one frame, suit/hair unchanged). 10.5 cr. Balance 349.35.
- V07 PASS: job 7091c47d
- V03 REBUILD (Amin GO 07:29, 10.5 cr) from F1: job 3b52de8b, PASS (slam + shout, no grin). Step-in clip before it pending GO (11.5).
