# Brand song timing: "We Don't Play About The Brand (Remastered x2)" (Amin 2026-10-16 13:10)

Source: Amin's Google Drive link, Suno track by amin685 (suno.com/song/ea80056d-7b30-482c-8854-7ea06c94a598), 2:28. Sandbox copy: ~/song/song.mp3. Lyric times from Whisper (word level).

## Lyric map (song time)
- 115.52-116.9 "We don't play about the brand" / 117.2-118.7 again / 119.0-120.5 again
- 120.8-124.0 "From that cloth we cut, real ones stay around us"
- 124.4-127.2 "We don't play about the brand" x2
- 127.24-131.0 "The game ain't what it is, but we still know it A to Z"
- 132.7-135.9 "Yo, yo, yo, yo, skin care" (repeats 136.1-139.4, 139.6-142.9), outro fades to 147.8

## OPEN (hero) = media c4df9bec (preview, 11.8s)
- Song from 115.375: vocals hit at 0.15s. Three "We don't play about the brand" + "From that cloth we cut, real ones stay around us."
- Picture: V01 sped to 4.9s (full tower kept), V02 0-3.3s (door opens), hard cut to V03 from 0.9s; palm hits the button at 8.675s.
- Record-stop starts 0.12s before the slam; song dies on the hit. Silence, then "WE ARE UNDER ATTACK!" (voice not recorded yet).
- "Ladies and gentlemen..." dropped from the hero: the song carries the open and sung lyrics never sit under dialogue.

## CLOSE (hero) = media 9e2bb3b4 (audio, 8.85s)
- Song 127.15-136.0: "The game ain't what it is, but we still know it A to Z" -> "Yo yo yo yo skin care." Short fade out before the next "Yo".
- Placement: starts as V26 (the Assistant's silent hesitation and spray) begins, AFTER "Somebody SHINE me!"; "A to Z" lands as the end card appears; "YO SKINCARE" sings over the logo + $37.97 + YOSKINCARE.COM.
- 30s/15s cuts: end card with just "Yo yo yo yo skin care" (132.7-135.9).

Rights: Amin's own Suno track. Commercial use is OK if it was made on a paid Suno plan.

## CLOSE v2 (Amin 13:37) = media 757bad53 (audio, 9.9s), SUPERSEDES 9e2bb3b4
- Song 126.10-136.0: last "We don't play about the brand" -> "The game ain't what it is, but we still know it A to Z" -> "Yo yo yo yo skin care." The hook ties the ending back to the opening.
- Placement: "We don't play about the brand" starts right after "Somebody SHINE me!" over V26 (Assistant hesitates, sprays); the rest plays over the end card, "YO SKINCARE" over logo + $37.97 + YOSKINCARE.COM.

## CLOSE v3 FINAL (Amin 13:38) = media 076a6f74 (audio, 11.94s), SUPERSEDES 757bad53 and 9e2bb3b4
- Song 124.06-136.0: "We don't play about the brand. We don't play about the brand." -> "The game ain't what it is, but we still know it A to Z." -> "Yo yo yo yo skin care." Starts in the small gap after "around us", just before the downbeat.
- Placement: starts right after "Somebody SHINE me!" over V26 (~3s, Assistant hesitates and sprays); end card from ~3s, "A to Z" ~4.7-7.0s, "YO SKINCARE" ~7.9-10.5s over the logo; end card ~9s long, so it animates in stages (products, price, URL) to keep moving.
