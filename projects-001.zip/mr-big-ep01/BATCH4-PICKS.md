# Batch 4 boardroom clips: notes and latest takes

Updated 14 Oct, 16:05. **Every shot is now being rebuilt keyframe-first (FIX-PLAN.md). The takes below are reference only.**

**Amin's note on all clips:** executive skin is nowhere near oily enough. The target is [oil-level-reference.jpg](refs/oil-level-reference.jpg): faces dripping wet, with thick glossy streaks and oil running down the neck and chest. Madame is the only exception, with an intense, radiant natural glow.

## Oil edit test: pick one
These are the same clips, re-skinned to match your oil photo, with no re-render.

| Test | Clip | Cost | Link |
|---|---|---|---|
| A: Kling edit | V04, the wide shot of the executives | ~10 credits | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_150858_23c82325-138e-45af-aae2-26ed783517db.mp4) |
| B: FLUX edit | V04, the wide shot of the executives | ~15 credits | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_150858_1c0e2aca-9f3c-4386-b274-d407e775b072.mp4) |
| A: Kling edit | V09, Mr. Big close-up (check that his lips and medallion still hold) | ~10 credits | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_150859_13d534a6-dc44-4d9d-bc56-86349c655c62.mp4) |

Compare them with the originals in the table below.

**Standing rules:**
- The table is full: 8 to 10 greasy executives.
- Nobody stands in or on the table.
- There is exactly one Mr. Big.
- Mr. Big's rage is over the top.

| Shot | What it is | Amin's note | Status | Latest take |
|---|---|---|---|---|
| V04 | Wide: executives panic | Oil too weak (all clips) | Oil-edit test running | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_140752_b5413642-037d-4b02-a51d-a3a38c6d453f.mp4) |
| V05 | Assistant: "Sir! Who hit us?" | Oil too weak | Waiting on edit test | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_140752_62a06e7a-8d69-4c6f-8666-1c0a4a13f80a.mp4) |
| V06 | Mr. Big: "...affordable!" + spray | Oil too weak | Waiting on edit test | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_140728_73b25e05-05b1-4560-a4c0-982890513410.mp4) |
| V07 | Room freezes, pen drops | v1 matte, rejected | v2 re-run ready | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_141442_6286ecb9-c72b-435d-9088-0e306fd59818.mp4) |
| V08 | Ms. Anylist with tablet | Oil too weak | Waiting on edit test | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_140752_696d1841-c8a9-41cd-91e2-b849b0b4faf1.mp4) |
| V09 | Mr. Big: "Thirteen ninety-nine?!" | Oil too weak | Oil-edit test running | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_140728_d6093565-70ea-408e-b9d9-ae2086ccda19.mp4) |
| V10 | Assistant close-up | Oil too weak | Waiting on edit test | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_140752_f78fd5ea-b324-4617-ab44-d4a1cf16baf2.mp4) |
| V11 | Ms. Anylist, medium | Oil too weak | Waiting on edit test | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_140752_c68b2eba-1a94-4555-be0b-a629be6e911f.mp4) |
| V12 | Mr. Big clutches chain: "$37.97?" | Oil too weak | Waiting on edit test | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_140917_60a0f092-a932-4ee3-959e-f1bf967caea7.mp4) |
| V13 | Mr. 12 Steps: "step nine" | Terrible: he's in the table, only 2 board members | Re-run ready (full table) | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_145820_b19586d7-2003-4d21-b37f-be1f8676fa2a.mp4) |
| V14 | Mr. Big: "why your face ain't shining?" | Terrible: Mr. Big in the table, no board members, Madame's face not visible | Re-run ready (full table, Madame visible) | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_145820_391228f1-6b6a-4071-8262-04e96a3c6086.mp4) |
| V15 | Madame: "glow... oil spill" | Line is "oil spill", not "grease spill". Glow must be far more intense and radiant | v3 ready (intense glow). v2 is a fallback only | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_150315_40aa3395-f87a-4527-a584-9250eda8f4b0.mp4) · v2 [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_145959_4ffe6a07-83a3-4a4a-9b96-342d13099bc4.mp4) |
| V16 | Mr. Big greasy close-up, BIG SHINE | Oil too weak | Waiting on edit test | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_140752_3a2f97c8-35cc-40a3-8f62-9bbde9ea4ced.mp4) |
| V18 | Mr. Big rage: "the ENEMY" | Not over the top: just yelling and pointing | Re-run ready (full meltdown) | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_150141_e84b0eec-cf61-46a9-887c-8d8a59e1c7f1.mp4) |
| V19 | Madame: "it's an inside job" | Glow must match V15 v3 | Match after V15 v3 approved | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_140727_1e05f86b-e360-4dfb-a150-9fa783e759d0.mp4) |
| V20 | Madame: "I mark it up..." | Terrible: Madame walking on the table | Re-run ready (on floor, glowing) | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_150424_44b6204b-f991-4339-8fc9-a32b80feda0e.mp4) |
| V21 | Madame walks out | Terrible x2: walks on the table; then walks left and right instead of exiting | Replaced in the storyboard by start and end frames (seat, then exit doors) | n/a |
| V22 | Ms. Anylist taps tablet | Terrible: several Mr. Bigs, no board members | Re-run ready (one Mr. Big, full table) | [watch](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_150557_405dda70-4467-4946-87e9-0e83a4a0044f.mp4) |

## Opening picks (Amin, 2026-10-14)
- V01: take 2 (job 6d8d6a31) chosen 16:40; raw copy approved/video/V01_take2_raw.mp4. Needs a very small Mr. Big silhouette on the TOP balcony (just under the crown). Edits: FLUX 4a74be9a, Kling edit 4a24e2f9.
- V02: Amin picked the attached take ("take 2" in his words: turns sharply and strides to the gold doors) at 16:45; copy approved/video/V02_pick_raw.mp4 (5.04s). 16:46 Amin: it must END inside the packed boardroom with everyone in their correct seats. Re-render on Kling 3.0 Pro 8s, start 36aea5a5 balcony still, end frame R3 master 3dcd3d97: jobs 619b36fe, 0f372977.
- V02 re-renders posted 16:55: take A 0f372977, take B e18677a4 (8s, start 36aea5a5, end R3). 619b36fe failed (no reason given).
- V01 silhouette edits posted 16:55: FLUX 4a74be9a, Kling edit 4a24e2f9. Awaiting Amin's picks.
- V04 (Amin 16:52, on the old Batch 4 clip): orientation wrong. As Mr. Big enters through the BALCONY door, every seated executive stays in their exact seat and turns toward that door; all faces oily; NO duplicate or lookalike people. Rebuild: keyframe edits of R3 (nano_banana_pro + oil ref): 239872fc, 803519d9.
- 17:10 Amin: V01 pick = the silhouette edit with tiny Mr. Big (he's on the lower balcony, Amin OK with that); asked him A (4a74be9a) or B (4a24e2f9). V02 take B rejected: Mr. Big morphs into someone else, unapproved board members, extra standing people. Root cause: end frame R3 had non-element executives + one clip balcony-to-button. Plan: keep Amin's original V02 take (ends at the doors), hard-cut to V04 locked frame (1094b000 / skin fix ebc29fc9) built with all character elements. Reverse master from that frame: 69618bb3, 7748831b.
- 17:13 posted V04 entrance frame for approval: 1 = 1094b000 (structure checks pass; oil reads as white cream to TinyFish), 2 = ebc29fc9 (skin-only fix; Assistant may be missing). Reverse master candidates from frame 1: 7748831b (done), 69618bb3 (rendering). Not shown yet.
- 18:00 VISUAL QC now possible: Higgsfield sandbox_exec (curl the result URL, ffmpeg downscale, image_paths) returns images I can actually see. Findings:
  - V01: Edit B (Kling, 4a24e2f9) = ONE silhouette on the lower balcony = Amin's pick. Edit A (FLUX) has TWO figures: reject.
  - R3 (3dcd3d97), Frame 1 (1094b000), d6a54021, ebc29fc9 and all 22 storyboard frames (bb91cc9b..084937c8) are WRONG CAST (generic East Asian extras, wrong Madame, Assistant at the button instead of Mr. Big). Rejected. Do not use R3 as a reference.
  - A3 (c07df507) is CORRECT: Mr. Big standing at the button, Assistant behind him, balcony behind, Ms. Anylist (emerald suit) and Mr. 12 Steps (mask) seated, Madame at the near end, oily execs. A3 is the foundation for everything.

## Final storyboard set (2026-10-14 18:25, all pass CONTINUITY-CHECKLIST by eye)
V04 55727b24 · V05 d16182b2 · V06 a0dcde58 · V07 f74f439a · V08 5b4064d3 · V09 f6257e77 · V10 561b42ca · V11 30978adc · V12 dfa518af · V13 f51a1d33 · V14 71a1193f · V15 e30c7fc4 · V16 407fd457 · V18 3e83671d · V19 9bd01327 · V20 445ab6ed · V21a 8cafc2d6 · V21b 738f9a1f · V22 c51f27cb · V23 a9b6765c · V24 f4c75ac5 · V25 5eb5fc05 · V26 6434bca4. V17 (product composite) still to build.
Storyboard sheet: media ae12bb72 (https://d2ol7oe51mr4n9.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/ae12bb72-7761-4cf5-ba70-9b49c39c7884.jpg). Balance 880.15. Animation estimate ~450 to 500 cr (Kling 3.0 Pro ~250 to 300, FLUX oil pass ~100 to 120, retries ~80 to 100). Waiting for Amin's GO.

## Animation batch (2026-10-14 19:52, Kling 3.0 Pro, sound off, start frame = storyboard frame; V21 start+end)
V04 b43d0e69 · V05 80dfb6ee · V06 ecf3a945 · V07 ff068dfc · V08 495836ff · V09 3bcf6494 · V10 92e5d397 · V11 314b2cae · V12 607773db · V13 5aa8920f · V14 c26e93ef · V15 e8963f9a · V16 4e43ce46 · V18 f1e92d35 · V19 1760412d · V20 1793fbdd · V21 917ed4cb · V22 d4749d0d · V23 088b0c25 · V24 5a74e99c · V25 17c334c4 · V26 58b32bd3
Products/web plan: V17 handbag shot from real product photos (composite, not AI labels); V08/V11 product + price pop-ups, end card ($37.97, YOSKINCARE.COM, logo), captions = post-edit.

## Animation QC (2026-10-14 20:05)
- PASS: V04 V05 V06 V08 V09 V10 V11 V12 V13 V14 V15 V16 V18 V19 V21 V22 V23 V25 V26 (originals).
- FAIL then fixed: V07 camera drift (re-roll 75d6fae5 PASS); V24 face drift on push-in (re-roll a7b0206b PASS); V20 start frame had an empty table + tan bag (new frame 52757a2a PASS, animating 6cc58c8f).
- FLUX oil pass REJECTED on V08/V11/V13/V25 (537e214c, edad4fda, 1122f4a4, 9179ef62): white goo streaks read as cream, and 12 Steps lost his beard, mask and bow tie. Testing Kling edit with oil ref instead: V08 ad9cc79b, V13 9f4683fc.
- SEAT SIDE: shots from Mr. Big's end without him in frame (V19, V20) show Ms. Anylist camera-left; the reverse master has her camera-right. Mirror V19 and V20 (hflip) in the edit so seats match.
- 20:20 Final picks: V08 cceb8ba4, V11 ed919c5d, V13 e7fb9a82, V25 39ad0146 (from oilier frames 77334ef8/3da482c0/833805d0/8b0ae74a); V20 6cc58c8f (frame 52757a2a). V25 f1132152 FAIL (extra standing people). Kling edit oil test ad9cc79b/9f4683fc: no visible change, not used. Dailies reel media b324b67b. Full list: CLIPS-EP01.md. Balance 513.2 (spent ~367 since GO).
