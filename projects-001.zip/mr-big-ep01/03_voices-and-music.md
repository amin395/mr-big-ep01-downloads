# Mr. Big Beauty Ep01: Voices & Music

## Can Suno make the character voices?

**Not reliably. Use Suno for music, and something else for dialogue.**

- Suno's new **Speech** feature (public beta since 1 Oct 2026) makes **one spoken voice over music as a single track**. Suno itself points it at short personal pieces (a poem, a note), not scripts, and notes that accents can drift and pauses can run long. There's no multi-character dialogue, no voice that stays locked across separate lines, and no music-free speech mentioned. ([Dubspot on Suno Speech](https://blog.dubspot.com/suno-speech-2026), [guide](https://jackrighteous.com/es/blogs/guides-using-suno-ai-music-creation/suno-speech-beta-spoken-audio-background-music))
- Suno's **Voices/Personas** feature is for singing voices inside songs, not spoken lines.

### Voice tool options

| Option | How | Pros | Cons |
|---|---|---|---|
| **A. ElevenLabs (recommended)** | Voice Design: describe the voice in text → save it → generate every line with the v3 model and its emotion tags | Same voice every line, clean dry audio, emotion tags like [shouting], [sarcastic], gasps | Separate subscription (Starter tier is enough) |
| B. Higgsfield's own voices | Voice presets in Lipsync, or Custom Voice from an uploaded MP3/WAV sample | Everything in one place | Less control over performance; presets are generic |
| C. Real voice actors (Fiverr, Backstage, local Atlanta talent) | Record the ~20 lines | Best comedy timing, most authentic | Costs money and time |

**Pick A, combined with B:** design each voice in ElevenLabs, generate all lines, then upload a 30 to 60 second clean sample of each voice into Higgsfield as a **Custom Voice**. That way any lip-sync fix inside Higgsfield uses the same voice as the edit. If Mr. Big's "Voice B" already exists as a file, upload that as his sample and skip designing him.

Tell me if you'd rather go with C. For a comedy ad, real Atlanta comedians reading these lines would be the strongest version, and the lip-sync workflow is the same.

---

## ElevenLabs voice prompts

**How:** ElevenLabs → Voices → Voice Design → paste the **Voice description** → paste the **Preview text** → generate → keep the best of the 3 → save with the name shown. Then in Text to Speech, choose model **Eleven v3**, select the saved voice and paste each **Line** exactly. The words in [brackets] are performance tags; v3 reads them as direction, not words. Generate 3 takes per line and pick the funniest.

Don't name or imitate any real celebrity in voice descriptions. It's against ElevenLabs' rules and a legal risk in an ad.

### 1. MR. BIG (save as "MrBig_VoiceB")
**Voice direction (Amin 2026-10-15 07:14):** eccentric, RASPY throughout, HIGH-PITCHED in moments of extreme emotion. Amin's reference is a well-known soul singer's speaking style; per the rule below we describe the qualities and never name or clone a real person.
**Voice description:**
```
A middle-aged African American man from Atlanta with a raspy, gravelly, soulful voice that is eccentric and flamboyant. Normally a raspy mid-range with a playful, sing-song swagger, like a billionaire showman who thinks he is royalty. Under extreme emotion (shock, rage, panic) his voice shoots up into a high-pitched, raspy, almost falsetto screech, then drops back to raspy. Comedic, larger than life, crisp studio recording.
```
**Preview text:**
```
Ladies and gentlemen... we are under attack! Do you know who I am? I own this city, baby. I own the skyline.
```
**Lines (Eleven v3):**
| Shot | Line |
|---|---|
| V01–V03 | `[dramatic, slow] Ladies and gentlemen... [shouting] WE ARE UNDER ATTACK!` |
| V06 | `[shouting] WORSE! Somebody out there is making beautiful skin... [horrified, voice cracking] AFFORDABLE!` |
| V09 | `[outraged] Thirteen ninety-nine?! [shouting] That's what we charge for the SHIPPING!` |
| V12 | `[gasping, panicked] Thirty-seven ninety-seven? For the WHOLE routine?! [wailing] How are we supposed to sell people twelve steps they don't need?!` |
| V14 | `[suspicious, slow] Hold on. Madame Markup... why your face ain't shining like a glazed doughnut?` |
| V18 | `[furious, shouting] You brought the ENEMY into MY boardroom?!` |

### 2. MADAME MARKUP (save as "MadameMarkup")
**Voice description:**
```
A sophisticated African American woman in her fifties with a smooth, warm, low alto voice. Elegant, unbothered and razor sharp, with Southern charm and perfect comedic timing. She never shouts; her power comes from calm superiority, slow deliberate pauses and a hint of a smile in her voice. Polished, expensive, crisp studio recording.
```
**Preview text:**
```
Darling, I don't rush. I don't raise my voice. And I most certainly do not pay full price.
```
**Lines:**
| Shot | Line |
|---|---|
| V15 | `[amused, matter-of-fact, smooth] Because, darling, I discovered the difference between a glow and an oil spill.` |
| V19 | `[cool, matter-of-fact, smooth] Baby, it's an inside job.` |
| V20 | `[matter-of-fact, one smooth breath, heavy emphasis on "don't pay"] I mark it up. I DON'T PAY the markup.` (Amin 18:05) |

V20 is the most important audio in the film. Generate 6 to 10 takes. **Amin's direction (14 Oct):** say it as one smooth, matter-of-fact, emphatic statement. No choppy pauses or stop-start beats between the halves. Nothing breathy or yelled.

### 3. THE ASSISTANT (save as "Assistant")
**Voice description:**
```
A large, muscular African American man in his fifties with a deep, gravelly bass voice. Dead serious and intensely loyal, like a bodyguard reporting a national emergency. Short, clipped, urgent phrases with military seriousness that makes trivial things sound life-or-death. Crisp studio recording.
```
**Preview text:**
```
Sir. Perimeter is secure. Your towel is warm. Your mirror is polished. Nobody gets near the boss.
```
**Lines:**
| Shot | Line |
|---|---|
| V05 | `[urgent, serious] Sir! Who hit us? A lawsuit? The government? [shouting] Somebody find the CFO!` |
| V10 | `[loud dramatic gasp]` (generate the gasp alone) |
| V06 (on the spray, right after Mr. Big's "...affordable!") | `[suddenly smooth and cool, a laid-back 1970s soul-radio announcer, slow, velvety, a little breathy, savoring every word] Biiig... Skin... Shine.` Same Assistant voice; the joke is the bodyguard suddenly turning silky for one line. Off-camera (only his gloved hand is in shot), so Mr. Big stays the only on-screen speaker. Amin 15:46. |

### 4. MS. ANYLIST (save as "MsAnylist")
**Voice direction (Amin 2026-10-16 12:02):** clear, deliberate, confident. NOT rambling off information. Every word and price understandable at a comfortable pace. Data-driven, but she understands reality.
**Voice description:**
```
A professional African American woman in her forties with a clear, confident, articulate mid-range voice. A sharp, data-driven corporate analyst who is also grounded in real life. She speaks deliberately, at a measured pace, every word and every number crisp and easy to understand. Never rushed, never rambling, never nervous. Calm authority with a subtle undertone of being secretly impressed. Crisp studio recording.
```
**Preview text:**
```
Sir, according to the quarterly numbers, we may have a small problem. Okay. A big problem.
```
**Lines:**
| Shot | Line |
|---|---|
| V08 | `[clear, deliberate, confident] Sir, the company's called YO SKINCARE. Their Triple-Action cleanser, exfoliator and toner is nine ninety-nine. SUPA GLO Facial Elixir, fifteen ninety-nine. SUPA GLO Body Oil, thirteen ninety-nine.` |
| V11 | `[calm, measured, confident] It gets worse. Their Complete Routine is only thirty-seven ninety-seven. Sea moss, black seed oil, and jojoba. [impressed] A ten-oil face elixir. A seven-oil body oil. And five-star Google reviews.` |

### 5. MR. 12 STEPS (save as "Mr12Steps")
**Voice direction (Amin 2026-10-16 12:02):** sounds like a Black professor. Proper, a little stuck-up, eccentric, absurd, complicated.
**Voice description:**
```
An older African American man in his sixties who sounds like a proper, highly educated professor. Precise, over-enunciated diction, a little stuck-up and condescending, as if every sentence is a lecture. Eccentric and absurd: overly technical, fussy about tiny details, complicated in the way he explains simple things. Dry, deadpan delivery. Crisp studio recording.
```
**Preview text:**
```
Step four is the toner. Step five is the other toner. Step six... I forgot step six.
```
**Lines:**
| Shot | Line |
|---|---|
| V13 | `[proper, precise, deadpan, faintly condescending] Sir, I'm on step nine of twelve. Chemically speaking, it's the same oil as step eight. [pause] However... its potency has been diluted, to reduce our costs.` (Amin 10-16 12:16. ~7s, V13 is 5s: the last sentence runs off-camera over the start of V14 while Mr. Big glares, then "Hold on.") |

### Optional crowd/background
Use the ElevenLabs **Sound Effects** generator with: `office workers gasping in shock in a large room`, `stunned murmuring crowd of executives`, `single person drops a metal pen on a marble table`.

---

## Brand song: "We Don't Play About the Brand" (your track)

**Decision:** the song bookends every cut.
- **Open:** the song's hook plays over the tower and balcony (about 5s in the hero, 2s in the 30s, none in 15s A). It **hard-stops with a record scratch the instant Mr. Big slams the button.** The music dying is the hook and the first laugh.
- **Close:** the song returns under the end card in all cuts, so the brand sound is the last thing people hear.
- **Pick the exact bar:** from your 1:56–2:08 section, use the 2 to 5 seconds where "we don't play about the brand" is sung. Leave a breath after it so Mr. Big's "Ladies and gentlemen..." can land in the gap.
- **Rule:** sung lyrics never sit under dialogue.
- **Rights:** if the song is yours or was made for the brand on a paid Suno plan, you're clear for paid ads. If anyone else wrote or released it, get written permission first.

S1 below is now only a backup if the song doesn't fit.

## Suno prompts (music and stings)

**How:** Suno → Create → Custom mode → **Instrumental ON** (except S5) → paste the Style → title as shown. Generate 2 to 4 versions of each and keep the best. Export WAV, and stems if your plan has them, so you can duck the music under dialogue.

**S1: "Big Empire" opening theme (aerial and button, about 0:00–0:10)**
Style:
```
cinematic orchestral comedy, grand brass fanfare, pompous royal march, low timpani and taiko hits, swelling strings, trap hi-hats subtly underneath, absurdly epic billionaire villain theme, 90 bpm, big dramatic final hit, instrumental
```

**S2: "Emergency Meeting" tension bed (boardroom, under dialogue)**
Style:
```
comedic tension underscore, pizzicato strings, low staccato brass, ticking percussion, sneaky sitcom suspense, light 808 bass, sparse and quiet so dialogue sits on top, loopable, 100 bpm, instrumental
```

**S3: Comedy stings pack (price reveals, gasp, handbag reveal)**
Style:
```
short dramatic orchestral comedy stings, brass stab with cymbal crash, dun dun dunnn, cartoonish sitcom hit, timpani roll, each hit 1 to 3 seconds with silence between, instrumental
```
(Cut single hits out of the track in your editor.)

**S4: "The Exit" victory flourish (Madame walks out)**
Style:
```
sassy confident strut, funky bass, finger snaps, smooth horns, short victorious R&B flourish, classy and feminine, 8 seconds, instrumental
```

**S5: End card jingle (optional, sung)**
Instrumental OFF · Lyrics:
```
[Short soulful jingle]
Don't go broke to be beautiful
YO SKINCARE
```
Style:
```
short neo-soul jingle, warm female vocal with harmony, gospel chords, clean and premium, 6 seconds, ends on a bright resolved chord
```

**Suno licensing note:** music you make on a paid Suno plan can be used commercially. Make sure these tracks are generated while your subscription is paid, not on the free tier.

---

## Mix notes (for the editor)
- Dialogue always on top. Music ducks about 10 dB under every line.
- Music **fully out** 0.5s before "I mark it up" and back in on her first heel click.
- Siren: two short whoops only, never under dialogue.
- Room tone under the whole boardroom so ElevenLabs lines don't sound "dry."
