# Ep01 continuity checklist

Every one of Amin's notes, in one place. Every storyboard frame and every clip passes this list **before** Amin sees it. Anything that fails gets fixed first and is not posted.

**QC rule (2026-10-15):** check every character against their OWN locked Element / character reference image, never against a derived storyboard frame. **APPROVED MASTERS (Amin 05:16): Master A = media 52dddd8b (toward Mr. Big), Master B = media 2dadadc5 (toward Madame/exit).** Every boardroom frame is built from these. Old masters A3 c07df507, 55727b24, f0ad6d48, 44887c9d are INVALID. Plan: STORYBOARD-PLAN.md. Last updated 2026-10-15 05:20.

**Prompt rule (Amin 02:19):** actions, props and lines come from the approved prompt pack (02_higgsfield-prompt-pack.md) and the script. Don't improvise props or blocking.

## 1. Settings
- [ ] There are only three settings: the tower exterior, the balcony and the boardroom. Nothing new.
- [ ] **Tower:** the black-and-gold MR. BIG'S BEAUTY tower with the gold crown. In V01, tiny Mr. Big stands on the lower balcony (Amin is fine with that).

## 2. Room orientation (Amin 16:06, 16:17, 16:52, 16:54, 16:57)
- [ ] There is ONE balcony door. It is always behind Mr. Big.
- [ ] The red button on its gold pedestal is always in front of Mr. Big.
- [ ] Mr. Big STANDS behind the button. He never sits and is never in or on the table.
- [ ] Madame's end is the opposite end. Behind her are SOLID walnut-and-gold exit doors, never glass or a balcony.
- [ ] Only Mr. Big and his Assistant are ever framed against the balcony. Anyone who talks to Mr. Big is shot from his end, so the room and the exit doors are behind them.
- [ ] **ENTRANCE (Amin 07:31, repeated, angry):** the balcony doors open DIRECTLY onto the head of the table. Mr. Big steps through the doors and the table and red button are RIGHT THERE: one step in, then he hits the button (V03). He never walks past or down the table.
- [ ] Mr. Big enters from the balcony (V02). From his entrance on, everyone is already seated and turns toward the balcony door.

## 3. Fixed positions (same in every shot, opening to end)
- [ ] **Mr. Big:** standing behind the button, balcony behind him. There is exactly ONE Mr. Big.
- [ ] **Assistant:** stands directly behind Mr. Big, holding BIG SHINE, in every shot of Mr. Big. BIG SHINE is ALWAYS the approved IMG-07 prop (30c81577): gold flask, oval window, crown cap with spray nozzle, "BIG SHINE" embossed. Never a generic gold bottle, never a different container (Amin 02:19).
- [ ] **Ms. Anylist:** seated on the left side, second seat from Mr. Big, with her tablet.
- [ ] **Mr. 12 Steps:** seated in the right side's middle seat, as ECCENTRIC as his ref (98967b5b): frock coat, ornate gold vest, vial bandolier, devices, tortoiseshell glasses, bow tie, white LED mask. Never a plain suit (Amin 02:16).
- [ ] **MADAME'S HANDBAG (Amin 02:39):** Madame carries the DARK GREEN TELFAR shopping bag with the embossed T logo, Higgsfield element prop_madame-hand-bag (166893ac, media aa315ca5), in EVERY shot that shows her bag. The logo must be visible. It replaces the ivory bag from her ref sheet and the IMG-08 ivory plate. V17 pulls the YO products from this bag.
- [ ] **Mr. 12 Steps and Ms. Anylist are never dressed alike or in the same colors** (Amin 02:16). DECIDED (Amin 02:44): Mr. 12 Steps' frock coat is DEEP BURGUNDY velvet; everything else from his ref stays (gold vest, green bow tie, vials, devices, LED mask). Ms. Anylist stays emerald green.
- [ ] **Madame Markup:** seated in the END CHAIR at the total opposite end, directly facing Mr. Big, exit doors right behind her, face visible (Amin 02:07). Her walkout: she stands, turns, walks straight out. No chair glitches. She is present in every table shot until V21. After she exits, her chair is empty.
- [ ] Every other chair is filled. Table shots show 8 to 12 executives, and nobody is ever standing or walking in or on the table.
- [ ] Every person is a different individual. No twins, replicas or repeated faces in a frame.
- [ ] The same faces appear from scene to scene. Main characters always come from their approved Elements.

## 4. Skin (Amin 14:13, 15:02, 16:05; oil target refs/oil-level-reference.jpg)
- [ ] **OIL LEVEL (Amin 02:19, replaces the old "dripping wet" target):** everyone except Madame looks WET, "almost like wet, not quite dripping." At most a SMALL drip. Never dripping all over, never streaks running down the neck. Same level on everyone, real skin tone showing, never white cream, a mask or face paint.
- [ ] **Madame** is bare-faced, with little or no makeup and no glam or contour. Her glow is INTENSE and radiant, lit from within, and must never be mistaken for grease.
- [ ] No FLUX oil pass (it gave white goo and changed faces). Oil is set in the start frame.

## 5. Performance and staging
- [ ] Comedy is over the top. Every Mr. Big rage is a full-body meltdown: fists, trembling, oil flying. Never just yelling and pointing.
- [ ] Blocking reads clearly. Any move through the room gets a start AND an end frame (Madame's exit in V21 walks out through the exit doors).
- [ ] Each shot has one speaker.
- [ ] Madame's lines are smooth, matter-of-fact and emphatic, with no choppy pauses.

## 6. Locked lines (the script file is the source of truth)
- **V07 (unnamed executive, Amin 07:23):** background scoffing mutters ("That'll never work." "Good luck with that." "Affordable? Please."), then the one clear line: "Well... what do they consider affordable?" Madame gives a small knowing smile, no scoff.
- **V08b (new):** gold pen drop insert right after Ms. Anylist's last price.
- **V08 (Ms. Anylist):** "Sir, the company's called YO SKINCARE. Their Triple-Action cleanser, exfoliator and toner is nine ninety-nine. SUPA GLO Facial Elixir, fifteen ninety-nine. SUPA GLO Body Oil, thirteen ninety-nine." ("toner" is pending Amin's label check.)
- **V09 (Mr. Big, Amin 08:01):** "Exfoliate, Tone & Cleanse for NINE-NINETY-NINE!" (replaces the shipping joke).
- **V11 (Ms. Anylist):** "It gets worse. Their Complete Routine is only thirty-seven ninety-seven. Sea moss, black seed oil, and jojoba. A ten-oil face elixir. A seven-oil body oil. And five-star Google reviews."
- **V13 (Mr. 12 Steps):** "...I'm on step nine, sir. Same oil as step eight."
- **V14 (Mr. Big):** "Hold on. Madame Markup... why your face ain't shining like a glazed doughnut? ...Are you GLOWING?" (Amin 16:50)
- **V15 (Madame):** "Because, darling, I discovered the difference between a glow and an oil spill."
- **V19 (Madame):** "Baby, it's an inside job."
- **V20 (Madame):** "I mark it up. I DON'T PAY the markup." (emphasis on "don't pay", Amin 18:05)
- **Ending:**
  - V21: exit, door clicks.
  - V22: Ms. Anylist's secret Add-to-Cart chime.
  - V23: more chimes from generic executives, who act innocent. The Assistant and Mr. 12 Steps stay loyal.
  - V24: "What was THAT?!"
  - V25: "...Calendar reminders, sir."
  - V26: "Somebody SHINE me!" The Assistant hesitates, then sprays.
  - End card: $37.97 and YOSKINCARE.COM.
- Never say "seventeen (other) oils".

## 7. Approved and kept
- **V01:** take 2 plus the small Mr. Big silhouette edit.
- **V02:** Amin's take, which ends at the doors, then a hard cut into V04.
- **V03:** the button slam.
- **Locked images:** IMG-01, IMG-04 to IMG-09. Never regenerate them.

## QC log
| Shot | Frame / job | Pass? | Notes |
|---|---|---|---|
| ref | A3 c07df507 | PASS | Foundation master: correct cast, Mr. Big standing at the button, Assistant behind, balcony behind |
| ref | Reverse 55727b24 | PASS | From behind Mr. Big + Assistant; Madame at far end with walnut doors; 12 Steps left, Ms. Anylist right |
| V07 | f74f439a | PASS | Wide shock, cast correct |
| V09 | f6257e77 | PASS | Mr. Big CU, Assistant behind, balcony |
| V10 | 561b42ca | PASS | Assistant gasping behind Mr. Big |
| V12 | dfa518af | PASS | Clutching chain, Assistant behind, balcony |
| V15 | e30c7fc4 | PASS | Madame CU, doors behind |
| V19 | 9bd01327 | PASS | Madame rising, handbag, doors behind |
| V20 | 445ab6ed | PASS | Madame MCU, handbag, doors |
| V21a | 8cafc2d6 | PASS | Madame walks to doors |
| V21b | 738f9a1f | PASS | Madame through door, chair empty |
| V23 | a9b6765c | PASS | Empty far chair, cast in seats |
| V05,V06,V14 | fc4795ec,3c13392c,e7f7e30d | FAIL | Wrong Mr. Big (white man), wrong room |
| V08,V11 | 8677907f,38968559 | FAIL | Standing / not a close-up |
| V13 | f57bc8e3 | FAIL | Wrong 12 Steps, wrong room |
| V16 | a57e070a | FAIL | Table/room behind him instead of balcony |
| V18 | 551b2a5c | FAIL | Duplicate Assistant, extras near glass |
| V22 | 1d975e1c | FAIL | A gold-suit man is seated in Madame's empty chair |
| V26 | f8d1984d | FAIL | Recreated A3 with Madame present after her exit |
| V04 | 55727b24 | PASS | Reverse master used as the entrance frame after V02 |
| V05 | d16182b2 | PASS | Re-roll from V09 frame: correct Mr. Big, Assistant behind |
| V06 | a0dcde58 | PASS | Re-roll: correct Mr. Big |
| V08 | 5b4064d3 | PASS | Ms. Anylist seated in her seat, doors behind |
| V11 | 30978adc | PASS | Ms. Anylist seated, correct seat |
| V13 | f51a1d33 | PASS | Correct 12 Steps, green coat and gadgets |
| V14 | 71a1193f | PASS | Correct Mr. Big, oily CU |
| V16 | 407fd457 | PASS | Only Mr. Big + Assistant against the balcony |
| V18 | 3e83671d | PASS | One Assistant, marble table |
| V22 | c51f27cb | PASS | Madame's chair empty, Ms. Anylist taps tablet |
| V24 | f4c75ac5 | PASS | Correct Mr. Big (hair restored) |
| V25 | 5eb5fc05 | PASS | Ms. Anylist seated, deadpan, no extras |
| V26 | 6434bca4 | PASS | Mr. Big + Assistant hesitating, balcony |
| Sheet | ae12bb72 | PASS | Storyboard V04 to V26 posted to Amin 18:25 |

- [ ] **BIG SKIN SHINE (Amin 15:46, option A):** the bottle label stays "BIG SHINE" in every clip (never re-render for it). NO separate on-screen title (Amin 15:52: the voice is the joke). Instead, the burned-in caption for that one line is styled in a groovy 70s gold font. No title on the end tease either. On the V06 spray the Assistant says "Big Skin Shine" like a cool 1970s announcer (line in 03_voices-and-music.md).
