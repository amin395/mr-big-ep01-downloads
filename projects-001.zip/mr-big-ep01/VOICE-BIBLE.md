# Mr. Big Beauty Ep01: Voice Bible (for Amin's approval before any credits)

Written 2026-10-16 12:55. Nothing gets recorded until Amin approves this page. Every audition and every final take is judged against it.

**Everyone:** Black adults, Atlanta boardroom, comedy played completely straight. The jokes land because each character believes every word. Studio-clean, no echo. Nobody laughs or giggles on a line.

---

## 1. MR. BIG (the boss, head of the table)
**Who he is:** a billionaire showman who thinks he's royalty. Flamboyant, eccentric, a little unhinged.
**Voice:** raspy, gravelly and soulful all the way through. Normal register is a raspy mid-range.
**Pitch:** under shock, rage or panic his voice shoots HIGH into a raspy, almost-falsetto screech on the key word, then drops back down. That jump is his signature.
**Cadence:** a showman's swagger and a sing-song rhythm when he's in control. Short, explosive bursts when he melts down. Big words get stretched ("AFF-ORD-able!").
**Tone:** outraged, theatrical, never cool and never smiling. Full meltdown energy.
**Accent:** Atlanta, Southern, loose grammar on purpose ("why your face ain't shining").
**Don't:** sound like a movie-trailer narrator, sound calm or smug, laugh, or copy any real singer's voice.

| Shot | Line | How he says it |
|---|---|---|
| V01-V03 | "Ladies and gentlemen..." | low, slow, grand, like opening a show |
| V03 | "WE ARE UNDER ATTACK!" | full shout, voice cracks up high on "ATTACK" |
| V06 | "Worse! Somebody out there is making beautiful skin... AFFORDABLE!" | "Worse!" barked. Builds, small pause, then "AFFORDABLE" screeched high like it's a curse word |
| V09 | "Exfoliate, Tone & Cleanse for NINE-NINETY-NINE!" | first half fast and furious, the price climbs higher on each syllable |
| V12 | "Thirty-seven ninety-seven? For the WHOLE routine?! How are we supposed to sell people twelve steps they don't need?!" | gasping, wailing, high and desperate on "WHOLE" and "twelve steps" |
| V14 | "Hold on. Madame Markup... why your face ain't shining like a glazed doughnut? ...Are you GLOWING?" | sudden drop to suspicious and low, slow and squinting; "GLOWING?" spikes high and accusing |
| V18 | "You brought the ENEMY into MY boardroom?!" | shaking rage, hits "ENEMY" and "MY" hard |
| V24 | "What was THAT?!" | paranoid, whipping around, voice cracks high on "THAT" |
| V26 | "Somebody SHINE me!" | snapping, demanding, a spoiled-king order |

## 2. MADAME MARKUP (end chair, the brand proof)
**Who she is:** the elegant insider who has already switched. Unbothered, razor sharp, expensive.
**Voice:** smooth, warm, low alto. Polished, with Southern charm.
**Pitch:** low and steady, never rises, never shouts.
**Cadence:** smooth and unhurried, every sentence in ONE flowing breath. No choppy pauses, no stop-start (Amin's rule).
**Tone:** matter-of-fact and emphatic. Calm superiority, with a hint of a smile in the voice but no laugh.
**Don't:** sound breathy, sultry, sing-song, yelled or nervous.

| Shot | Line | How she says it |
|---|---|---|
| V15 | "Because, darling, I discovered the difference between a glow and an oil spill." | smooth and amused, light lean on "glow" and "oil spill" |
| V19 | "Baby... it's an inside job." | cool and slow, the one small natural beat after "Baby" |
| V20 | "I mark it up. I DON'T PAY the markup." | the most important line. One smooth, matter-of-fact statement, heavy weight on "DON'T PAY," no gap between the halves |
| V21 (exit, Amin 10-18) | "Ladies... you don't have to go broke to be beautiful." | over her shoulder to the women at the table as she walks to the door (her back is to camera from about 1.2s, so no lip sync). Warm, knowing, sisterly; a small beat after "Ladies"; light lean on "broke" and "beautiful". Energy 3. The brand tagline, it triggers Ms. Anylist's chime |

## 3. THE ASSISTANT (always standing behind Mr. Big, holds BIG SHINE)
**Who he is:** (Amin 10-20) the CLOWN: a big, goofy, oddly dressed sidekick, over-eager and a little clueless, always trying to help his boss. Comic relief, never serious.
**Voice:** deep, gravelly bass.
**Cadence:** rapid-fire, animated, bouncy; pitch jumps with cartoonish panic.
**Tone:** comical, warm and sincere, playing it big for laughs. Never stiff, military or menacing.
**Exception:** one line ("Big Skin Shine") flips to a silky 1970s soul-radio announcer: slow, velvety, savoring each word. Same voice, totally different mood.

| Shot | Line | How he says it |
|---|---|---|
| V05 | "Sir, who hit us? A lawsuit? The government? Somebody find the CFO? ...Or should I get the goons?" | (Amin 10-20) goofy, over-eager, frantic and helpful; questions tumble out with cartoonish panic; then a beat and a sneaky, proud stage whisper on "Or should I get the goons?" |
| V06 (off-camera, on the spray) | "Biiig... Skin... Shine." | smooth 70s announcer, slow and velvety |
| V10 | (a loud, dramatic gasp) | cartoonish sitcom gasp, pops up high in pitch, no words |

## 4. MS. ANYLIST (Marketing Analyst, side seat, emerald suit)
**Who she is:** the data person who also understands the real world. She's quietly impressed by YO SKINCARE and secretly buys it.
**Voice:** clear, articulate, confident mid-range.
**Cadence:** swift, smooth and conversational, like a confident analyst giving a report she knows cold (Amin 10-20: the earlier "beat after every price" sounded choppy and robotic). Every word and price is clear and easy to understand without being slow; product names run together as natural phrases. Never rattling off numbers, never list-reading.
**Tone:** calm authority, matter-of-fact, with just a hint of being impressed.
**Don't:** sound nervous, fast, robotic, or like she's reading a list.

| Shot | Line | How she says it |
|---|---|---|
| V08 | "Sir, the company's called YO SKINCARE. Their Triple-Action cleanser, exfoliator and toner is nine ninety-nine. SUPA GLO Facial Elixir, fifteen ninety-nine. SUPA GLO Body Oil, thirteen ninety-nine." | steady briefing, each price clearly landed |
| V11 | "It gets worse! Their Complete Routine is only thirty-seven ninety-seven, with sea moss, black seed oil and jojoba, a ten-oil face elixir, a seven-oil body oil, and five-star Google reviews!" | (Amin 10-20) URGENT and escalating, never flat: "It gets worse!" is a bombshell; energy builds item by item; "five-star Google reviews!" is the climax, half alarmed, half impressed. Swift and fully understandable |
| V25 | "...Calendar reminders, sir." | flat, cool, perfectly innocent cover-up |

## 5. MR. 12 STEPS ("the Professor")
**Who he is:** an over-educated skincare scientist who sells twelve-step routines. Proper, a little stuck-up, eccentric, absurd, complicated (Amin 12:02).
**Voice:** (Amin 10-20) NERDY and quirky: a light, thin, slightly nasal tenor, high and reedy, NEVER deep or serious. Pompous, eccentric, prissy over-precise diction; pitch flutters up on words he loves.
**Cadence:** quick, bouncy and theatrical, like a fussy lecture; fussy little beats before technical words, never slow.
**Tone:** condescending and deadpan. He thinks everyone is beneath his science, even when admitting the scam.
**Don't:** sound defeated, mumbly, or cartoon-squeaky.

| Shot | Line | How he says it |
|---|---|---|
| V13 + vial close-up | "Sir, I'm on step nine of twelve. Chemically speaking, it's the same oil as step eight. ...However, its potency has been diluted, to reduce our costs." | "Chemically speaking" said with pride; a beat before "However"; the last part dry and matter-of-fact, as if it's a perfectly normal business decision |

## 6. UNNAMED EXECUTIVES (V07, the scoff)
**Background mutters (low and overlapping, mixed men and women):** "That'll never work." / "Good luck with that." / "Affordable? Please." Dismissive, chuckling under their breath.
**The one clear line (a foreground male executive):** "Uhh... well... what do they consider... affordable?" (Amin 10-20) a young NASAL, nerdy, awkward numbers geek (pinched whiny tenor, voice cracks), totally unlike every other voice; mumbles nervously, then blurts "affordable?" too loud, asking for himself.

---


## The emotional arc (Amin 13:45): shock -> comedy -> over the top -> acceptance
The voices carry the story's arc between the song's opening and its closing. Energy is shown out of 10, and every take gets checked against its number.

| Act | Time (hero) | What the audience feels | Voices |
|---|---|---|---|
| 1. SHOCK | 0:00-0:15 | Hype song, then the record-stop and alarm | Mr. Big "WE ARE UNDER ATTACK!" **9**; Assistant's emergency **8**; "AFFORDABLE!" **9**; "Big Skin Shine" announcer **3** (the first laugh is the drop) |
| 2. COMEDY | 0:15-0:45 | The scam is exposed by calm facts | Executives' scoff **4**; Ms. Anylist steady **4**; Mr. Big's price outrage **8-9**; Mr. 12 Steps' deadpan confession **3**. The joke is calm against explosive |
| 3. OVER THE TOP | 0:45-1:10 | Mr. Big peaks while Madame stays the calmest person alive | "Are you GLOWING?" **9**; "ENEMY into MY boardroom?!" **10** (his loudest moment); Madame **3** throughout; "I DON'T PAY the markup" **4**, firm, never loud |
| 4. ACCEPTANCE | 1:10-end | The room quietly switches sides | Madame's exit line "Ladies... you don't have to go broke to be beautiful." **3**; door click, chimes; Mr. Big "What was THAT?!" **7** (paranoid, losing grip); Ms. Anylist "Calendar reminders, sir." **2**; "Somebody SHINE me!" **6** (denial); the Assistant's silent hesitation says it all; then the song: "We don't play about the brand... Yo skincare" |

**Rule:** Mr. Big's loudest moment is V18. After Madame's punchline his energy never returns to that peak, so the ending reads as acceptance, not more yelling.

---

## Captions
Burned-in captions use these lines word for word, including V21 "Ladies... you don't have to go broke to be beautiful." The end card keeps the full tagline "Keep yourself beautiful. And don't go broke to be beautiful."

## How the voices get made
- Higgsfield has ready-made voices only (no custom design). For each main character I pick the 3 ready-made voices closest to this page, and each reads one line. You choose. About 10 credits.
- Mr. Big's raspy-to-falsetto jump is the hardest to find in ready-made voices. If none of the 3 hit it, the backup is designing him from this description in ElevenLabs and uploading a sample to Higgsfield.
- Every take gets checked against the "Don't" lines above before you hear it.
