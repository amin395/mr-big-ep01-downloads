# Scene 2 video plan (V08 to V12): the prices, pre-checked 2026-10-15 07:50

Model: Kling 3.0 Pro, 9:16, sound off, start frame only. Prices from get_cost. **Total 66.5 cr = HARD CAP.**

| Shot | Start frame | Length | Cost | What happens |
|---|---|---|---|---|
| V08 Ms. Anylist, prices | F3 fixed (job 3bafff82) | 8s | 14 | Seated with her tablet, glances at it then toward Mr. Big: "Sir, the company's called YO SKINCARE. Their Triple-Action cleanser, exfoliator and toner is nine ninety-nine. SUPA GLO Facial Elixir, fifteen ninety-nine. SUPA GLO Body Oil, thirteen ninety-nine." Tiny nervous side-eye on the last price. Stays seated. |
| V08b pen drop (new, Amin 07:23) | Master A (media 52dddd8b) | 5s | 8.75 | Right after the last price: the executive closest to camera freezes, jaw drops, his hand opens and a gold pen falls and bounces on the marble. Everyone else frozen. ~1s used in the edit. |
| V09 shipping joke | F1 (job 910cf1db) | 5s | 8.75 | Mr. Big recoils like he's been slapped, chain swinging, full-body outrage, never smiling: "Exfoliate, Tone & Cleanse for NINE-NINETY-NINE?!" (Amin correction 08:01). Raspy, high-pitched on "NINE-NINETY-NINE". |
| V10 Assistant gasp | F2 (job 5f80a2c9) | 4s | 7 | Gasps, gloved hand flies to his chest, BIG SHINE in the other hand (no silver tray). Dead serious. |
| V11 Complete Routine | F3 fixed (job 3bafff82) | 8s | 14 | Swallows, almost impressed: "It gets worse. Their Complete Routine is only thirty-seven ninety-seven. Sea moss, black seed oil, and jojoba. A ten-oil face elixir. A seven-oil body oil. And five-star Google reviews." Eyebrows up on "five-star". Seated. |
| V12 clutches his chain | F1 (job 910cf1db) | 8s | 14 | Grabs his chain with both hands like a heart attack, wails: "Thirty-seven ninety-seven? For the whole routine?! How are we supposed to sell people twelve steps they don't need?!" On "twelve steps" flings an arm toward frame right (Mr. 12 Steps' side). Never smiling. |

Changes from the prompt pack (later rules win):
- V08/V11: Ms. Anylist stays seated (pack said she stands).
- V10: BIG SHINE instead of the silver tray (props rule).
- V09/V12: "never smiling" added after V06's grin; meltdowns are full-body.
- V08b is new (Amin's option C, 07:23).
- Product photos and price pop-ups beside Ms. Anylist go in during the edit (V08, V11).

## Results (rendered 08:03, QC 08:10). Spent 66.5 of 66.5 cap. Balance 282.85.

| Shot | Job | Result |
|---|---|---|
| V08 | e8055baf | PASS: seated, tablet, consistent |
| V08b | 0b00dc6d | PASS: pen slips and hits the marble ~3.9-4.4s; use ~3.6-4.8s in the edit (ignore an early stray pen ~2s) |
| V09 | ebbf7002 | PARTIAL: grins ~0.5s and ~1.7-3.5s (fail). Last ~1.3s (3.7-5s) is a clean push-in shriek. Free fix: use only the shriek, slowed to ~2s, first half of the line over the cut. Retake = 8.75 |
| V10 | 616a66a4 | PASS: gasp, hand to chest, BIG SHINE |
| V11 | 46e08a9f | PASS: seated, consistent |
| V12 | 995bbcf8 | FAIL: chain clutch reads as a happy grin ~2-5.5s; the point toward 12 Steps at 6-8s is good. Retake 8s = 14 cr, awaiting GO |

### Fix round (Amin chose "Retake V12, trim V09", 09:08). Spent 14. Balance 268.85.
- V09 EDIT (free): shriek 3.7-5.04s slowed 1.5x to 2.0s. Media b64caf53. First half of the line plays over the cut in.
- V12 retake daad1873 (14 cr): still grins ~4.3-5.0s and on the point. Clean: 2.8-4.2s (clutch, anguish) and 5.1-5.9s.
- V12 EDIT (free): retake 2.8-4.2 + retake 5.1-5.9 + original 995bbcf8 6.4-7.15 (point), each slowed 1.25x = 3.8s. Media ea05da5b. The rest of the line runs over the cut to Mr. 12 Steps.
- ROOT CAUSE: F1 (910cf1db) has a faint smile baked in, and Kling keeps drifting back to it. For later angry Mr. Big shots, make an "enraged F1" start frame first (face-only patch, ~2.75 cr).
