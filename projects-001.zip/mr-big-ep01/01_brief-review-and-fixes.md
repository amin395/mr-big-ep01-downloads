# Mr. Big Beauty Ep01 "An Inside Job": Brief Review & Fixes

Goal: make Ep01 funny, accurate, and built to convert as a paid ad on Meta, TikTok and YouTube. This file is the review; the paste-ready prompts are in `02_higgsfield-prompt-pack.md` and the voices and music are in `03_voices-and-music.md`.

---

## 0. Decisions locked with Amin (14 Oct 2026)
| Item | Decision |
|---|---|
| Website | yoskincare.com · Complete Routine page: https://www.yoskincare.com/products/yo-supa-glo-combo-pack (live: $37.97, compare-at $39.97, all 3 scents in stock) |
| Price wording | "Complete Routine ~~$39.97~~ $37.97": $39.97 is the three products bought separately. The price is permanent. |
| Claims | "Lightweight" and "fast-absorbing" are approved. Both are backed by the Complete Routine page ("absorbs fast," "finish light," "lightweight") and the labels ("lightweight blend," "absorbs easily"). |
| Structure | One shoot, three cuts: ~78s hero, 30s, 15s (A and B) |
| Shots | One speaker per shot |
| Voices | ElevenLabs (5 voices). Suno for music only. |
| Mr. 12 Steps | In Ep01, line: "...I'm on step nine, sir. Same oil as step eight." |
| Grease gag | Mr. Big's own heavy oil, "BIG SHINE," sprayed on him three times by the Assistant (V05 plant, V06 spray, V16 refusal) |
| Madame's comeback | "Baby... it's an inside job." |
| Medallion | Gold and diamonds, reads BIG BAGS / BEAUTY / MR. BIG'S |
| Music | "We Don't Play About the Brand" opens, hard-stops on the button slam, returns under the end card |
| End card | Logo, real products, ~~$39.97~~ $37.97, "Lightweight. Fast-absorbing. Made for melanin.", tagline, YOSKINCARE.COM |
| Workflow | Step by step from `00_START-HERE.md`. Each step is approved here before the next one. |

Useful label fact: the Triple-Action Cleanse label says it "helps remove dirt, excess oil and surface buildup without leaving skin feeling stripped." That's the honest product link to the over-oiling joke, and it's good for captions or ad copy.

---

## 1. Verdict

**The concept is strong. The brief is built for a short film, not a paid ad.**

What already works:
- A clear villain (overpriced complexity), a clear hero (a simple $37.97 routine), and a clear payoff line. "I MARK IT UP. I DON'T PAY THE MARKUP!" is a genuinely good closer that also says the brand promise.
- The oily vs. radiant contrast is a visual joke you can read with the sound off, and the brand's own site backs it up: the Facial Elixir is described as "lightweight, non-greasy."
- The product logic is clean: three products, three prices, one bundle price, one action (Add to Cart).

What will hurt it as an ad (fixes are in section 3):
1. **The hook comes too late.** The first 12 seconds are a silent drone shot. On TikTok and Reels most people decide in 1 to 3 seconds. You need a voice and a reason to stay in the first 2 seconds.
2. **100 seconds is too long for paid social.** It's fine for a YouTube hero cut. Meta and TikTok paid placements will do better at 15 to 45 seconds. Shoot once, cut three lengths.
3. **The shot plan asks the AI to do too much per shot.** Prompts 02 to 07 each have 2 or 3 speakers, a camera move and props. That's where face swaps, wrong lip-sync and voice drift come from. One speaker per shot is the single biggest reliability fix.
4. **Voices are not solved.** Cinema Studio 4.0 now generates native audio, so if you type dialogue into a prompt it will invent a new voice every shot. You need one locked voice per character from outside Higgsfield (see file 03).
5. **There's no CTA or URL on the end card.** A paid ad has to tell people where to go. Add "YOSKINCARE.COM" and "Complete Routine $37.97".
6. **No captions in the plan.** Most feed viewers watch muted. Burned-in captions are mandatory in post (the brief correctly says "no subtitles" in generation; it just never adds them back).
7. **You uploaded a fifth character the brief never uses: Mr. 12 Steps.** He is the perfect visual for Mr. Big's own line, "How are we supposed to sell people twelve steps they don't need?!" Use him (section 3.4).

**How I think it will do:** as an organic piece and a YouTube hero, it should land well, because the characters are big, the joke is culturally specific and the price story is simple. As paid media, the 100-second cut alone would likely get low completion and expensive clicks. With a 2-second hook, a 30-second and a 15-second cutdown, captions, and a URL end card, I'd expect it to be competitive, with the 15s and 30s carrying conversions and the long cut building brand recall and retargeting audiences. That expectation is inferred from how short-form paid video generally performs, not from data on this account.

---

## 2. Fact check against yoskincare.com (checked 14 Oct 2026)

| Brief says | Site says | Status |
|---|---|---|
| Triple-Action Cleanse $9.99 | "Triple-Action Cleanse": African Black Soap face & body wash, 9 fl oz, from $9.99 (Unscented, Peppermint, Lemongrass). Shown with a struck-through $29.97. | ✅ Price right. The $29.97 strike-through looks odd; worth checking with whoever runs the store. |
| SUPA GLO Facial Elixir $15.99 | "SUPA GLO 10-Oil Facial Elixir", 2 fl oz, $15.99 | ✅ |
| SUPA GLO Body Oil $13.99 | "SUPA GLO 7-Oil Body Oil", 8 fl oz, $13.99 | ✅ |
| Complete Routine $37.97 | "YO SKINCARE Complete Routine": Cleanse + Facial Elixir + Body Oil. **Sale $37.97, regular $39.97.** | ⚠️ It's a sale price. If the sale ends while the ad runs, the ad is wrong. Confirm it's permanent or plan to update the end card. |
| Sea moss, Ethiopian black seed oil, jojoba | All three are in the Triple-Action Cleanse. The Facial Elixir has black seed + jojoba, **no sea moss**. | ✅ True for the routine as a whole. Never say "the Elixir has sea moss." |
| Five-star Google reviews | "5.0 out of 5 stars on Google", "Based on 62 Google reviews" | ✅ Safe as written. Don't add the count (it changes). |
| "Fast-absorbing" (section 1 of the brief) | **Correction:** the Complete Routine page says "absorbs fast" and "finish light," and the Body Oil label says "absorbs easily." | ✅ Approved for use |
| Brand line | "Botanical Skincare for Melanin-Rich Skin" | ✅ Matches positioning. |

Product page URLs (for the screen recording):
- Complete Routine set: https://www.yoskincare.com/collections/combo-pack
- Facial Elixir: https://www.yoskincare.com/products/supa-glo-10-oil-facial-elixir
- Body Oil: https://www.yoskincare.com/products/supa-glo-body-oil

---

## 3. Recommended changes

### 3.1 Runtime and structure (pick one)

| Option | What you make | Pros | Cons |
|---|---|---|---|
| A. Keep 100s only | The brief as written | Least editing | Weak paid performance, slow open |
| **B. One shoot, three cuts (recommended)** | ~75s hero + 30s + 15s from the same footage | Best for paid; shoot cost barely changes | More editing |
| C. Rewrite as a 30s spot | 30s only | Cheapest | Loses the world and characters you've built |

**Pick B.** You generate the same shots once and cut them three ways. The hero runs on YouTube and organic; the 30s and 15s are the paid workhorses.

### 3.2 The hook (first 3 seconds)
Current: 12s drone, no voice. Change to:
- 0:00 Drone push on the tower **with Mr. Big's voice pre-lapping**: "Ladies and gentlemen..." plus on-screen text "MR. BIG'S BEAUTY HQ — ATLANTA".
- 0:03 Smash cut: his oily hand slams the red button. "WE ARE UNDER ATTACK!" Siren.
- The balcony walk becomes two shots joined by a cut on action (he turns on the balcony, cut, he strides through the doors inside). The single continuous "drone to balcony to boardroom" move is the riskiest generation in the whole plan and adds nothing a cut can't do.

### 3.3 One speaker per shot
Every dialogue shot in the new shot list has exactly one person talking, 3 to 8 seconds long. Reactions are separate silent shots. This is how real sitcoms are cut anyway, and it's what keeps AI faces and lips stable.

### 3.4 Add Mr. 12 Steps (from your uploads)
He's already built: glasses, frock coat, strapped with LED masks, vials and gadgets. He becomes the walking punchline:
- MR. BIG: "How are we supposed to sell people twelve steps they don't need?!"
- Cut to MR. 12 STEPS, gadgets beeping. His LED mask slides off and clatters. He says nothing, or one line: "...I'm on step nine, sir."
- He's also a perfect 15s cutdown opener.

**Default I picked:** he's the company's "Chief Routine Officer." Tell me if he was meant for a later episode instead.

### 3.5 Make the grease his product's fault (fixes a logic gap)
YO SKINCARE sells **oils**. A sharp viewer will say "so the oily people need... oil?" Fix: the grease comes from Mr. Big's own heavy product.
- Prop: a gold jar on the table, "MR. BIG'S 12-STEP GLAZE." The Assistant is constantly blotting Mr. Big's face with the green towel from his tray (he already carries the tray, fan and mirror in his reference).
- Madame's line now reads as: his product = grease spill, YO = glow. That also matches the site's "lightweight, non-greasy."

### 3.6 Script trims and punch-ups

| Beat | Current | Suggested | Why |
|---|---|---|---|
| Analyst price read | Reads all three prices (about 18s) | "Sir... the company's called YO SKINCARE. Cleanser, nine ninety-nine. Face elixir, fifteen ninety-nine. Body oil... thirteen ninety-nine." Prices also on screen. | Faster, and it sets up the shipping joke |
| Routine reveal | "...sea moss, Ethiopian black seed oil, jojoba—and five-star Google reviews." | Keep. Split into its own shot. | Accurate per the site |
| Betrayal reply | "Please. It's called having standards." | **Option 1:** "Baby... it's an inside job." **Option 2:** "Please. I read labels for a living." Keep the original as option 3. | Option 1 pays off the episode title |
| Closer | Locked | Locked. Music fully drops 0.5s before her line. | |
| End card | Tagline only | Tagline + logo + "Complete Routine $37.97" + "YOSKINCARE.COM" | A paid ad needs a destination |

### 3.7 Platform and compliance must-dos
- **Never cut the two skin prop references side by side.** The oily and glowing images are the same people, so together they are a before/after. Meta's ad policy restricts before/after imagery for skincare. Use them only as texture references attached to generations.
- **No "fixes oily skin" wording** anywhere, in the ad or its copy. The glow contrast is satire, as your brief already says.
- **Turn on AI-content disclosure** at upload. TikTok, Meta and YouTube all ask for a label on realistic AI-generated people.
- **Red-soled heels** are Christian Louboutin's trademark. In a paid ad it's a small but real risk. Lower-risk swap: gold soles ("she doesn't pay the markup, but she does have taste"). Your call; I left red in the prompts because the reference has it, and the swap is one word.
- **Safe zones:** keep faces and text out of the bottom ~20% and right edge of 9:16 frames (TikTok and Reels UI). The prompts frame for this.
- **Formats:** deliver 9:16 for all three platforms, plus a 4:5 crop of the 30s for Meta feed. Frame action centered so the crop works.

### 3.8 Fix in the references before you lock them
- **Mr. Big's medallion text is garbled** ("BIG BAGS BEAUTY / MR. BIG BEAUTY" in mixed AI lettering). Video models copy it and it will shimmer on screen. Either regenerate the medallion as a crown shape with "MB" only, or keep it blurred in close-ups. Prompt is in file 02 (IMG-06).
- **Pick one company name.** The brief uses both "Mr. Big's Beauty" (building) and "Mr. Big Beauty" (character/series). I used **MR. BIG'S BEAUTY** for the company and signage, **Mr. Big** for the man.
- **Never let the video model draw signage or labels.** Generate the tower and wordmark as a still with an image model that handles text, then animate from that still. Product labels and the website are always real footage or composites in post.

### 3.9 How to run it through ChatGPT
ChatGPT tends to "improve" prompts. Tell it at the start of each session:
> "Paste the prompts I give you into Higgsfield exactly as written. Do not rewrite, shorten, translate or add to them. Apply the SETTINGS block in the model controls, not in the prompt box."

Each shot in file 02 has a SETTINGS block (dropdowns and attachments) separate from the PROMPT block (the text to paste). That split is the main fix for the "references mentioned but not attached" problem in your earlier runs.

---

## 4. Higgsfield facts I checked (vs. the brief)

| Brief says | Current info | Source |
|---|---|---|
| Cinema Studio 4.0, 4 to 30s clips | Up to 30s per generation, up to 1080p, **up to 50 reference images**, Tempo setting (Chaotic / Dynamic / Calm / Single Shot), Genre (incl. Comedy), 30+ camera presets, Elements for reusing characters, locations and props, forward/backward Extend | [Higgsfield blog](https://higgsfield.ai/blog/cinema-studio-4-0), [review](https://diyai.io/ai-tools/video-generation/reviews/higgsfield-review/) |
| 9:16 | Not every model supports every ratio. Check that 9:16 is selectable in Cinema Studio before each job. | [Higgsfield help](https://higgsfield.ai/creator-hub/help-center/ai-models/how-do-i-use-lipsync-voiceover-and-aspect-ratios) |
| Audio added in post | Cinema Studio **generates native audio**. Lipsync tools accept a custom voice cloned from an uploaded MP3/WAV sample. | same help page |
| 2,500-character prompt limit | Not published. My prompts stay under ~900 characters, which is safer anyway. | |
| Credit costs | Not published per job. Check the cost shown before you hit Generate. | |

Practical rules:
- **Use Single Shot tempo** for every shot in this plan. Multi-shot tempos cut on their own and break continuity.
- **Don't use 30s generations.** Use 5 to 8s. Longer isn't more reliable, which the brief already says.
- **Test before you batch.** Run Shot 03 (one speaker, Mr. Big, button slam) first and judge face, lips and voice before spending on anything else.

---

## 5. Paid media plan (short)

**Audience:** women and men 25–54 interested in Black-owned beauty, natural skincare, African black soap, melanin skincare; Atlanta DMA first, then national.
**Offer:** Complete Routine $37.97 (3 full-size products).
**Positioning:** "Don't go broke to be beautiful": simple botanical routine vs. 12-step markup.
**Objections to answer in copy:** "Is it legit?" (5.0 on Google), "Will it make me greasy?" (lightweight, non-greasy), "Is it for my skin?" (made for melanin-rich skin).

**Test plan (weeks 1–2):** 3 cuts (15s, 30s, 75s) × 2 hooks (button slam open vs. Mr. 12 Steps open), so 6 ads per platform.

**Budget range (assumed, adjust to your numbers):**

| Scenario | Daily | 14-day test |
|---|---|---|
| Conservative | $30/day per platform (Meta + TikTok) | ~$840 |
| Base | $50/day per platform + $20/day YouTube | ~$1,680 |
| Aggressive | $100/day per platform + $40/day YouTube | ~$3,360 |

**Break-even CPA** = order value × gross margin. At $37.97 and an **assumed** 65% margin after shipping, that's about $24.68 per first order. Send me your real margin and shipping cost and I'll redo it.

**KPIs to watch:**
- Hook rate (3s views ÷ impressions): aim ≥ 30%
- Hold rate (15s views ÷ 3s views): aim ≥ 25%
- CTR (link): ≥ 1.0% Meta, ≥ 0.8% TikTok
- Cost per Add to Cart and CPA vs. the break-even above
- Kill any ad under 20% hook rate after ~3,000 impressions

**Ad copy starters**

Opening on-screen text hooks (pick per cut):
1. "Big Beauty just called an emergency meeting."
2. "When skincare gets affordable, somebody panics."
3. "POV: you're the CEO of overpriced skincare."
4. "He charges $13.99 for SHIPPING."
5. "12 steps? Baby, it's 3."
6. "The boardroom is shining. Not in a good way."
7. "She marks it up. She don't pay the markup."
8. "The inside job nobody saw coming."
9. "Glow vs. oil spill." (Amin changed "grease" to "oil", 14 Oct)
10. "$37.97 for the whole routine?!"

Headlines: "The Complete Routine: $37.97" · "Don't Go Broke to Be Beautiful" · "3 Products. Not 12." · "Botanical Skincare for Melanin-Rich Skin" · "5.0 on Google. Made for Melanin."
CTAs: "Shop the Complete Routine" · "Get the 3-Step Glow"
Recommended primary text (Meta): "Mr. Big's empire runs on 12 steps you don't need. YO SKINCARE does it in 3: Triple-Action Cleanse, SUPA GLO Facial Elixir and SUPA GLO Body Oil. Complete Routine $37.97. Don't go broke to be beautiful."

---

## 6. Assumptions I made
- Website is **yoskincare.com** (please confirm).
- $37.97 stays the bundle price for the ad's flight.
- Mr. 12 Steps is a Mr. Big executive and can appear in Ep01.
- Company name on signage: MR. BIG'S BEAUTY.
- Voices: ElevenLabs for dialogue, Suno for music (file 03).
- You have, or can export, real product photos and the logo from the store.

## 7. What I need from you
1. Confirm the website URL and whether $37.97 is permanent.
2. Upload: product photos (all 3 + the bundle, clean background), the YO SKINCARE logo, and any Atlanta skyline or tower images you've already approved.
3. Pick the betrayal reply (Option 1 "it's an inside job" is my pick) and say yes or no to Mr. 12 Steps.
4. Your gross margin and shipping cost, so I can fix the break-even number.
