# Voice auditions, round 1 (2026-10-16 14:01), 15 takes, 6.75 credits
Engine: text2speech_v2 / elevenlabs / preset voices. All 15 takes read every word correctly (checked by transcript); no stage directions spoken aloud.
Base URL: https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261016_<id>.mp3

| Character | Voice (voice_id) | Job | Notes |
|---|---|---|---|
| Mr. Big | Andre f1e8226e-2248-4d5f-b43c-0a79e9949dbf | 140109_0879aec2-3ff1-4e5b-ae27-d58efa079590 | mid 198 Hz, jumps ~10 semitones on AFFORDABLE |
| Mr. Big (PICK) | Sterling dc382508-c8bd-443c-8cb2-46e57b8d2e6f | 140109_3c58654c-a1cc-40a0-b95e-9227eb63a54f | low Southern base 104 Hz, biggest jump (~15 st) |
| Mr. Big | John 6b528d43-c056-4a2f-9d82-1591a7ba13b0 | 140109_3902ba84-439d-4b39-bee2-d420e9d0fa91 | nasal character voice, high all the way, small jump |
| Madame | Sloane b57b22a0-f287-405b-bc82-6f08f5e6bb1f | 140109_2d702984-654d-48eb-895a-9027d2d4ba33 | highest of the three (174 Hz) |
| Madame (PICK) | Tallulah f32c8f51-449e-4ddf-bdf7-1527e11df917 | 140109_73a7857b-c1b7-441b-a68c-937b9966295f | low alto 139 Hz, steady, Southern |
| Madame | Linda f82790fd-8283-5187-9e3f-cc8e99bc5b17 | 140110_1bf55614-0287-49a5-b3d8-ceb9b2c399aa | lowest (98 Hz), dry |
| Assistant (PICK) | Gideon 1ad38ba4-9cc4-4f2f-9fde-b0fefdf67ae5 | 140110_37a514c1-4039-4417-bb68-25a1dcbeef6b | only one that stayed deep while shouting (114 Hz) |
| Assistant | Landon dc1c0a41-53cd-53af-aec5-ab637840505f | 140110_d1a5fe83-4fb1-4c3b-a4e4-0665e2fe81b7 | went up to 245 Hz, "lawsuit" slurred |
| Assistant | Fraser 6705e465-7b52-5915-a1d8-b1222885e01d | 140109_58106168-55fc-4f32-9ae0-eb2a738b155b | went up to 230 Hz |
| Ms. Anylist (PICK) | Elena ca83ca7f-c186-493d-bd69-0d765fa861b2 | 140109_855a1e2d-d23d-47d0-9475-8c3ec721a4dd | crisp, 4.4s |
| Ms. Anylist | Maya b0f766b7-8703-4bd1-b973-f857c36837b6 | 140109_cbbe5d69-65a7-40ed-96d0-ebdf6ff8745b | warm, 4.5s |
| Ms. Anylist | Quinn 80914268-dfae-4f76-8306-36f2d55f58f8 | 140109_b393101e-28d1-4c88-8cc8-4e69d640d6ac | slowest, most deliberate, 5.0s |
| Mr. 12 Steps (PICK) | Xavier 43173c95-3ec8-446a-a162-6504332c578b | 140116_60527d5c-182e-4c94-b8f3-96e2b3f3bf04 | precise, 106 Hz, 11.6s |
| Mr. 12 Steps | Alistair d9d5c263-f84e-4752-97b5-3750fcc6fd2f | 140116_eda9e819-f6d4-4f13-bc7d-e900551ae2df | very deep (75 Hz), not "thinner" |
| Mr. 12 Steps | Alexey 7c2133e5-68ab-511f-9aed-9a67664382b1 | 140116_0d1f3170-6217-4373-943c-682fbd0d7c52 | trails off at the end |

Edit notes (free, no re-record): Madame takes have a 0.5-0.8s gap between "I mark it up." and "I DON'T PAY"; tighten in the edit per the no-gap rule. 12 Steps takes run 10.7-11.8s vs 9.4s of picture (V13 slow + vials); tighten pauses about 1s and/or speed 1.1x, else move "Sir," onto the end of the previous shot.
Thumbnails in the voice library are plain gradients; picks are from the voices' own descriptions plus pitch/timing measurements. Accent and attitude need Amin's ear.
