# Ep01 storyboard plan (from the approved masters)

Approved by Amin 2026-10-15 05:16:
- **Master A** (toward Mr. Big): Higgsfield media 52dddd8b
- **Master B** (toward Madame and the exit): Higgsfield media 2dadadc5

## How every frame is made
- Every frame is built from Master A or Master B, so the room, seats, lighting and cast stay the same.
- Each main character is also checked against their own master character image. Only their framing changes.
- Model: GPT Image 2.5, high quality, 2K, at 2.75 credits per frame. Nano Banana is not used, because it turns oil into white streaks.
- If a retouch drifts somewhere else in the frame, the good region is pasted onto the approved frame locally, at no cost.
- Actions, props and lines come from 02_higgsfield-prompt-pack.md and the script.
- Where Amin's later rules overrode the pack, the later rule wins:
  - everyone stays seated;
  - Ms. Anylist stays seated;
  - Madame has the Telfar bag;
  - Mr. 12 Steps wears the burgundy coat;
  - the oil is wet, with at most a small drip.
- A frame only goes to Amin after it passes CONTINUITY-CHECKLIST.md.

## Frames: 8 new frames, plus the 2 masters and 1 free composite

One start frame serves several shots. Kling animates a different action from the same frame, which keeps those shots consistent.

| Frame | What it shows | Used for |
|---|---|---|
| Master B | Wide from behind Mr. Big down the table to Madame | V04 panic |
| Master A | Wide toward Mr. Big, balcony behind | V07 stunned silence |
| F1 | Mr. Big medium close-up at the head of the table. Red button in front, balcony and skyline behind, Assistant behind his shoulder with BIG SHINE | V06, V09, V12, V14, V16, V18, V24, V26 (and V03 if Amin wants it rebuilt) |
| F2 | Assistant medium close-up behind Mr. Big, balcony behind, BIG SHINE in hand | V05, V10 |
| F3 | Ms. Anylist medium close-up in her seat with her tablet. The wall behind her matches her side of the room in Master A | V08, V11, V25 |
| F4 | Over Ms. Anylist's shoulder: tablet with a green screen, Madame's chair empty | V22 |
| F5 | Mr. 12 Steps medium shot in his seat, full gear, burgundy coat | V13 |
| F6 | Madame close-up in her end chair, bare-faced with an intense glow, exit doors behind | V15 |
| F7 | Madame standing beside her chair holding the green Telfar bag (logo visible), exit doors behind | V19, V20, V21 start |
| F8 | Master B with Madame gone: chair empty, exit door just closed | V21 end, V23 |
| V17 | BUILT 05:57, 0 cr: F6 table at Madame's end + real Telfar photo (logo visible) + real product elements (Cleanse Unscented 59534827, Body Oil a0b05eb8, 10-Oil Elixir e76a9519). Still = media 5734e881, 2.5s push-in = media 3eba4104. Lower third left clear for the $37.97 pop-up | V17 (free) | **ANIMATED 18:41 (Amin chose A): media 845bad34, 4.6s, products rise out of the Telfar bag one at a time (soap, body oil, elixir), pop onto the table, end on the still layout.** |

**Cost cap: 22 credits** (8 frames at 2.75 each). If any frame needs a second try beyond the cap, stop and ask Amin first.

## Clips that no longer match (re-animate after the storyboard is approved; video cost to be quoted then)
- **V08, V11, V25 (Ms. Anylist):** the gold horse statue sits behind her, but in Master A it is on the opposite wall (Mr. 12 Steps' side).
- **V15, V19, V20 (Madame):** need the bare-faced glowing Madame. V19 and V20 also need the Telfar bag; she held a white bag and then a tan one.
- **V03 (button slam):** a marble wall is behind Mr. Big instead of the balcony. Amin approved it earlier, so this is his call.
- **Kept as is:** V01 and V02.

## Fix round 2026-10-15 06:05 (Amin GO, cap 13.75 cr, spent 13.75; balance 422.1)
- **F3 Ms. Anylist** = job 3bafff82: white streaks gone, wet glossy shine.
- **F4 secret tap** = job 9450a051: REBUILT per Amin 06:04. She sits in her own side seat (left side of Master A) and faces ACROSS the table toward the side wall (Mr. 12 Steps, execs, gold horse statue). Head of table, balcony, button and both ends are out of frame. Tablet solid green, below the table edge. No blob.
- **F6 Madame CU** = media 3bd08c80 (job ff572c6a + free local highlight bloom; skin tone unchanged).
- **F7 Madame standing** = job 573accb4 (stronger glow; Telfar logo visible).
- **Master B v2** = media e59a0f83: approved 2dadadc5 with only Madame's face region patched from job e1f84d1d (now matches her ref a52133b3: mature face, hoops, gold chain).
- Rule from Amin 06:04: Ms. Anylist is NEVER framed from the head of the table or looking down the table toward Madame; she is always in her side seat.
