# Scene 5 video plan (V22 to V26): the ending. Pre-checked 2026-10-15 19:05

Model: Kling 3.0 Pro, 9:16, sound off, start frame only, 1.75 cr/s. **Total 42 cr = HARD CAP.** Nothing runs before Amin's clear GO on this number. Balance before: 187.35, after: 145.35.

| Shot | Start frame | Length | Cost | What happens |
|---|---|---|---|---|
| V22 Add to Cart | F4 (job 9450a051) | 5s | 8.75 | Ms. Anylist in her side seat, facing across the table to the side wall. Tablet solid green, held low below the table edge. She glances up to check nobody is watching, taps the center of the screen once, tiny satisfied smile. (Post: key the green and drop in the real Complete Routine page, $37.97, Add to Cart tap; chime SFX.) |
| V23 More chimes | F8 (job 127b64aa) | 5s | 8.75 | Madame's chair empty, door closed, everyone in their fixed seats. Unnamed oily executives around the table glance at each other and at the ceiling, whistle, straighten ties, slide phones face down, acting like nothing happened. Nobody stands, nobody on the table. (Post: 3 to 4 chimes staggered over it.) Assistant and Mr. 12 Steps do NOT buy. |
| V24 "What was THAT?!" | F1-stern (media bad4886e) | 4s | 7 | At the button, balcony behind, Assistant behind with BIG SHINE. He whips his head side to side, full-body outrage, voice cracking high. Never smiling. |
| V25 "Calendar reminders, sir." | F3 (job 3bafff82) | 4s | 7 | Ms. Anylist in her side seat, emerald suit. Slides the tablet face down on the table, looks up deadpan: "...Calendar reminders, sir." |
| V26 The tease | F1-stern (media bad4886e) | 6s | 10.5 | Mr. Big snaps "Somebody SHINE me!" The Assistant raises BIG SHINE, hesitates one beat and glances down the table toward the door Madame left through, then sprays anyway. Mr. Big doesn't notice. Never smiling. |

Then the end card (built in post, free): real logo, real products, COMPLETE ROUTINE ~~$39.97~~ $37.97, tagline, YOSKINCARE.COM, brand song.

Rules applied: fixed seats, Mr. Big standing at the button with the balcony behind in every Mr. Big shot, Assistant behind him holding BIG SHINE, Ms. Anylist framed from her side seat, nobody on the table, Madame's chair stays empty after her exit, no product held in AI shots.

## Run (Amin GO 20:13, cap 42)
- Jobs: V22 a3fd66ae, V23 17d1b880, V24 8e77213b, V25 0050b7e4, V26 5a53e3a5.

## Results (QC 20:22). Spent 42 of 42. Balance 145.35.
| Shot | Job | Result | Use |
|---|---|---|---|
| V22 | a3fd66ae | PASS: side seat, checks around, taps the green tablet, tiny smile | raw |
| V23 | 17d1b880 | FIXED free: shot from the balcony behind Mr. Big, execs look at the ceiling/whistle/slide phones, chair empty. Assistant walked out of frame at ~1.8s; patched him back from frame 2 (static, BIG SHINE readable) | edit 0067bf0b |
| V24 | 8e77213b | FIXED free: paranoid head whips 0-3.0s; lunged + big grin at 3.2s+ cut | edit 412028d1 (silent; "What was THAT?!" plays over the end of V23 while we see his back) |
| V25 | 0050b7e4 | PASS: slides tablet face down, deadpan "Calendar reminders, sir." | raw |
| V26 | 5a53e3a5 | FIXED free: 1.0-2.7s hair morphed into a braid; use 3.0s-end (eyes shut waiting, Assistant hesitates/looks away, then sprays) | edit 3bf669fb ("Somebody SHINE me!" plays off-camera over the end of V25) |

## V22 screen insert (Amin 23:58)
- Amin sent his real screen recording of the Complete Routine page -> Add to Cart -> Cart ($37.97): /mnt/user-data/uploads/hearth/a292a78f-c5a8-4f2d-8a0a-4d0e186e34fd/a292a78f-c5a8-4f2d-8a0a-4d0e186e34fd.mp4 (1080x2316, 12.1s; tap ~4.5s, cart from ~8s). Cart badge shows 2 and a second item peeks in at the bottom: crop to the Complete Routine line only.
- V22 tablet: green quad ~190x330 px, tilted ~60 deg, around x 490-780 / y 1370-1740; finger tap ~3.5-4.0s. Plan: product page (price + ADD TO CART) before the tap, cart page after; key the green per frame, corner-pin, keep the finger on top. Free.
- Blocked: this workspace can't reach upload.higgsfield.ai, so Amin was asked (00:0x 10-16) to upload the recording into Higgsfield himself; then find it with show_medias.
- 00:27 10-16 Amin sent a CLEAN recording (replaces the first): /mnt/user-data/uploads/hearth/6e145fc3-7e32-47a7-b0e5-4fdff9aba22e/6e145fc3-7e32-47a7-b0e5-4fdff9aba22e.mp4 (1080x2316, 21s). Product page -> ADD TO CART pressed ~4.2s -> Cart (1 item, $37.97) ~5s -> scroll to Subtotal $37.97 + CHECK OUT ~9.2s -> checkout page ~11s (shows $39.49 with shipping: never use). Amin: END when she presses checkout. Plan: content 0 to ~9.5s sped up over V22 0-3.6s, her single tap (~3.6s) = CHECK OUT press, end there.
- Still not in Higgsfield (show_medias checked 00:30). Asked Amin to upload it into Higgsfield himself (where he added the Telfar Element), named "V22 Add to Cart screen".
- 00:45 10-16 DONE (free): Amin's recording in Higgsfield = media 0f8173d9 (VFR; use CFR copy). Add to Cart press 4.1s, cart loaded 6.4s, CHECK OUT press 10.7s.
  - V22 with screen: media 34b1bcff (keyed green tablet, tracked; product page, her tap at 3.9s = Add to Cart, then cart).
  - V22b close-up insert 2.25s: media 32476fc4 (Add to Cart tap ripple -> Cart $37.97 -> Subtotal $37.97 -> CHECK OUT tap ripple, ends on the press; never shows the $39.49 checkout page).
  - Edit: V22 0-3.95s -> V22b -> V23. Preview of both together: media 9ad12a53 (6.2s).
- 01:12 10-16 REDONE per Amin ("tracking flips upside down, looks stupid; just show products, Add to Cart, hit Check Out"): media ca5d9252 (6.25s). V22 0-3.95s with the green screen replaced by a plain lit screen (no tracked content), then a straight full-screen cut of the real recording: products group photo 0.9s -> ADD TO CART press 0.7s -> CHECK OUT press 0.7s. SUPERSEDES 34b1bcff / 32476fc4 / 9ad12a53. Never tracked/rotated content on the tablet again.
- 02:3x 10-16 REDONE per Amin 02:20 ("when she has the pad in her hand it should show the products right there on the pad, then go to the screen itself"): media 8e5aa009 (6.29s), FINAL. V22 0-3.95s with the YO site header + the three products shown ON her tablet (tracked with orientation locked upright: cyclic corner matching + winding check, no flips; products placed right of center so her sleeve never hides them), then straight full-screen cut: products 0.9s -> ADD TO CART press 0.7s -> CHECK OUT press 0.7s, ends on the press. SUPERSEDES ca5d9252. Any future tablet content must stay upright and steady (v22pad.py in sandbox anim/).
- 10:1x 10-16 REDONE per Amin 10:08 ("screen still looks distorted; picture should just be there, still, despite her moving; then directly to Add to Cart and Check Out"): media da048c19 (5.42s), FINAL. Pad picture is now a RIGID image (rotation + move only, fixed size, heavily smoothed, never stretched or skewed; sandbox anim/v22rigid.py), YO header + three products. Then straight full-screen ADD TO CART press 0.75s -> CHECK OUT press 0.7s (no extra products shot; B2.mp4 via v22b2.py). SUPERSEDES 8e5aa009. Rule: tablet content is never perspective-warped.
- 11:05 10-16 REDONE per Amin 10:57 ("everything is supposed to move with the iPad, like it normally would, not distorted"): media 8883b2ad (5.42s), FINAL. The product page is now pinned to the iPad screen itself: per-frame fit of the real screen edges (top + both long edges, RANSAC on the green boundary, fixed screen aspect 1.72), so the page moves, tilts and turns exactly with the iPad, like a real screen (sandbox anim/v22edge.py -> v22glue.py). Then straight full-screen ADD TO CART -> CHECK OUT (B2.mp4). SUPERSEDES da048c19 (rigid image that slid around) and 8e5aa009 (warped).
