# Ep01 finished clips (silent, Kling 3.0 Pro, 1076x1928)

All clips passed the [continuity checklist](CONTINUITY-CHECKLIST.md) by eye on 2026-10-14. Voices, music, product graphics, end card and captions get added in the edit.

**Dailies reel V04 to V26, in story order (127s, labeled):** [watch](https://d2ol7oe51mr4n9.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/b324b67b-43a1-4b33-a430-460eb9016600.mp4)

| Shot | Beat | Clip |
|---|---|---|
| V01 | Tower flight ending on Mr. Big in full color on lower balcony | APPROVED 06:45 Kling 8b530f89 (start = old V01 frame 0, end = image 2acf8b59), 13.25 cr. Old: Kling edit 4a24e2f9 (silhouette) |
| V02 | Balcony entrance | Amin's take (approved/video/V02_pick_raw.mp4). EDIT: ends at ~3.3s as he pulls the door open; never show the room interior (Amin 07:38). Hard cut to V03 slam (3b52de8b). |
| V03 | Button slam | approved/video/V03_v1.mp4 |
| V04 | Panic, red alarm | [b43d0e69](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195203_b43d0e69-a9d4-4463-92c1-da5af8b9e816.mp4) |
| V05 | Assistant: "Who hit us?" | [80dfb6ee](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195203_80dfb6ee-64ff-44fa-b112-97a1ec3f924c.mp4) |
| V06 | "Affordable!" + BIG SHINE spray | [ecf3a945](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195203_ecf3a945-fda9-42b6-a56c-99a9ecf3ee59.mp4) |
| V07 | Stunned silence, pen drop | [75d6fae5](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195952_75d6fae5-84e5-46c1-89fa-ac6fec9e1a8f.mp4) |
| V08 | Ms. Anylist: prices | [cceb8ba4](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_201103_cceb8ba4-644e-45eb-bacc-0a0c6ee03030.mp4) |
| V09 | "That's what we charge for SHIPPING!" | [3bcf6494](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195203_3bcf6494-29b7-4856-af6d-a579aeeabacf.mp4) |
| V10 | Assistant gasp | [92e5d397](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195203_92e5d397-ee6f-41b4-955c-c40235822560.mp4) |
| V11 | Ms. Anylist: Complete Routine | [ed919c5d](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_201242_ed919c5d-e57f-4701-98b8-dc39c1e90341.mp4) |
| V12 | Mr. Big clutches chain | [607773db](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195203_607773db-74ba-45ed-898c-58c63e1438d4.mp4) |
| V13 | Mr. 12 Steps: "step nine" | [e7fb9a82](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_201103_e7fb9a82-6d50-4ef4-80e7-e6b9fb1dc502.mp4) |
| V14 | "Glazed doughnut?" | [c26e93ef](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195203_c26e93ef-298c-47f7-be12-7b57878de134.mp4) |
| V15 | Madame: glow vs. oil spill | [e8963f9a](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195240_e8963f9a-b147-4934-a9db-8fe89227fece.mp4) |
| V16 | Pushes BIG SHINE away | [4e43ce46](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195240_4e43ce46-ec93-4bcf-972f-c7e1252a4481.mp4) |
| V17 | Handbag product reveal | BUILT 2026-10-15: still media 5734e881, push-in media 3eba4104 (awaiting Amin OK) |
| V18 | "The ENEMY" meltdown | [f1e92d35](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195240_f1e92d35-1f53-4f00-abfb-89277a298e21.mp4) |
| V19 | "Inside job" (mirror in edit) | [1760412d](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195240_1760412d-a1c1-4ecd-b2ca-24010cfa85aa.mp4) |
| V20 | "I mark it up" (mirror in edit) | [6cc58c8f](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_200341_6cc58c8f-0aff-4c8f-8845-0e7e4c3fb9f0.mp4) |
| V21 | Madame walks out | [917ed4cb](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195241_917ed4cb-5041-4d2b-a6f5-e14d2fdf664d.mp4) |
| V22 | Secret Add to Cart | [d4749d0d](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195240_d4749d0d-0147-46b1-a788-b3cac564a76e.mp4) |
| V23 | Phones under the table | [088b0c25](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195240_088b0c25-8a7a-4fc9-93e1-68aa604b2d3d.mp4) |
| V24 | "What was THAT?!" | [a7b0206b](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195952_a7b0206b-2f63-4bc2-8ab8-90889617a4a4.mp4) |
| V25 | "Calendar reminders, sir." | [39ad0146](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_201553_39ad0146-d458-42cf-9236-ced45d5725d4.mp4) |
| V26 | "Somebody SHINE me!" | [58b32bd3](https://d8j0ntlcm91z4.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/hf_20261014_195241_58b32bd3-917b-4895-9837-2a4b39f72c28.mp4) |

Notes: V19 and V20 are mirrored in the edit so Ms. Anylist and Mr. 12 Steps stay on the same sides as every other table shot. V08, V11, V13 and V25 were re-animated from oilier start frames (FLUX oil pass rejected: white streaks, changed faces).

## 2026-10-20 Mr. Big likeness fix (supersedes the Mr. Big shots above)
Start frames from master 18a72730: 0dee231b (veneers), 3cf07367 (closed glare), expression frames 311ca3bc / 1ad8c8a4 / 919038e0. Review reel (labeled, 66s): https://d2ol7oe51mr4n9.cloudfront.net/user_3KOzJVP27QgwHOIL4gn9cNAtzgO/a360d926-dbff-450d-ad6a-8c3199d5a79b.mp4
| Shot | New clip (Kling job / media) | Edit note |
|---|---|---|
| V02 | 3009460b | use 0-3.3s |
| V03 | c6107ba6 | use 0-3.3s (grins after) |
| V04 | media 7070fbf6 (shine; job 4c9d28c2) | reverse angle |
| V06 | 75aeb7c0 | |
| V07 | media a2609571 (shine; job dcc5b4d7) | reverse angle |
| V08b | media 9757acde (shine; job dac41a00) | |
| V09 | 2d1252c4 | |
| V12 | fdd4a2dd | use 3.0-8.0s |
| V14 | 4e012b19 | |
| V16 | fb324116 | |
| V18 | c520ffc8 | |
| V23 | media 7ed320ab (shine; job 8950b450) | reverse angle, Madame's chair empty |
| V24 | fa163ca8 | |
| V26 | edce2f2a | |
Shine-boosted (other characters): V05 3b78acca, V08 f1043dc8, V10 39c9769f, V11 f5f24bb3, V13 aaac03b7, V22fix 8e78b842, V25 32affb86.

## 2026-10-20 07:50 canonical picks for the rest (verified from thread history)
- V04 replaced again: Kling job b1188ae5 (reverse angle, keeps the dive-under-the-table gag), shine-boosted in edit.
- V15 media f049cecd (glow boosted, ends at 6.4s on the Telfar bag). V17 media 845bad34 (products rise from bag, replaces 3eba4104).
- V19 media 732fe221, V20 media 63383e6f (both mirrored in edit). V21 Kling ea7f6990 + 2s hold media 8e2a0d48.
- Edit order: V15 -> V17 -> V16 -> V18. V13: 75% slow-mo then vial close-up for "However...".
