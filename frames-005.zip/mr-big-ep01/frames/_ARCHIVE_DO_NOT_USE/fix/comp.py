import sys
from PIL import Image,ImageEnhance,ImageFilter
P='/mnt/project-files/mr-big-ep01/products/'
def paste(base,prod,cx,bottom,height,bright=0.93):
  c=Image.open(P+prod+'.png').convert('RGBA');c=c.crop(c.split()[3].getbbox())
  wdt=round(c.width*height/c.height);c=c.resize((wdt,height),Image.LANCZOS)
  rgb=ImageEnhance.Brightness(c.convert('RGB')).enhance(bright);a=c.split()[3].filter(ImageFilter.GaussianBlur(0.7))
  c=Image.merge('RGBA',(*rgb.split(),a))
  base.paste(c,(round(cx-wdt/2),bottom-height),c);return base
