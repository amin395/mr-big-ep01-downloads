import json,re,sys
R={x['idx']:x for x in json.load(open('reqs.json'))}
for x in json.load(open('later.json')): R[x['idx']]=x
for x in json.load(open('b9.json')):
    if x['index']==925:
        p=x['params']['prompt'].replace('; 6) FRAMING reference only: match its camera distance, lens and composition; do NOT copy that person, room or outfit','')
        R[925]={'idx':925,'prompt':p,'medias':[m['value'] for m in x['params']['medias'] if not m['value'].startswith('c87ec774')]}
for i,pl in ((921,'b02188e4-4ca4-44bf-9fb1-9541112c62ea'),(924,'a5322263-4ca4-4466-a3a5-28aeaa9a4d88')):
    R[i]=dict(R[i]); R[i]['medias']=list(R[i]['medias'])+[pl]; R[i]['prompt']=R[i]['prompt'].rstrip('.')+'; 5) set plate (match the room and light exactly).'
J=dict((int(a),b) for a,b in (l.split() for l in open('jobs.tsv')))
try: NEW=dict((int(a),b) for a,b in (l.split() for l in open('jobs_fix.tsv')))
except FileNotFoundError: NEW={}
UNS='8742f819-5a53-429b-99c7-8ad4360685b0'; LEM='ae432abc-4492-4475-84a3-c50898313faa'; ELX='2197ea71-bfcf-48e6-ab74-42189e400f68'; OIL='79efd9ff-f3d4-409b-b9cb-88af6e75066a'
TENTM='92606940-c74a-444e-b449-0ffbba958331'; TABLE='9081db73-3078-458a-a6b2-3f534c07f6f0'
SIMWED='88f60a8b-f74b-4375-a2cd-35f776aeb6f3'; ZOEWED='a098b1c0-a01b-4457-9f80-5ec839508ebd'; KEN14='1c7ae686-4611-4ef6-834d-cd076714f711'
ZOEHOME='95a6ad2f-0281-4cef-ab4e-17b135b3ad94'; GIFT='affcb8c5-6878-4466-a950-56dfb5237a47'
LOGIC=(" PHYSICAL LOGIC: true human scale, feet on the floor or seated; nobody on furniture; two arms and two hands each; no duplicate people; in cars everyone faces the windshield. MIRRORS: one mirror, one sink; reflections match real positions; never a second mirror or sink behind anyone.")
STUDIO=(J[250],"ANCHOR FRAME (shot 25): this is the SAME studio; match its walls, mirror stations, pendant light, chairs, rug, furniture, colors and light exactly")
WED=lambda: (NEW[10],"ANCHOR FRAME (new shot 1 wide): the SAME wedding set, riser layout, family, outfits and light; match exactly")
SIMGUEST=" SIMONE (Kenya's best friend, 42, chin-length silk-press bob, emerald-green guest dress, radiant skin) is VISIBLE as a guest standing on the grass just beside the risers at frame-right, smiling and watching; she is NOT on the risers yet."
F={}
def fx(i,txt,refs=(),drop=(),swap=None,action=None,camera=None):F[i]=dict(txt=txt,refs=list(refs),drop=drop,swap=swap,action=action,camera=camera)
# ---- WAVE 1
fx(10,SIMGUEST,[(SIMWED,"Simone / wed look sheet (match face, hair and emerald dress)")])
fx(60,"",[(KEN14,"Kenya at 14 / grad look sheet (match face and pressed high ponytail exactly)")],action="Close on Ms. Dee (39, in her scrubs) standing in the audience aisle in the foreground, sharp, holding in her emotion, mouth closed; behind her, softly out of focus, the graduates in blue gowns stand on the stage with KENYA (14, cap and gown, pressed high ponytail, the reference girl) centered and smiling; a photographer stands IN FRONT of the stage facing the graduates and his camera flash fires toward them, lighting the graduates from the front.",camera="Close-up on Ms. Dee, shallow focus, the stage behind her.")
fx(140,"",[(J[110],"ANCHOR FRAME (shot 11): the SAME car interior, seats and dashboard; match exactly")],camera="From the passenger seat looking at Ms. Dee in a three-quarter front view: she sits in the DRIVER'S seat facing the windshield, both hands on the steering wheel in front of her, head slightly bowed, crying quietly; night outside.")
fx(160,"",[(J[150],"ANCHOR FRAME (shot 15): the SAME Kenya, same hair (high natural puff), same navy scrubs and badge, the SAME car interior (steering wheel, center screen, dashboard, seats) and parking-garage light; match exactly")],camera="Same camera side and distance as the anchor frame; she sits in the driver's seat facing forward, looking down at the phone in her hands.")
fx(170,"",[],camera="Kenya SITS on the vanity stool facing her vanity mirror; the camera is behind her right shoulder; we see the back of her head and shoulder in the foreground and her face in the mirror's reflection, matching her real position; the ring light stands beside the mirror; her bed is behind the camera, not in the reflection.")
fx(180,"",[],camera="She stands at the sink about an arm's length from the mirror; camera slightly behind her right shoulder; her reflection shows her face at the matching size and position; the counter holds only the sink and her small makeup bag; no jars.")
for i in (260,270,280,290,300):
    fx(i," HANDS: Ms. Faye's hands never touch Kenya's face, jaw or chin." if i==260 else "",[STUDIO])
fx(330,"",[],action="HAIR-TO-FACE, scientific 3D medical-animation look on a dark background: a Black woman's head and shoulders in three-quarter profile, deep brown skin, NATURAL coily hair styled up with the EDGES LAID: baby hairs brushed down and swirled with edge gel, curl cream visibly coating the coils, a glossy film of gel and cream on the hairline. The glossy film is creeping off the edges and hairline onto the forehead, the temple and the taper by the sideburn and behind the ear. Head alone, no skin cutaway, no cross-section under her.",camera="Locked three-quarter profile, soft rim light.")
fx(380,"",[(ZOEHOME,"Zoe look sheet: the avatar photo in the notification is THIS girl's face")],camera="Over Kenya's shoulder onto her phone: the notification bubble shows a tiny round avatar photo of ZOE (the reference girl, box braids, lavender hoodie) next to the text '@AuntKenya I did all 11 steps!'")
fx(420,"",[(J[410],"ANCHOR FRAME (shot 41): the SAME car interior, seats and dashboard; match exactly")],camera="Camera outside the windshield looking in, front three-quarter: Ms. Dee in the DRIVER'S seat (frame-left) facing forward through the windshield with both hands on the wheel; Zoe in the PASSENGER seat (frame-right) facing forward, looking down at her phone in her lap; each has two arms; night.")
fx(450,"",[],camera="Eye-level medium-wide; Amin stands on the exhibit-hall floor among attendees at normal adult height (his head at the same height as the other adults), booths and the 'NATURAL HAIR & BEAUTY SHOW' banner behind him at true scale.")
fx(460,"",[],camera="Eye-level medium; Amin stands ON THE FLOOR beside the campaign board on the wall, pinning a flyer at shoulder height; the desk with the laptop is in front of the board, he is NOT standing on it.")
fx(540,"",[(J[530],"ANCHOR FRAME (shot 53): the SAME yard, pots, mats and elder; match exactly")],camera="Close-up on the elder's face and shoulders, her face large in frame on the upper third, three-quarter front toward camera, mouth closed and relaxed, the paddle still in her hands below frame; the yard soft behind her.")
fx(580," SOAP COLOR: the African Black Soap wash pours as a rich BROWN liquid, the same brown as the black soap bars, onto the white cloth; never clear or white.",[STUDIO])
fx(610,"",[STUDIO,(J[600],"ANCHOR FRAME (shot 60): the SAME sinks and studio corner")],camera="Soft close-up on Ms. Dee's face, three-quarter front, at the LEFT sink, mouth closed, eyes on Kenya, holding the white washcloth; Kenya's shoulder and profile soft at the frame edge.")
fx(710,"",[],action="DIAGRAM, START FRAME: scientific 3D skin cross-section like the other diagrams (same layers, hair shafts, colors). The Elixir has just been spread on by hand: a thin, even, golden oil layer COATS THE WHOLE skin surface from edge to edge, beginning to sink into the very top layer only.",camera="Locked side cross-section, identical to the other diagrams.")
fx(740,"",[(LEM,"real YO African Black Soap LEMONGRASS wash bottle"),(ELX,"real YO SUPA GLO Facial Elixir bottle"),(OIL,"real YO SUPA GLO Body Oil bottle")],drop=('unlabeled','plain bottles','no labels'),action="Black seeds crack open and turn into golden oil that splits into three streams pouring into the three REAL YO bottles standing side by side, caps off: the Lemongrass African Black Soap wash, the SUPA GLO Facial Elixir and the SUPA GLO Body Oil, each exactly as in the attached product photos (labels, colors, caps) and at their true relative sizes (the Elixir is the small 2 oz bottle).",camera="Product hero, warm studio backdrop.")
fx(850," TOP LAYER: the thin oil seal on the surface carries a soft, healthy sheen and gentle glow on the top layer (smooth, never wet-looking).",[])
fx(860,"",[(OIL,"real YO SUPA GLO Body Oil bottle")],camera="ONE Kenya only: she stands at her bathroom counter in her white robe, the garment bag open on the door; she holds the white wedding dress against her body and looks into the single mirror; the mirror shows exactly one reflection of her; the YO Body Oil bottle (the only product in view) stands on the counter.")
fx(900,"",[(UNS,"real YO African Black Soap UNSCENTED wash bottle (Simone's product)"),(ELX,"real YO SUPA GLO Facial Elixir bottle"),(OIL,"real YO SUPA GLO Body Oil bottle")],drop=(LEM,),action="Night 1: Simone, still in her work clothes and full makeup, finds the YO gift bag on her bathroom counter with a small card reading 'K'; she has lifted out the three products and stands them upright in a neat row on the counter: the UNSCENTED African Black Soap wash, the SUPA GLO Facial Elixir and the SUPA GLO Body Oil, each exactly as in the attached photos.")
fx(910,"",[(UNS,"real YO African Black Soap UNSCENTED wash bottle")],drop=(LEM,),action="Same moment: Simone, at her sink, pours the brown UNSCENTED African Black Soap wash from the real bottle in her RIGHT hand onto a white washcloth held in her LEFT hand; only her own two hands in frame.",camera="Front three-quarter view from the end of the counter, her face and both hands visible; the mirror beside her shows her matching reflection.")
MIR="COMPOSITION LOCK (copy the attached anchor composition exactly): we look straight into her bathroom mirror; her reflection is centered, head and shoulders; only the edge of her real shoulder shows at the frame edge; the three bottles stand on the counter in front of the mirror in the lower foreground; the mirror shows only the room BEHIND her (wall, door, towel), never another mirror, sink or counter."
fx(921,"",[(J[924],"COMPOSITION ANCHOR (Simone's portrait): copy its camera position, framing and mirror geometry; NOT the person or room")],camera=MIR)
fx(925,"",[(J[924],"COMPOSITION ANCHOR (Simone's portrait): copy its camera position, framing and mirror geometry; NOT the person or room")],camera=MIR)
fx(924,"",[(J[924],"ANCHOR FRAME: the SAME image of Simone; reproduce it exactly"),(UNS,"real YO African Black Soap UNSCENTED wash bottle")],drop=(LEM,),camera=MIR+" The soap bottle is the UNSCENTED African Black Soap wash.")
fx(950,"",[],action="After Day 30: Simone, bare-faced and radiant, STANDS ON THE FLOOR at the head of the boardroom table presenting with calm confidence; SIX board members (men and women, Black and other backgrounds, business attire) sit around the table watching her, one woman leaning to a colleague in quiet admiration.",camera="Medium-wide from the far end of the table, eye level.")
fx(960,"",[(J[410],"ANCHOR FRAME (shot 41): the SAME car interior; match exactly")],camera="From the passenger seat: Ms. Dee sits in the DRIVER'S seat facing forward, fully visible in her wedding outfit; the rearview mirror is mounted high at the top center of the windshield and shows her smiling eyes; she glances up into it.")
TENT=" BOOTH: the booth must be the REAL YO tent exactly as in the attached tent mockup (canopy pattern, roof logo, yellow valance, the printed BACK WALL panel, side walls) and the table wears the real YO table cover exactly as in the attached table-cover mockup; no other tent or table design."
fx(1060,TENT,[(TENTM,"REAL YO tent mockup (match exactly)"),(TABLE,"REAL YO table cover mockup (match exactly)")],camera="Medium two-shot from a slight three-quarter angle so the festival crowd and other tents show softly in the background; both founders' mouths CLOSED with gentle closed-lip smiles; Kimmy faces camera.")
# ---- WAVE 2
for i in (30,130,970,990): fx(i,SIMGUEST if i!=130 else SIMGUEST,[WED(),(SIMWED,"Simone / wed look sheet")] if NEW.get(10) else [])
fx(1020,SIMGUEST+" KENYA wears her elegant updo with small white flowers exactly as in the anchor. ZOE is 14 (a teenager, as tall as Kenya's shoulder), in the reference look, not a small child.",[WED(),(SIMWED,"Simone / wed look sheet"),(ZOEWED,"Zoe / wed look sheet (14 years old)")] if NEW.get(10) else [])
fx(1040,"",[WED(),(SIMWED,"Simone / wed look sheet")] if NEW.get(10) else [],action="WIDE on the WHOLE family on the risers exactly as in the anchor (Kenya center front with Ms. Dee beside her, Marcus, Zoe in front, the family and groomsmen behind); Kenya turns and waves her best friend in; Simone, glowing in emerald, steps up onto the empty far-right end of the back riser into the family photo, everyone laughing.",camera="Wide, same camera position as the anchor.")
fx(200,"",[(NEW.get(180),"ANCHOR FRAME (shot 18): SAME restroom, same mirror, same camera position and distance, same counter (no jars); match exactly")] if NEW.get(180) else [],camera="Identical framing to the anchor frame.")
fx(210,"",[(NEW.get(170),"ANCHOR FRAME (shot 17): SAME vanity, same camera position, same Kenya hair and outfit; match exactly")] if NEW.get(170) else [],camera="Identical camera and mirror geometry to the anchor frame; the bottles are on the vanity in front of the mirror.")
fx(711,"",[(NEW.get(710),"ANCHOR FRAME: the start frame of this diagram; same cross-section and camera")] if NEW.get(710) else [],action="DIAGRAM, END FRAME: the same cross-section; the golden Elixir layer has fully absorbed into the top layer of skin, nothing sits on top, and the surface glows softly and evenly.",camera="Locked, identical to the anchor.")
for i,a in ((931,921),(941,921),(932,925),(942,925),(934,924),(944,924)):
    fx(i,"",[(NEW.get(a),"ANCHOR FRAME (Day 1 of this same shot): identical camera, framing, room, outfit, hair and bottles; only the skin changes")] if NEW.get(a) else [],drop=(LEM,) if a==924 else (),camera=MIR)
F[941]['txt']=" GLOW: soft, even, satin glow from within; NOT shiny, no highlights on the forehead or cheeks."
for i in (934,944): F[i]['refs'].append((UNS,"real YO African Black Soap UNSCENTED wash bottle"))
fx(1070,TENT,[(NEW.get(1060),"ANCHOR FRAME (shot 106): same booth, same founders, same light")] if NEW.get(1060) else [],camera="Medium close on Amin (chest up), Kimmy beside him partly in frame, the real YO tent behind them, festival crowd soft in the background; mouths closed.")
WAVE1=[10,60,140,160,170,180,260,270,280,290,300,330,380,420,450,460,540,580,610,710,740,850,860,900,910,921,924,925,950,960,1060]
WAVE2=[30,130,970,990,1020,1040,200,210,711,931,941,932,942,934,944,1070]
def build(i):
    f=F[i]; base=R[710 if i==711 else i]
    p=base['prompt']; meds=list(base['medias'])
    if i in (900,910,924,934,944):
        meds=[UNS if m==LEM else m for m in meds]
        p=p.replace('soap-lemongrass_front.png','soap-unscented_front.png (the UNSCENTED wash)')
    if i==740:
        p=re.sub(r"Lettering and products: NONE in this shot\..*?plain and unlabeled\.","Lettering: ONLY the real YO labels on the attached product photos.",p,flags=re.S)
        p=p.replace("No text, no labels, no arrows.","No text other than the real labels, no arrows.")
    if f['action']: p=re.sub(r'ACTION: .*? CAMERA:', lambda m:'ACTION: '+f['action']+' CAMERA:', p, count=1, flags=re.S)
    if f['camera']: p=re.sub(r'CAMERA: .*?(?= Keep every face| START FRAME| No text)', lambda m:'CAMERA: '+f['camera'].rstrip('.')+'.', p, count=1, flags=re.S)
    if 'ATTACHED REFERENCES:' not in p: p=p.rstrip('.')+'. ATTACHED REFERENCES:'
    p=p.replace(' ATTACHED REFERENCES:', f['txt']+LOGIC+' ATTACHED REFERENCES:',1)
    extra=[(v,t) for v,t in f['refs'] if v and v not in meds]
    n=len(meds)
    add=''.join(f"{'' if (n==0 and k==0) else ';'} {n+1+k}) {t}" for k,(v,t) in enumerate(extra))
    p=p.rstrip('.')+add+'.'
    meds+=[v for v,t in extra]
    return {'index':i,'params':{'model':'nano_banana_2','aspect_ratio':'9:16','resolution':'1k','prompt':p,'medias':[{'value':m,'role':'image_references'} for m in meds[:14]]}}
if __name__=='__main__':
    w=sys.argv[1]; L=WAVE1 if w=='1' else WAVE2
    out=[build(i) for i in L]; json.dump(out,open(f'fix_w{w}.json','w'))
    for o in out: print(o['index'],len(o['params']['medias']),len(o['params']['prompt']))
