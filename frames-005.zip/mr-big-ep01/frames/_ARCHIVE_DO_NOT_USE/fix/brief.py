import json,re,sys
d={r['index']:r for r in json.load(open(sys.argv[1]))}
for i in map(int,sys.argv[2:]):
  p=d[i]['params']['prompt']
  st=re.search(r'SETTING \((.*?)\)',p); 
  ppl=re.search(r'PEOPLE IN FRAME:(.*?)\.',p)
  pos=re.findall(r'POSITION: ([^.]*)\.',p)
  lett=re.search(r'Lettering and products:(.*?)SETTING',p,re.S)
  act=re.search(r'ACTION:(.*?)Keep every face',p,re.S)
  extra=re.search(r'never white patches, white spots or blown-out highlights\.(.*?)PHYSICAL LOGIC',p,re.S)
  ref=re.search(r'ATTACHED REFERENCES:(.*)',p,re.S)
  print('##',i,'|',st and st.group(1),'|',ppl and ppl.group(1).strip(),'|POS',pos)
  print('LET:',lett and lett.group(1).strip()[:400])
  print('ACT:',act and act.group(1).strip())
  print('EXTRA:',extra and extra.group(1).strip()[:600])
  print('REF:',ref and ref.group(1).strip()[:700])
  print('MED:',[m['value'][:8] for m in d[i]['params']['medias']]);print()
