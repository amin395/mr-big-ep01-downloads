APPROVED START FRAMES ONLY (Amin-approved stills page + founders 1084). One file per shot. Video renders use ONLY these files.
Not in folder by design: shot 62 (continues from last frame of shot 61 video), 76/87/88/89/103/105/108/109 (edit graphics, no AI frame).
s106 and s107 = the approved founders picture 1084.
