# Video sync rule (Amin 11-15 12:21): picture cuts exactly to the locked audio. Talking shots cut 0.10 s after their last sound;
# the following shot comes in right there (end of statement). A gap over 1.0 s after a talking shot becomes a continuation shot
# generated from the lip-sync clip's last frame, with no mouth movement.
import json, re, os, copy, numpy as np, soundfile as sf
M=json.load(open('/mnt/project-files/mr-big-ep01/mix-v18/map-v18.json')); V=dict(zip(M['voxid'],M['vox']))
L='/mnt/project-files/mr-big-ep01/engine-v18/clean18/lines/'
_C={}
def segs(line):
    if line in _C: return _C[line]
    if not os.path.exists(L+line+'.wav'): _C[line]=[tuple(V[line])]; return _C[line]
    d,sr=sf.read(L+line+'.wav'); d=d if d.ndim==1 else d.mean(1)
    h=int(sr*0.005); e=np.array([np.sqrt(np.mean(d[i:i+h]**2)) for i in range(0,len(d)-h,h)]); db=20*np.log10(e+1e-9)
    act=db>db.max()-38; out=[]; s=None
    for i,a in enumerate(act):
        if a and s is None: s=i
        if not a and s is not None: out.append([s*0.005,i*0.005]); s=None
    if s is not None: out.append([s*0.005,len(act)*0.005])
    m=[]
    for a,b in out:
        if m and a-m[-1][1]<0.15: m[-1][1]=b
        else: m.append([a,b])
    _C[line]=[(V[line][0]+a, V[line][0]+b) for a,b in m if b-a>0.04]; return _C[line]
def ids(sh): return [x for x in re.findall(r'[A-Z][A-Z0-9]+[a-z]?',sh.get('line') or '') if x in V]
OUT_PAD=0.10; MAX_PULL=1.0
def apply(SH, log):
    SH.sort(key=lambda s:(s['t'],1 if s.get('par') else 0, s['orig']))
    add=[]
    main=[s for s in SH if not s.get('par')]
    for s in main:   # IN: a talking shot never starts after its first sound
        if s['model']!='SL': continue
        sp=[g for i in ids(s) for g in segs(i) if abs(g[0]-s['t'])<0.3]
        if sp:
            f=min(g[0] for g in sp)
            if f < s['t']-0.005: log.append(f"{s.get('line')}: cut moved {s['t']-f:.3f} s earlier to the first sound ({f:.3f})"); s['t']=round(f,3)
    for k,s in enumerate(main):
        if s['model']!='SL' or k+1>=len(main): continue
        nx=main[k+1]; t0,t1=s['t'],nx['t']
        sp=[g for i in ids(s) for g in segs(i) if g[1]>t0 and g[0]<t1]
        if not sp: continue
        last=max(g[1] for g in sp); out=round(last+OUT_PAD,3); gap=round(t1-out,3)
        if gap<=0.05: continue
        if gap<=MAX_PULL:
            log.append(f"{s.get('line')}: cut moved {gap:.2f} s earlier to {out:.3f} (0.10 s after the last word); the next shot comes in there")
            nx['t']=out
        else:
            c=copy.deepcopy(s); c.update(model='S', line=None, spk='', orig=s['orig']+0.05, t=out,
                audio="(no speech from this character; music/other voice continues)",
                action="CONTINUES the previous shot from its last frame (start frame = final frame of the lip-sync clip), so the cut is invisible: "+s['action']+" Nobody on camera speaks here: the speaker's mouth stays closed or her face is turned from camera.")
            c['motion']=c['action']; add.append(c)
            log.append(f"{s.get('line')}: talking part ends at {out:.3f}; the remaining {gap:.2f} s becomes a continuation shot made from the lip-sync clip's last frame (no mouth movement)")
    SH.extend(add); SH.sort(key=lambda s:(s['t'],1 if s.get('par') else 0, s['orig']))
    return SH
