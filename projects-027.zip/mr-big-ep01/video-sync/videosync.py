# VIDEO SYNC CHECK: every lip-sync shot's IN lands on the first sound of its line, its OUT 0.05-0.15 s after the last sound.
import json, re, numpy as np, soundfile as sf
M=json.load(open('/mnt/project-files/mr-big-ep01/mix-v18/map-v18.json')); V=dict(zip(M['voxid'],M['vox']))
L='/mnt/project-files/mr-big-ep01/engine-v18/clean18/lines/'
B=json.load(open('book.json')); SH=B['shots']
import os
def segs(line):
    if not os.path.exists(L+line+'.wav'): return [tuple(V[line])]   # ETB/AT2: map span = trimmed sound edges
    d,sr=sf.read(L+line+'.wav'); d=d if d.ndim==1 else d.mean(1)
    h=int(sr*0.005); e=np.array([np.sqrt(np.mean(d[i:i+h]**2)) for i in range(0,len(d)-h,h)]); db=20*np.log10(e+1e-9)
    act=db>db.max()-38; out=[]; s=None
    for i,a in enumerate(act):
        if a and s is None: s=i
        if not a and s is not None: out.append([s*0.005,i*0.005]); s=None
    if s is not None: out.append([s*0.005,len(act)*0.005])
    m=[]
    for a,b in out:
        if m and a-m[-1][1]<0.15: m[-1][1]=b
        else: m.append([a,b])
    m=[x for x in m if x[1]-x[0]>0.04]
    return [(V[line][0]+a, V[line][0]+b) for a,b in m]
rows=[]; fails=0
main=[x for x in SH if not x.get('par')]; prevout={main[k+1]['t']:main[k] for k in range(len(main)-1)}
for s in SH:
    if s['model']!='SL': continue
    ids=[x for x in re.findall(r'[A-Z][A-Z0-9]+[a-z]?',s.get('line') or '') if x in V]
    t0,t1=s['t'],round(s['t']+s['dur'],3)
    sp=[g for i in ids for g in segs(i) if g[1]>t0-0.3 and g[0]<t1+0.3]
    inside=[g for g in sp if g[0]<t1 and g[1]>t0]
    first=min(g[0] for g in inside); last=max(g[1] for g in inside)
    spill=[g for g in sp if g[0]<t1-0.005<g[1]]   # a sound still going at the cut
    pre=[g for g in sp if g[0]<t0-0.005<g[1]]
    din=round(first-t0,3); dout=round(t1-last,3)
    pv=prevout.get(t0); boundary = pv is not None and pv['model']=='SL'   # comes in right after the previous speaker's statement (listening lead)
    ok_in = (-0.05<=din<=0.12 or (boundary and 0<=din<=1.0)) and not pre
    ok_out= 0.0<=dout<=0.2 and not spill
    st='PASS' if ok_in and ok_out else 'FAIL'; fails+= st=='FAIL'
    rows.append(dict(n=s['n'],line=s.get('line'),t_in=t0,t_out=t1,first=round(first,3),last=round(last,3),in_gap=din,out_gap=dout,spill=bool(spill),status=st))
    print(f"{st}{' (listening lead after prev statement)' if boundary and din>0.12 else ''} #{s['n']:<3} {s.get('line')[:28]:28} in {t0:8.3f} first {first:8.3f} ({din:+.3f})   out {t1:8.3f} last {last:8.3f} (+{dout:.3f}){'  SPILL' if spill else ''}")
print('fails',fails); json.dump(rows,open('videosync.json','w'),indent=1)
