# Forever Pictures v5: the problem, the cause, the answer

**Goal:** one film that shows what Black women have been doing to their skin because the right products were never made for them, why it backfires, and how YO answers it head to toe, with 3D science shots that make each point clear. **Done:** the full story is below, plus the evidence chain, the diagrams and the compliance line.

## What's new in this version (your notes)

1. **Ms. Dee shines from work, not from grease on her face.** She comes off a double shift still sweating, and the grease holding her edges melts down with the sweat.
2. **The niece copies Kenya.** Jordan, 16, films the same 11-step videos and lays her edges the same way. That raises the stakes for the next generation.
3. **Edge control is a named problem.** Waxes and oils move from the hair onto the hairline and forehead, and dermatologists say that causes bumps, irritation and, on our skin, dark marks.
4. **The answer has two steps.** First wash it off: the Triple-Action Cleanse cleanses deep, exfoliates and tones. Then replenish: the 10-oil Elixir for the face and the Body Oil head to toe, with each ingredient's job.
5. **Trust comes from the founders.** Amin has 15 years in Black beauty and Kimmy grew up in her mother's esthetics room. They are why this works.
6. **Eight 3D science shots** illustrate each problem and each answer.
7. **A compliance section** shows exactly how far we can push the claims.

## The problem chain, backed by research

Here is what's happening to Black women's skin and why, one link at a time. Each link is a scene in the film.

1. **We were never served.** Black consumers are 3x more likely than non-Black consumers to be unhappy with their options for hair, skin and makeup. 72% say there's a gap. *(McKinsey 2022; NielsenIQ 2022)*
2. **So we made do with what was there.** Black women use more hair products than any other group, and body butters about 4 days a week. *(Taking Stock Study 2021; CAPABLE 2023)*
3. **Hair products don't stay on the hair.** Dermatologists found hair product residue stays on the forehead and cheeks for hours, and the amount increases over time. "It is almost impossible to use a hair care product without it getting on the skin." *(Practical Dermatology, Dr. Iris Rubin; J Drugs Dermatol 2020)*
4. **On the hairline, that means bumps.** The AAD says the oils in hair care products, including styling gels and waxes, can cause tiny bumps along the hairline and forehead. "Pomade acne" is frequently seen in Black skin, looks purple-brown on darker skin and can leave dark marks. *(AAD; Atlas of Black Skin, Springer 2020)*
5. **Dark marks are the #1 face worry.** Uneven tone and hyperpigmentation top Black women's facial concerns, and dark marks after irritation hit darker skin more often and harder. *(MOSAIC 2026; JCAD)*
6. **Then we cover the marks.** Foundation goes on top, often a shade that took "six or seven" tries to find, worn 10 hours a day, sometimes slept in. Dermatologists say makeup can cause breakouts of its own and should come off before bed. *(McKinsey; AAD)*
7. **Our work makes us sweat through it.** Black women are about 1 in 4 nursing aides and practical nurses and 1 in 10 RNs. 62% of healthcare workers had skin problems from masks and PPE, nurses worst of all, with sweating a top complaint. *(Health Affairs 2022; PMC9792000)*
8. **And now the phone adds more layers.** Glass skin calls for 7 to 11 products. 95% of the top viral glass-skin videos had misleading claims, 84% ignored skin type, and dermatologists warn that too many products lead to irritation and breakouts. About 80% of Gen Z women trust creators most. *(EADV 2026; AAD; LTK 2023)*
9. **Our skin is oily on top and thirsty underneath.** Black skin has the highest sebum of any group but the lowest ceramides, so it loses water faster and goes ashy. Layers on top don't fix what's underneath. *(Dermatology News)*

**What it adds up to:** layers on top, nothing that truly washes them off, and nothing light that feeds the skin underneath. That is the cycle YO breaks.

## The answer: the YO routine

**Step 1. Wash it off: Triple-Action African Black Soap, face and body wash ($9.99).**
- Three actions: it cleanses deep, exfoliates and tones.
- It washes off the day's sweat, makeup and edge-gel residue, "without leaving skin feeling stripped" (from the label).
- It's made from the plantain-skin and cocoa-pod ash that gives true African black soap its gentle exfoliating texture.
- The trio is what makes it different from plain black soap:
  - **sea moss**, a mineral-rich cushion of moisture;
  - **Ethiopian black seed**, antioxidant-rich;
  - **jojoba**, a liquid wax close to what your skin makes.

**Step 2. Replenish the face: Supa Glo 10-Oil Facial Elixir ($15.99).**
- Two drops, lightweight, fast-absorbing.
- **Rosehip**, rich in essential fatty acids, to smooth the look of skin.
- **Turmeric**, the golden root, for brightness.
- **Argan** and **almond**, naturally rich in vitamin E.
- **Calendula**, the soothing flower.
- **Grapeseed**, light as air.
- **Jojoba** and **black seed**.
- **Copaiba**, the rare one from the Amazon.
- "Helps fade the look of dark marks" (site claim).

**Step 3. Replenish the body: Supa Glo 7-Oil Body Oil ($13.99).**
- Head to toe.
- Absorbs fast, with a light finish that won't stick to your clothes.
- "Visibly reduces the look of ashiness" (site claim).

**All three: the Complete Routine, $37.97.** Twenty plant ingredients, totally plant-based, mixed, filled and bottled in the USA.

## The story from A to Z

A three-and-a-half-minute animated film, Pixar-quality 3D, told by Ms. Faye, a makeup artist with 25 years doing Black brides' faces, in short warm rhymes over your YO songs.

### Scene 1. The photo she keeps walking out of

**What happens.** A wedding. "Family of the bride!" Everyone crowds in, except the bride's mother. Ms. Dee, 56, slides out of the frame: "Take it without me, baby."

Flashback to June 2009. Ms. Dee, 39, a nursing aide, rushes straight from a double shift to her daughter's eighth-grade graduation, still in scrubs. It's hot and she's still sweating from the shift. The grease holding her edges down melts with the sweat and runs onto her forehead, and her face shines under the gym lights. Kenya, 14, embarrassed in front of her friends, tugs her sleeve: "Mama, can you stand in the back?" Ms. Dee does, and she has stood in the back of every picture since.

**What you feel.** A gut punch. Every mother who has felt like an embarrassment to her child feels it, and every daughter who once said something careless. You need to see this mother get her picture back.

**The value.** This is what skin costs a family: pictures, pride, a mother's place in the frame. It's also real life: a working Black woman with no time, sweating through her day, using what was available.

**Science shot D1, sweat and grease.** A 3D cross-section of Ms. Dee's forehead. Sweat rises out of the pores and mixes with the melted hair grease sliding down from the hairline, forming a slick surface layer that throws back the light.

### Scene 2. The daughter who followed her, and the niece who follows her

**What happens.** Today. Kenya, 31, is an ICU nurse like her mother. In quick flashes of her 12-hour shift: mask on, mask off, sweat at her hairline. Ms. Faye: "She takes care of everybody. Every body but her own."

That night, at her ring light, Kenya films a get-ready-with-me video for the wedding. Eleven bottles. "Step seven, y'all, seal it in." "Glass skin goals!" About $600.

Then her niece Jordan, 16, in her bedroom, plays Kenya's video on her phone and copies it step for step. She lays her edges with a thick swipe of edge control and stacks the same bottles. Kenya has no idea.

The low point is Kenya alone in her car in the hospital garage. Mask lines in her cheeks, tiny bumps along her hairline she keeps covering, and her foundation gone. She wipes it off her phone screen. "I did everything they said."

**What you feel.** Recognition, then worry. Every woman who works on her feet knows that car. Seeing the 16-year-old copy her adds fear: it's being passed down again.

**The value.** It names the modern problem. The phone sells more steps and more layers, and they don't survive a real Black woman's real day. The next generation is learning it right now.

**Science shot D2, the mask shift.** A cross-section under a mask. Heat and sweat build up, foundation pigment slides on the slick and rubs off where the mask presses.

### Scene 3. Ms. Faye's chair: three women, one problem

**What happens.** Wedding morning. Ms. Faye works three women in a row.

**Kenya.** The foundation slides right off. "But my skin's healthy, look at the glow!" Ms. Faye: "Baby, that ain't glow. That's layers." Then she lifts Kenya's edges and sees the little bumps. "And these? You been covering these for how long?"

**Simone, 42, maid of honor, a bank VP.** "Full face, ten hours a day. Seven tries to find my shade, and it's gone by two." "And at night?" Quietly: "I sleep in it more than I'd admit."

**Jordan, 16**, who's been asking to do her makeup "just like Auntie's." Ms. Faye runs a finger along her hairline and holds it to the light: a shiny film of edge gel. "What you put on your hair don't stay on your hair."

The groom walks by stacking beard oil. His groomsman: "Bro. Your ankles." Ashy.

Then the line of the film. Ms. Faye holds up the 2009 photo of Ms. Dee: "Your mama called it grease. Your phone calls it glass. Baby, it's the same layers."

**What you feel.** Laughter and being caught: "that's me." Under it, the click: mother and daughter were doing the same thing a generation apart, and the niece is next.

**The value.** The truth comes out. The problem isn't her skin; it's what's piled on it, from sweat, hair products, makeup and trendy routines, at every age.

**Science shot D3, edge control.** A macro of the hairline. Waxy, oily residue creeps from the hair onto the skin, settles into the openings of the pores, and small raised bumps form beneath. On deep brown skin, they leave darker marks behind.

**Science shot D4, eleven layers.** Eleven translucent films stacked on the skin like glass, flash bouncing off the top, while underneath, moisture quietly escapes from the skin. Greasy on top, thirsty underneath.

### Scene 4. It ain't your fault

**What happens.** Kenya, hurt: "So my mama was wrong, and I'm wrong too?" Ms. Faye sets her brush down.

"No, baby. Nobody made it for us. Not for our skin, not for our shifts, not for our sweat. So our mamas made do. Grease was making do. And them videos? Most of them never even asked what kind of skin you got."

On screen: 84% of top viral glass-skin videos didn't account for skin type.

"You ain't doing too little. You doing too much of the wrong thing. And you never had the right thing to wash it off."

**What you feel.** Relief. Shame becomes understanding, and nobody is the villain.

**The value.** The emotional key. It says what Black women have lived through: no right products, so they improvised. And it sets up the answer: it starts with the wash.

### Scene 5. Who finally made it for us

**What happens.** Ms. Faye sets down the YO Triple-Action Cleanse. Kenya: "Black soap? Mama's bars dried us out." "Not all black soap is the same. I asked the people who make this one."

Flashback to the YO tent. Amin: "Fifteen years in this business, I watched them sell us more steps, smaller bottles, and labels nobody reads. Hair products that never thought about our skin. So I went and got it myself." Kimmy: "I grew up in my mother's esthetics room. She's a master esthetician. Every woman who sat in her chair, she washed first. Then she fed the skin. That's how we built this."

**What you feel.** Trust and pride. These are insiders who know the business and the skin.

**The value.** It answers "nobody made it for us" with "these two did." It also states the method in one line: wash first, then feed the skin. That's the whole YO routine, credited to an esthetician's chair.

### Scene 6. Back to the source

**What happens.** First Ghana. In a village soap yard, plantain skins and cocoa pods burn slowly to ash while an elder stirs a big iron pot for hours. She presses a warm ball of soap into Amin's hand: "You want it fast, or you want it right?" Cut to Kenya's eleven bottles. Then the elder washes her granddaughter's face: "My grandmother washed me with this. I washed her mother."

Then Ethiopia, in misty highland fields. A farmer pours black seed into Amin's palm: "Tikur azmud." It has been treasured for thousands of years and was even found in King Tut's tomb. It's pressed into dark gold oil, antioxidant-rich, and it's in all three YO bottles.

Back in the chair, Ms. Faye counts off the YO trio: "Sea moss, a mineral-rich cushion, so you rinse soft, not tight. Black seed, antioxidant-rich, so skin feels smooth and nourished even while you wash. Jojoba, a liquid wax close to what your own skin makes, so the lather has slip and rinses clean."

Kenya washes a patch on her hand, waiting for the tight, squeaky feeling. It doesn't come. "Huh."

**What you feel.** Wonder at where it comes from, then a small, satisfying surprise.

**The value.** Real origin and real quality. The three ingredients are what make this black soap different from the bars that dried her out, and the biggest objection is answered on her hand.

**Science shot D5, triple action.** A cross-section with YO lather spreading across the surface:
- it lifts the stacked layers, sweat, makeup and edge-gel residue, and carries them away;
- fine particles roll away dull surface cells (exfoliate);
- the surface settles smooth and even (tone), with a soft cushion of moisture left behind (sea moss).
Clean, not stripped.

### Scene 7. The wash: the heart of the film

**What happens.** Ms. Dee has been listening in the doorway. She steps in and holds out her hand: "Let me." She washes her grown daughter's face on her wedding morning, gently along the hairline, where the edge gel sits. The film cuts between her hands and the elder in Ghana washing her granddaughter, in the same light with the same lather. Ms. Faye: "Same soap. Other side of the ocean." The music falls away to water and breath.

**What you feel.** The first big peak, a lump in your throat. The mother who was pushed to the back is now the one caring for her daughter.

**The value.** It shows what YO means: Your Original Skincare, a ritual handed down that connects Black women here to their roots. It's skincare as love.

### Scene 8. Replenish, head to toe

**What happens.** A quick, rhythmic montage.

**Feed the face.** Ms. Faye opens the Supa Glo Elixir: "Ten oils. Two drops." Each oil flashes up with its job: rosehip to smooth the look of skin, turmeric for brightness, argan and almond with their natural vitamin E, calendula to soothe, grapeseed light as air, jojoba and black seed. Then copaiba, golden resin from an Amazon tree. Amin: "I didn't fly to the Amazon for this one. I studied it till I knew exactly why it belonged." Ms. Faye: "Bet you never heard of it. That's the point." On screen: helps fade the look of dark marks.

**Glass versus glow.** The drops sink in while a slick of glass sits on top. "Glass sits on top. This absorbs." The brush glides and the makeup finally holds. "Now THAT'S a canvas."

**Feed the body.** Kenya smooths the Body Oil over her shoulders, and the white satin gown slides on. "Not a mark on that dress." Marcus's ankles get the same oil.

**It all comes home.** Ghana in the wash, Ethiopia in every bottle, a little Amazon in the glow, mixed, filled and bottled in America. "Twenty plant ingredients. Three bottles. Face to feet. Thirty-seven ninety-seven."

**What you feel.** Excitement and confidence. The white dress moment is real tension, then relief.

**The value.** The full answer. After washing the layers off, it puts back what skin needs:
- fatty acids, vitamin E and antioxidants from plant oils;
- light enough to absorb, so makeup holds and clothes stay clean;
- face and body, not face-only, for $37.97.

**Science shot D6, two drops.** Elixir droplets sink between the surface cells and spread underneath, while a glass-skin film beside them just sits on top.

**Science shot D7, the roll call.** One quick macro per oil (a rosehip, a turmeric root, an argan nut, a copaiba resin drop), each turning into a golden droplet that joins the others.

**Science shot D8, head to toe.** A translucent body in soft blue light, with a warm glow spreading from the face down to the feet as the Body Oil absorbs. On the shin, the dry, ashy surface smooths out.

### Scene 9. Thirty nights

**What happens.** The next thirty nights, one moment for each person.
- Kenya, after a 12-hour shift, washes once, presses in two drops, and she's done. She posts: "Y'all. I been doing too much." Then she sends the video to Jordan.
- Jordan watches it, puts eight bottles in a drawer, and washes along her hairline every night after laying her edges.
- Simone takes the day off her face every night: "Haven't slept in my face in a month."
- Ms. Dee, alone at her vanity, boxes up her old jars, washes, presses in two drops, and looks in the mirror longer than she has in years. "Her mama took the longest to believe. Thirty nights. Then she did."

**What you feel.** Warm hope, and Ms. Dee's private moment hits hardest.

**The value.** The routine fits real life: three steps, after a shift, at every age. The cycle is broken in front of the next generation, because Kenya teaches Jordan the right way.

### Scene 10. Get in the picture

**What happens.** The portrait. "Family of the bride!" Ms. Dee starts to slip out, and Kenya catches her hand: "Mama, I asked you to stand in the back once. Never again." Front and center, with Jordan right beside them. Flash. They glow, no glare. A guest: "Okay... what's the routine?"

Ms. Faye to camera: "It ain't your skin. It ain't your fault. It's what you stacked on it. Wash it off. Feed it right. Then get in the picture."

On black: For every woman who worked a double and still showed up for the picture.

The real photo of Amin and Kimmy at the real YO tent: the real founders, the real soap. End card: YO logo, Your Original Skincare, Complete Routine $37.97, five-star Google reviews, bottled in the USA, 45+ beauty supply stores. "Online, or at your beauty supply." "Glow Like Dat" plays out on "Keep yourself beautiful, don't gotta go broke for that."

**What you feel.** The second big peak, tears and joy. Three generations are in the picture.

**The value.** Skincare as being present in your family's memories. The real founders make it trustworthy, and the end card says what to buy, the price and where to get it.

## The feeling, start to finish

1. Gut punch (the photo).
2. Recognition and worry (the car, the niece).
3. Laughter (the chair).
4. Relief ("it ain't your fault").
5. Trust (the founders).
6. Wonder (the source).
7. **Tears (the wash).**
8. Excitement (head to toe).
9. Hope (the mirror).
10. **Tears and joy (the portrait).**

## Compliance: how far we can push

**What we CAN say, and how we say it.**
- **Problem claims about hair products and makeup, attributed and generic.** "Dermatologists say the oils in hair products can cause tiny bumps along your hairline" (AAD, near-verbatim). "Hair products don't stay on your hair" (Practical Dermatology). We never name a brand.
- **The study super:** "84% of top viral glass-skin videos didn't account for skin type," with an on-screen footnote to the EADV 2026 study.
- **Cleanse:**
  - "Triple action: cleanses deep, exfoliates, tones."
  - "Washes off sweat, makeup and edge-gel residue" (residue is surface buildup, which is on the label).
  - "Without leaving skin feeling stripped" (label).
- **Ingredient facts:** rosehip is rich in essential fatty acids; argan and almond are naturally rich in vitamin E; black seed is antioxidant-rich; jojoba is a liquid wax similar to skin's own oils. These describe the ingredients, not cures.
- **Site claims, used verbatim:** "helps fade the look of dark marks," "visibly reduces the look of ashiness," "absorbs fast," "won't stick to your clothes."
- **Brand facts:** totally plant-based, 20 plant ingredients, Black-owned, family-founded, bottled in the USA, five-star Google reviews, made in Ghana, Ethiopian black seed.

**Where the line is (we stay just behind it).**
- We SHOW bumps and dark marks as the problem, but never show YO clearing them, and never say YO treats, prevents or heals anything. That would make it a drug claim.
- The payoff is the habit (washing the hairline every night) and the confidence, not a before-and-after of bumps.
- No "non-comedogenic," "won't clog pores," "dermatologist-tested" or "best in the world." We don't have the tests for those.
- "Replenish nutrients" becomes "feeds skin fatty acids, vitamin E and antioxidants from plant oils." We leave out proteins, because the oils aren't a protein source.
- Ghana and Ethiopia are named as countries only, the village and farm are fictional, and no certificates appear on screen.
- The dress shot needs your simple satin test photo on file before it airs.

## What it takes

- **From you:** about 6 short voice lines, Kimmy on 2 (she okays the "master esthetician" line), the Unscented Cleanse photo, and the satin test photo.
- **Credits:**
  - character masters, 10 at about 20;
  - locations, about 40;
  - story shots, about 440;
  - lip-sync, about 55;
  - **science shots D1 to D8, about 100** (about 12 each);
  - buffer, about 85.
  - **Total about 740.** You have 175, which covers phases 1 and 2. Add about 570 before phase 3.
- **Time:** 5 to 7 days from your GO.

## Next

1. GO on phase 1: 10 character masters, about 20 credits.
2. Add credits before phase 3.
3. Kimmy okays her line, and you record yours.
