# Forever Pictures: the story, rebuilt on what's real

**Goal:** a story where every problem a woman sees on screen is something research shows Black women are living with right now, told the way your three reference ads tell theirs. **Done:** the story is rebuilt below. Every problem beat has a source, and YO answers it head to toe with plant-based ingredients and their origins.

## What changed, in one paragraph

I dropped the idea that Ms. Dee put grease on her face. Nothing I can find supports it. What the research does support is this: Black women use more hair products than any other group, and hair grease and edge products sit right on the forehead. Body butters get used more days per week than by any other group. Black women are about a quarter of the country's nursing aides and practical nurses, and 1 in 10 RNs, working long shifts on their feet in masks and sweat. Professional women wear foundation 10 hours a day, foundation that took them six or seven tries to match. The 18 to 30 crowd learns skincare from creators, and 95% of viral glass-skin videos contain misleading claims. Under all of it is one truth: for decades nobody made skincare for us, so we made do. That's the story now.

## The research: what's real (sources)

| What's real | The fact | Source |
|---|---|---|
| We're underserved | Black consumers are 3x more likely than non-Black consumers to be unhappy with their options for hair, skin and makeup, and 2.9x more likely than White consumers to be dissatisfied with skincare | McKinsey, "Black representation in the beauty industry" (2022 survey of 1,268 Black beauty consumers) |
| We say so ourselves | 72% of Black consumers agree there's a gap in beauty offerings for them; they look for natural products and care about ingredients | NielsenIQ, "Attracting Black beauty consumers in 2022" |
| Products weren't tested on us | Black chemists and founders told McKinsey active ingredients are tested on Caucasian or Asian skin "99 percent of the time" (an insider quote, not a measured statistic) | McKinsey 2022 |
| Few safer options | Fewer than 25% of personal care products marketed to Black women scored well on EWG's hazard ratings, vs 40% for the general market | EWG Skin Deep analysis of 1,100+ products (2016) |
| Few doctors who look like us | About 3% of US dermatologists are Black | JAAD workforce analysis, cited by BLAC Media |
| Hair products are our biggest category | Hair care is the #1 beauty category for Black consumers (~$2.29B a year). Black women use more hair products than other groups | NielsenIQ 2022; Taking Stock Study, J Expo Sci Environ Epidemiol 2021 (women 18 to 34) |
| Hair products land on the face | "Pomade acne," seen more often in Black patients, appears on the forehead and is tied to hair care and styling products | Acne in skin of color review, The Hospitalist / MDedge |
| Heavy on the body | Black women used body butters (shea, cocoa) about 4.1 days a week and hair oil or grease about 2.6 days a week, more than any other group studied | CAPABLE study, J Expo Sci Environ Epidemiol 2023 (n=70 Black women) |
| Oily face, ashy legs, both real | Black skin has the highest sebum of any group but the lowest ceramides, so it's the most prone to water loss and dryness ("ashiness") | Dr. Naissan Wesley, Dermatology News / MDedge |
| Dark marks are the #1 face worry | Uneven tone and hyperpigmentation rank top among Black women's facial concerns (796 Black women, ages 22 to 85); dark marks after irritation hit darker skin more often and harder | MOSAIC survey, J Clin Aesthet Dermatol 2026; JCAD PIH review |
| We're the backbone of healthcare | Black women are 13.7% of the healthcare workforce (2x their share of all workers), almost 1 in 4 practical nurses and aides, and 10.2% of RNs | Health Affairs 2022 (Dill and Duffy), via Healthcare Dive |
| Shifts are hard on skin | 62% of healthcare workers had skin problems from masks and PPE; nurses were affected most (96.7%), and wearing them 6+ hours a day pushed it to 93.6%. Sweating was a top symptom | Healthcare-worker PPE study, PMC9792000 |
| Makeup all day | Makeup can cause "acne cosmetica," and it can take up to 6 months to show. Dermatologists say wash after you sweat and take makeup off before bed | American Academy of Dermatology |
| Foundation is a fight | One Black consumer: "I've gone through six or seven foundation swatches trying to find one that matches." Black customers are 5.7x more likely to be dissatisfied with color cosmetics | McKinsey 2022 |
| Glass skin is everywhere now | The glass skin trend started in the early-to-mid 2010s, spiked again from late 2025 into 2026, and Black women have joined it on TikTok | CP24/AP (Oct 2026); xoNecole |
| And it's misleading | 95% of top viral glass-skin TikToks had at least one misleading claim, 84% ignored skin type, none were made by dermatologists. Dermatologists say too many products can lead to irritation and breakouts | EADV Congress 2026 study (Paysano et al.), via Personal Care Insights and CP24; AAD |
| Creators are the new teacher | About 80% of Gen Z women and 61% of millennial women call creators their most trusted beauty source | LTK Beauty Shopper Study (2023), via eMarketer |

**FACT vs INTERP:** everything in the table is FACT from the source named. The characters are INTERP, built only from these facts: each one is a composite of what the data shows, not a guess.

## Why your reference ads work (the formula we're building on)

From the three ads you sent ("Dad Protect Daughter," "Dad Weight," and the Batana oil film), these are the patterns that make them hit, and where each one lands in our story:

1. **A shame moment that hurts someone else.** The problem costs a person you love, not only you. *Ours:* "Mama, can you stand in the back?"
2. **Real life, real pressure.** The hero is busy, capable and tired: she fixes everybody else. *Ours:* a nurse who takes care of everybody's body but her own skin.
3. **She did everything they told her.** She followed the experts and the internet, spent the money, and it still didn't work. *Ours:* 11 steps, $600, a GRWM video.
4. **The low point, alone.** *Ours:* Kenya in her car after a 12-hour shift, mask lines on her face, wiping foundation off her phone screen.
5. **A truth-teller from inside.** Someone plain-spoken who names the real cause. *Ours:* Ms. Faye, 25 years doing Black brides' faces.
6. **Absolution.** "You ain't weak, you backed up." The problem is not your fault. *Ours:* "Nobody made it for us. So our mamas made do."
7. **Back to the source.** A wise elder at the origin. *Ours:* Ghana, Ethiopia, then the Amazon, ending in America.
8. **One object, close up, cut on the word.** *Ours:* a blotting sheet soaked through, edge gel on the forehead, the trio counted on fingers, two drops sinking in.
9. **A ladder of moments, not a calendar.** People notice, a stranger asks. *Ours:* thirty nights, each woman's moment.
10. **A payoff that protects the next generation, then a dedication.** *Ours:* the portrait, and "For every woman who worked a double and still showed up for the picture."

Craft we keep from the Batana film: one narrator speaking in short rhymes over music, word-by-word captions with the key word in gold, and very little lip-sync.

## The story in one breath

A mother who has hidden from every family photo since her daughter asked her to stand in the back. A daughter who became a nurse just like her, and now chases the same shine on purpose because her phone told her to. On the wedding morning, a makeup artist tells three women in her chair the truth: it ain't your skin, and it ain't your fault. Nobody made it for us. Then she shows them who finally did, and where it comes from. About 3 minutes 40, stylized 3D at Pixar quality, narrated by Ms. Faye in rhyme.

## The story, scene by scene

### Scene 1. The photo she keeps walking out of (0:00 to 0:25)

A wedding. The photographer calls, "Family of the bride!" Everyone gathers, and the bride's mother, Ms. Dee, 56, quietly slides out of frame. "Take it without me, baby."

Flashback to June 2009. Ms. Dee is 39, a nursing aide who came straight from a double shift to her daughter's eighth-grade graduation, still in her scrubs. It's hot. Her edges are pressed down with hair grease, and in the heat it's running down onto her forehead. Her arms are shining with cocoa butter. Kenya, 14, tugs her sleeve: "Mama, can you stand in the back?" Ms. Dee did. That day and every picture since.

**Why it's here:** the shame moment that hurts someone else, the opening move of all three of your references. **What makes it real:** Black women are almost 1 in 4 nursing aides and practical nurses; hair grease and body butters are used more by Black women than by anyone else studied; hair products landing on the forehead is a documented, everyday thing. Nothing in this scene is invented. **Who it reaches:** every woman 30 to 55 who has a picture like this, and every daughter who said something like it.

### Scene 2. The daughter who followed her (0:25 to 0:55)

Today. Kenya is 31, an ICU nurse. She followed her mama into healthcare. We see her 12-hour shift in quick cuts: mask on, mask off, sweat at her hairline, a bathroom-break mirror check. Ms. Faye narrates:

*"She takes care of everybody. Every body but her own."*

That night, ring light on, she films a get-ready-with-me video, wedding countdown. Eleven bottles lined up. "Step seven, y'all, seal it in." The comments say "glass skin goals!!" She's spent $600 on it.

Then the low point: her car in the hospital garage after a shift. Mask lines pressed into her cheeks. She checks the camera and the foundation is gone. She wipes it off her phone screen. "I did everything they said."

**Why it's here:** "she did everything they told her" and the low point alone, patterns 3 and 4 in your references. And the irony that runs the film: the daughter who was ashamed of her mother's shine is now paying for it on purpose. **What makes it real:** 62% of healthcare workers had skin problems from masks and PPE, nurses most of all, with sweating among the top complaints; 80% of Gen Z and 61% of millennial women trust creators most; glass skin is spiking right now. **Who it reaches:** nurses, aides, and every woman who works on her feet; the 18 to 34 glass-skin crowd.

### Scene 3. Ms. Faye's chair: three women, one problem (0:55 to 1:35)

Wedding morning. Ms. Faye, 50s, 25 years doing Black brides' faces, works three women in a row.

**Kenya:** the foundation slides right off. "But my skin's healthy, look at the glow!" Ms. Faye: *"Baby, that ain't glow. That's layers."* Close up: eleven thin films stacked on the skin, the camera flash bouncing off.

**Simone, 42, maid of honor**, a bank VP: "Don't even start. I wear a full face ten hours a day, it took me seven tries to find my shade, and it's gone by two o'clock." Ms. Faye: "And at night?" Simone, quiet: "...I sleep in it more than I'd admit."

**Jordan, 19, the cousin**, college sophomore, edges laid perfect, glazed-donut skin from TikTok. Ms. Faye swipes a finger along her hairline and holds it up to the light: edge gel. *"What you put on your hair don't stay on your hair."*

Then the groom, Marcus, 33, walks by, stacking beard oil. His groomsman looks down. "Bro. Your ankles." Ashy.

And the line of the film. Ms. Faye, to Kenya, looking at a photo of Ms. Dee on her phone: *"Your mama called it grease. Your phone calls it glass. Baby, it's the same layers."*

**Why it's here:** the truth-teller from inside, pattern 5, delivered as a roll call so every age sees herself in one chair. **What makes it real:** foundation took "six or seven swatches" for a real McKinsey respondent; dermatologists say take makeup off before bed and wash after you sweat; hair products on the forehead are documented; Black skin is the oiliest and also the most prone to ashiness. **Who it reaches:** Simone is professional women 35 to 45; Jordan is 18 to 24; Marcus is the men; Kenya is everyone in between.

### Scene 4. It ain't your fault (1:35 to 1:55)

Kenya, frustrated: "So my mama was wrong, and I'm wrong too?"

Ms. Faye sets down her brush. This is the turn of the film:

*"No, baby. Nobody made it for us. Not for our skin, not for our shifts, not for our sweat. So our mamas made do. Grease was making do. And them videos? Most of 'em never even asked what kind of skin you got."*

On screen, a quiet super: *84% of top viral glass-skin videos didn't account for skin type.* (EADV 2026 study, footnoted.)

*"You ain't doing too little. You doing too much of the wrong thing."*

**Why it's here:** absolution, pattern 6, the move that turns shame into relief and makes your references so shareable. It speaks straight to what you've observed: Black women weren't served, so they improvised. **What makes it real:** 3x more dissatisfied (McKinsey); 72% say there's a gap (NielsenIQ); 84% of the viral videos ignored skin type (EADV 2026). **Emotion:** 7 out of 10. Every mother watching exhales.

### Scene 5. Who finally made it for us (1:55 to 2:10)

Ms. Faye sets down the YO Cleanse. Kenya: "Black soap? Mama's bars dried us out." Ms. Faye: "Not all black soap is the same. I asked the people who make this one."

Flashback to the YO tent. Amin: *"Fifteen years in this business, I watched them sell us more steps, smaller bottles, and labels nobody reads. So I went and got it myself."* Kimmy: *"I grew up in my mother's esthetics room. Every woman who sat in her chair, she washed first. Then she fed the skin. That's how we built this."*

**Why it's here:** answers "nobody made it for us" with "these two did." Your 15 years and Kimmy's mother being a master esthetician are the proof that this was built by people who know our skin. Black-owned, family-founded.

### Scene 6. Back to the source (2:10 to 2:45)

**Ghana.** A village soap yard (fictional, no real place named). Plantain skins and cocoa pods burned slow to ash; an elder stirring a big iron pot for hours. She presses a warm brown ball of soap into Amin's hand: *"You want it fast, or you want it right?"* Hard cut to Kenya's eleven bottles. Then the elder washes her granddaughter's face: *"My grandmother washed me with this. I washed her mother."*

**Ethiopia.** Misty highland fields. A farmer pours black seed into Amin's palm: *"Tikur azmud."* Black seed. People have treasured it for thousands of years; they even found it in King Tut's tomb. Pressed into a slow stream of dark gold oil. Antioxidant-rich, so skin feels smooth and looks nourished. The one ingredient in all three bottles.

**The YO trio.** Back in the chair, Ms. Faye counts it on her fingers, and each one gets its own close up:
- **Sea moss**: a mineral-rich cushion of moisture, so you rinse soft, not tight.
- **Black seed**: antioxidant-rich, smooth and nourished, even while you wash.
- **Jojoba**: "It ain't even really an oil, baby. It's a liquid wax, close to what your own skin makes." Light, gives the lather slip, rinses clean.

Kenya rinses a patch on her hand, waiting for that tight, squeaky feeling. It doesn't come. "Huh."

**Why it's here:** pattern 7, the source with a wise elder, and the reason this soap isn't the bar that dried her out. Plant-based, with an origin you can see.

### Scene 7. The wash: the heart of the film (2:45 to 3:00)

Ms. Dee has been listening in the doorway. She steps in and holds out her hand for the bottle. "Let me." And on her wedding morning, the mother washes her grown daughter's face. We cut between Ms. Dee's hands and the elder in Ghana washing her granddaughter. Same light. Same lather.

*"Same soap. Other side of the ocean."*

**Emotion:** 10 out of 10. The mother who was sent to the back is the one caring for her daughter now.

### Scene 8. Head to toe (3:00 to 3:20)

Quick and rhythmic, one object per cut:
- **Supa Glo Facial Elixir:** ten oils, two drops. Rosehip, turmeric, argan, almond, calendula, grapeseed, jojoba, black seed, and one you never heard of: **copaiba**, golden resin from an Amazon tree. Amin: "I didn't fly to the Amazon for this one. I studied it till I knew exactly why it belonged." Ms. Faye: "Bet you never heard of it. That's the point." On screen: *Helps fade the look of dark marks.*
- Two drops sink in while a slick of glass sits on top. *"Glass sits on top. This absorbs."* The brush glides and Kenya's makeup finally holds. *"Now THAT'S a canvas."*
- **Supa Glo Body Oil:** Kenya smooths it on her shoulders, then the white satin gown slides on. *"Not a mark on that dress."* Marcus's ankles, same oil: *visibly reduces the look of ashiness.*
- **It all comes home:** Ghana in the wash, Ethiopia in every bottle, a little Amazon in the glow, mixed, filled and bottled in America. *"Twenty plant ingredients. Three bottles. Face to feet. Thirty-seven ninety-seven."*

**Why it's here:** head to toe in one routine, which no face-only brand offers, with the price said out loud.

### Scene 9. Thirty nights (3:20 to 3:30)

The ladder of moments:
- Kenya, after a 12-hour shift, washes once, two drops, done. Her new post: "Y'all. I been doing too much."
- Simone takes the day off her face every night now. "Haven't slept in my face in a month."
- Jordan washes her hairline every night after she lays her edges.
- Ms. Dee, alone at her vanity, slides her old jars into a box, washes, presses in two drops, and looks in the mirror a little longer than she has in years. *"Her mama took the longest to believe. Thirty nights. Then she did."*

### Scene 10. Get in the picture (3:30 to 3:45)

The portrait. "Family of the bride!" Ms. Dee starts to slide out again, and Kenya catches her hand. *"Mama, I asked you to stand in the back once. Never again."* Front and center. Flash. They glow, no glare. A guest leans over: "Okay... what's the routine?"

Ms. Faye, to camera: *"It ain't your skin. It ain't your fault. It's what you stacked on it. Wash it off. Then get in the picture."*

Dedication on black: **For every woman who worked a double and still showed up for the picture.**

Real photo of Amin and Kimmy at the real YO tent. *The real founders. The real soap.* End card: YO logo, Your Original Skincare, Complete Routine $37.97, five-star Google reviews, mixed, filled and bottled in the USA, also in 45+ beauty supply stores. VO: "Online, or at your beauty supply."

## Who it speaks to

| Audience | Who carries it | What she sees of herself |
|---|---|---|
| Black women 30 to 55 (core buyer) | Ms. Dee, Kenya | Standing in the back; working doubles; making do |
| Nurses, aides, women on their feet | Kenya, young Ms. Dee | Masks, sweat, 12-hour shifts, no time |
| Professional women 35 to 45 | Simone | A full face 10 hours a day, foundation gone by 2, sleeping in it |
| 18 to 24, TikTok generation | Jordan, Kenya's GRWM | Glazed skin, edge control, trusting creators |
| Men | Marcus | Beard oil stacking, ashy ankles |
| Skeptics | Ms. Faye, the source journey | "Not all black soap is the same," proof you can see |
| Buy Black, buy American | Founders, the homecoming | Black-owned, family-founded, bottled in the USA |

## Emotion map

1. Scene 1, the photo: 8 out of 10, the hook.
2. Scene 2, the car: 6, recognition.
3. Scene 3, the chair: laughs, a 4 to breathe.
4. Scene 4, "it ain't your fault": 7, relief.
5. Scene 6, Ghana: 6, wonder.
6. **Scene 7, the wash: 10, the first peak.**
7. Scene 9, Ms. Dee at the mirror: 8.
8. **Scene 10, the portrait: 10, the second peak.**

## Music: your YO songs

- **Under Ms. Faye's narration (Scenes 1 to 4):** *Come Back To It* (R&B), low and warm.
- **The source journey (Scenes 5 to 6):** *YO From The Founders*.
- **The wash (Scene 7):** music drops to almost nothing, just water and breath.
- **Head to toe and thirty nights (Scenes 8 to 9):** *We Da Purist* or *YO Da Real Deal* for the rhythm cuts.
- **Portrait and end card (Scene 10):** *Glow Like Dat* (Kimmy), landing on "Keep yourself beautiful, don't gotta go broke for that."

I'll cut a 60-second audition of these placements before we render anything.

## Claims guardrails (built in)

- YO is never shown clearing bumps or marks. "Helps fade the look of dark marks" (Elixir) and "visibly reduces the look of ashiness" (Body Oil) are words only, from your site.
- The Cleanse "helps remove dirt, excess oil and surface buildup," from its label. We never say "clogs" or "breakouts" about anyone's product; the villain is layers sitting on top.
- No brand is named. Grease, edge gel and glass-skin bottles are all generic.
- The 84% super runs with a footnote to the EADV 2026 study. The 3x figure (McKinsey 2022) is held as backup.
- Ghana and Ethiopia are named only as countries. The village, elder and farmer are fictional, no real source is identifiable, and no certificates appear on screen.

## What it takes

- **From you:** your voice on about 6 short lines, Kimmy on 2 (she okays her line about her mother), and a photo of the Unscented Cleanse.
- **Characters:** 2 new ones (Simone, Jordan). 10 master images in total, about 20 credits.
- **Credits:** about 660 in total (about 40 more than before for the chair roll call). You have 175, enough for phases 1 and 2. Add about 500 before the video phase.
- **Time:** 5 to 7 days from your GO.

## Next

1. GO on phase 1: 10 character masters, about 20 credits.
2. I'll cut the 60-second music audition from your songs (free).
3. Kimmy okays her line.
4. You record your 6 lines.
5. Add about 500 credits before phase 3.
