**Goal:** the same Forever Pictures story, made simpler and more powerful. One original anthem carries the emotion, Ms. Faye's spoken word carries the truth and the ingredients, and only a handful of real character lines break through. **Pick:** this format, at about 3:55, with your brand song "Glow Like Dat" as the exit.

## The format in plain words

- **The anthem (sung).** An original song, "Get In The Picture," sung by one Black woman's voice, made in Suno. She is singing to herself in the mirror: honest about the hiding and the layers, then lifting herself up. It plays over the emotional montages, never over facts.
- **Ms. Faye (spoken word).** The only narrator, rhymed and rhythmic over the song's instrumental. She tells the story, says the dialogue for the characters ("And Simone said, real quiet: armor on."), and does every ingredient, benefit and price, because spoken words stay clear and compliant.
- **Seven earned lines.** Only these come from someone other than Ms. Faye or the singer. Each is about two seconds, which is why they hit so hard.
- **The exit.** "Glow Like Dat" with Kimmy singing "Keep yourself beautiful, don't gotta go broke for that" over the end card, with your and Kimmy's real photo and one line each.
- **Captions** run word by word throughout, with the key word in gold, so it works with the sound off.

**The trick that makes it hit:** we hold back the chorus. The singer gets close to "get in the picture" twice and the song breaks off both times. The full chorus only lands after Ms. Dee washes her daughter's face. By then the viewer has been waiting three minutes to hear it.

## The story, start to finish

### 1. The picture she keeps walking out of (0:00 to 0:35) · spoken

A wedding. The photographer calls, "Family of the bride! Everybody in!" Everyone crowds in except the bride's mother. Ms. Dee, 56, slides out of the frame: **"Take it without me, baby."** (earned line, on camera)

Ms. Faye: *"Every family's got a picture. And some of us been hiding from ours for years. Seventeen years she been stepping out of frame. Let me tell you where it started."*

Flashback, June 2009. Ms. Dee runs from a double shift to her daughter's eighth-grade graduation, still in scrubs, sweat on her brow, the grease on her edges melting under the gym lights. Kenya, 14, embarrassed in front of her friends: **"Mama... can you stand in the back?"** (earned line, on camera)

Ms. Faye: *"Kids say things quick. Mamas carry them long."*

- **What you feel:** a gut punch. Every mother who has felt like an embarrassment to her child, and every daughter who once said something careless.
- **Value:** it frames the shine as work and heat, not vanity, and it sets the promise: she will get her picture back.

### 2. The back row (0:35 to 1:00) · sung, Verse 1

The anthem enters, soft piano and one voice. Montage: seventeen years of family photos, Ms. Dee always at the edge. Kenya grows up, becomes an ICU nurse, and films a glass-skin "get ready with me": eleven bottles, step seven, "seal it in." Her niece Jordan copies it in her own mirror. The verse climbs toward the chorus, and then cuts to silence on Kenya alone in her car after a twelve-hour shift, crying.

Ms. Faye, into the silence: *"She did everything they said. Nobody said what was underneath."*

- **What you feel:** recognition, then the ache of the song breaking off.
- **Value:** the cycle is passed down, from grease then to glass now, and the next generation is watching.

### 3. The armor (1:00 to 1:25) · sung, Verse 2

The song comes back. Simone, 42, a bank vice president, at 5:30 a.m.: flat iron, edge control, full face, like she's suiting up. At 2 p.m. she's in the office bathroom touching up while a colleague says she always looks so put together. The verse climbs again and breaks off on her face in the mirror.

Ms. Faye: *"She don't wear makeup. She wears armor. 'Cause the room she walks in don't forgive."*

- **What you feel:** every professional Black woman feels seen.
- **Value:** names all-day makeup and hair product on the skin, and why women can't just stop.

### 4. The chair (1:25 to 2:00) · spoken

Ms. Faye's makeup chair, the week before the wedding. Spoken word over a low beat:

*"Kenya sat down proud: 'Look at my glow.' Baby, that ain't glow. That's layers. I lifted her edges, saw them little bumps at the hairline. 'How long?' 'Since nursing school.'"*

Macro shot: edge gel on a fingertip, then a 3D cross-section of the hairline, wax and oil settling on the skin.

*"What you put on your hair don't stay on your hair."*

*"Simone said nobody at work has seen her real skin in fifteen years. I told her, baby, I've seen it. It's beautiful. It's just tired of carrying all that."*

Ms. Faye holds up the 2009 photo: *"Your mama called it grease. Your phone calls it glass. Baby, it's the same layers."*

- **What you feel:** caught, then understood.
- **Value:** the cause in plain words: layers sitting on top, and hair products landing on the skin.

### 5. Every stage (2:00 to 2:15) · spoken

A fast portrait montage: the prom girl, the new mama, the nurse off a night shift, the boss who never takes it off, the grandmama with her mama's jar.

*"Twenty-five years in this chair, I've seen every stage. Different ages, same story. We pile it on, 'cause nobody ever gave us the right thing to take it off. Your mama wasn't wrong, baby. Grease was making do."*

- **What you feel:** absolution. The shame turns into understanding.
- **Value:** every woman, every life stage. The problem was what was missing, not her.

### 6. The source (2:15 to 2:45) · spoken

*"Not all black soap is the same. I asked the folks who make this one. Him, fifteen years in this business. Her, raised in her mama's esthetics room. Every woman in that chair got washed first, then fed. So he went to the source."*

Ghana. An elder soap maker looks straight at him: **"You want it fast, or you want it right?"** (earned line, on camera)

Ethiopia. A farmer pours black seed into his palm: **"Tikur azmud."** (earned line, on camera, Amharic)

Back in the chair, Ms. Faye counts on her fingers:

*"Your mama's bars dried you out, 'cause plain black soap is just black soap. This one's got three things plain don't. Sea moss: a mineral cushion, so you rinse soft, not tight. Black seed: treasured for thousands of years, rich in antioxidants. And jojoba. It ain't even really an oil, baby. It's a liquid wax, close to what your own skin makes. Cleanses deep. Exfoliates. Tones. And you don't walk away stripped."*

- **What you feel:** trust and a little awe.
- **Value:** founders with real experience, the Ghana and Ethiopia origin, and the three ingredients that make this soap different.

### 7. Wash it off (2:45 to 3:05) · sung, the bridge

The music strips down to voice and a choir's hum. Ms. Dee takes the washcloth from Ms. Faye: **"Let me."** (earned line, voice-over) She washes her grown daughter's face. The singer: *"Wash it off... all the years, all the shame..."* Kenya closes her eyes. Cut to the elder in Ghana washing her granddaughter's face with the same soap.

- **What you feel:** the first emotional peak. A mother and daughter, forgiven without a word.
- **Value:** wash first. The soap is love handed down, on both sides of the ocean.

### 8. Feed it (3:05 to 3:25) · spoken, on the beat

The beat kicks in, and the oils get a rhythmic roll call, one oil per cut, with 3D shots of two drops sinking in.

*"Now we feed it. Ten oils, two drops. Rosehip to smooth. Turmeric to brighten. Argan and almond, vitamin E. Calendula to soothe. Jojoba and black seed, the family. And copaiba, all the way from South America. Glass sits on top. This sinks in. Then the body: seven oils, face to feet, absorbs fast. Ghana in the wash. Ethiopia in every bottle. Mixed and bottled right here at home. Twenty plant ingredients. Three bottles. Thirty-seven ninety-seven."*

- **What you feel:** confidence. It's simple and complete.
- **Value:** step two, replenish; head to toe; plant-based; made in America; the price.

### 9. Thirty nights (3:25 to 3:40) · sung, the first full chorus

Finally, the chorus lands. Montage: Kenya posts a new video with no ring light, "Y'all... I been doing too much"; Simone at work in light makeup; Jordan washing her edges at the sink; Marcus hunting for "his" body oil. Ms. Dee looks in the mirror and smiles at herself.

- **What you feel:** release. The payoff the song has been holding back.
- **Value:** the routine fits real life, for everyone in the family.

### 10. Get in the picture (3:40 to 3:55) · sung, final chorus

The wedding portrait. "Family of the bride!" Ms. Dee starts to slip out. Kenya catches her hand. The music drops out: **"Mama, I asked you to stand in the back once. Never again."** (earned line, on camera) Front and center. Flash. The final chorus comes back a key higher with the choir: *"Get in the picture, Mama..."*

Ms. Faye, to camera: *"It ain't your skin. It ain't your fault. It's what you stacked on it. Wash it off. Feed it right. Then get in the picture."*

- **What you feel:** the biggest emotional peak of the film.
- **Value:** the message and the call to action in one line.

### 11. The exit (3:55 to 4:05) · your brand song

"Glow Like Dat": *"Keep yourself beautiful, don't gotta go broke for that."* A real photo of you and Kimmy at the YO tent. Kimmy: **"Wash first. Then feed it. That's how my mother did it."** You: **"That's how we built YO."** End card: YO logo, Your Original Skincare, the Complete Routine at $37.97, YOSKINCARE.COM.

## The anthem: "Get In The Picture"

Original lyrics, written to be sung by one woman to herself. It's honest in the verses and lifts her up in the chorus. The lyrics make no product claims; the product talk stays spoken.

**[Intro]** *[soft piano, humming]*
Mm... mm-hmm...

**[Verse 1]**
I learned to smile from the back row,
chin down, shoulders small.
Seventeen years of family pictures,
and I'm barely there at all.
Worked a double, kept the lights on,
sweat was the price I paid.
Somebody told me, hide that shine, girl,
so I stepped out of the frame.

**[Pre-Chorus]**
But I'm tired of standing where they put me,
tired of covering what's mine...

**[Chorus]**
So get in the picture, baby, get in.
Front row, chin up, let the flash come in.
I ain't hiding what my mama gave me,
I ain't stepping out again.
Get in the picture... get in.

**[Verse 2]**
Five a.m., I'm putting on my armor,
every layer like a shield.
Smile for the meeting, fix it at two,
never let 'em see what's real.
Layer on layer, step after step,
they sold me glass and called it glow.
I been carrying the whole world on my face,
and I'm the last one to know.

**[Pre-Chorus 2]**
But tonight I'm setting it down,
tonight I'm coming back to me...

**[Bridge]** *[stripped down, choir]*
Wash it off... (wash it off)
all the years, all the shame.
Wash it off... (wash it off)
I'm still here, I'm still the same.
What my grandmama knew, what her mama knew:
start with the water, let the truth come through.
I'm not too much, I'm not too little,
I'm just finally... me.

**[Chorus]**
So get in the picture, baby, get in.
Front row, chin up, let the flash come in.
I ain't hiding what my mama gave me,
I ain't stepping out again.
Get in the picture... get in.

**[Final Chorus]** *[key change, full choir]*
Get in the picture, Mama, get in.
Front row, hold my hand, let the flash come in.
You ain't hiding what you gave me,
you ain't stepping out again.
Get in the picture... get in.

**[Outro]** *[voice alone]*
Get in.

## How to make the song in Suno

1. **Make a new song in Custom mode.** Paste the lyrics above exactly, including the bracketed section tags.
2. **Style box, paste this:** *soulful R&B anthem, gospel influence, female lead vocal, warm powerful alto, intimate verses, soaring chorus, piano and Hammond organ, deep 808 bass, half-time live drums, choir backing vocals on bridge and final chorus, key change on final chorus, empowering, emotional, 74 BPM*
3. **Title:** Get In The Picture. Leave out any artist names.
4. **Make 4 to 6 versions.** Pick the one whose voice sounds like a grown Black woman singing to herself, not a pop star performing. The chorus has to give you chills.
5. **Get the instrumental** of the version you pick, using Suno's stems or instrumental option. Ms. Faye speaks over the instrumental, and the edit cuts between the vocal and instrumental versions.
6. **Send both files** as a Google Drive link.

**Rights:** as far as I know, Suno only grants commercial use for songs made on a paid plan. Make this one on a paid plan, and check your plan's terms before it runs as an ad.

**Why not one of the brand songs for the anthem:** none of them tell this story. The anthem has to follow the film beat for beat: the back row, the armor, the wash, the picture. "Glow Like Dat" is the perfect exit, because it's already the brand's voice and the tagline.

## Every spoken line that isn't Ms. Faye

| Line | Who | How it plays | How to say it |
|---|---|---|---|
| "Family of the bride! Everybody in!" (and again at the end) | Photographer | Voice-over | Bright, busy, calling across a crowd |
| "Take it without me, baby." | Ms. Dee | On camera | Soft and practiced, a smile that doesn't reach her eyes |
| "Mama... can you stand in the back?" | Kenya, 14 | On camera | Quick, embarrassed, half under her breath |
| "You want it fast, or you want it right?" | Ghana elder | On camera | Slow and certain, looking straight at him |
| "Tikur azmud." | Ethiopian farmer | On camera | Proud and warm, correct Amharic |
| "Let me." | Ms. Dee | Voice-over | Barely above a whisper |
| "Mama, I asked you to stand in the back once. Never again." | Kenya | On camera | Steady and loving, a small break on "never again" |
| "Wash first. Then feed it. That's how my mother did it." | Kimmy | Over your real photo | Warm and proud |
| "That's how we built YO." | Amin | Over your real photo | Calm, a little pride |

## What changes from the last version

- **Casting drops from 16 voices to 9 speaking voices plus the singer,** and only Ms. Faye has more than two lines. Kenya goes from 13 lines to 1, and Simone and the small parts become narration or song.
- **Lip-sync drops** from 10 lines (about 65 credits) to 7 short lines: 5 two-second lines plus Ms. Faye's 2 lines to camera, about 20 seconds and about 50 credits. If we make Ms. Faye's "same layers" line voice-over, it falls to about 40.
- **Total budget:** about 770 credits instead of about 790. The picture stays the same; the savings are lip-sync and voice auditions.
- **Your casting scripts:** the Ms. Faye script changes, because she now carries the dialogue. Hold that one; I'll send the new version once you OK this format. The Ghana and Ethiopia scripts are unchanged, except that the elder now has one line. Ms. Dee, Kenya and Kenya at 14 have 1 or 2 lines each.

## Next

1. OK this format.
2. Make the song in Suno with the prompt above, then send the vocal and instrumental versions.
3. I'll send the new Ms. Faye script for your actress, and a short sheet for Ms. Dee and both Kenyas.
4. GO on phase 1, the master images, about 20 credits.
