# Forever Pictures: every line, every voice

**Goal:** the full spoken script, line by line for each character, with how to say it and what it must land. **Done:** 87 lines across 16 voices. Every line was sharpened for emotion and message and checked against the claims rules.

## How to read this

- Each line has an ID (F for Ms. Faye, K for Kenya, and so on), its scene, and how it plays: **voice-over**, **on camera, lip-sync**, or **on her phone screen**.
- **How** is the delivery note for the actor or the AI voice.
- **Lands** is the feeling and the message that line must deliver.

## The 10 lip-sync lines

These are the only lines where we see the mouth move to the words, about 25 seconds in total, at about 65 credits. Every other line plays over the action, a reaction or a back-of-head shot.

1. **D1, Ms. Dee, Scene 1:** "Take it without me, baby."
2. **K14, Kenya, 14, Scene 1:** "Mama... can you stand in the back?"
3. **K2, Kenya, Scene 2:** "I did everything they said."
4. **S1, Simone, Scene 3:** "Armor on."
5. **S5, Simone, Scene 4:** "Don't. Nobody at work has seen my real skin in fifteen years."
6. **F17, Ms. Faye, Scene 4:** "Your mama called it grease. Your phone calls it glass. Baby, it's the same layers."
7. **E1, Ghana elder, Scene 7:** "You want it fast, or you want it right?"
8. **ET1, Ethiopian farmer, Scene 7:** "Tikur azmud."
9. **K13, Kenya, Scene 11:** "Mama, I asked you to stand in the back once. Never again."
10. **F41, Ms. Faye, Scene 11:** "It ain't your skin. It ain't your fault. It's what you stacked on it. Wash it off. Feed it right. Then get in the picture."

## What I sharpened, and why

- **Jordan's echo (J1).** Jordan whispers Kenya's exact words, "Step seven... seal it in," to her own mirror. Without a single explanation, it shows the habit passing down.
- **Kenya's two words (K4).** "...Since nursing school" tells you she has hidden her hairline for years.
- **Ms. Dee's quiet apology (D3).** "I should've done this a long time ago," said while she washes her daughter's face. Then Kenya answers with one word, "Mama...". That's the first peak.
- **Ms. Dee's mirror (D4).** "There you are," to her own reflection. She sees herself again, before she steps into the photo.
- **Simone's repeat (S1 and S3).** The same "Armor on," but wearier the next morning. That shows the cycle with no way out.
- **The roll call (F33)** gives every oil a one-word job on the beat, so value builds without slowing down.
- **The final line (F41)** now carries the whole message in order: not your skin, not your fault, the layers, wash, feed, get in the picture.

## Line sheets by character

### Ms. Faye (42 lines)

Narrator. Makeup artist, mid-50s, Atlanta, 25 years in the chair. Low-to-mid alto with a smile in it. Narration in short spoken-word rhymes; chair talk is plain truth. Cast: real Black voice actress.

**F1** · Scene 1 · voice-over

> "Every family's got a picture. And some of us been hiding from ours for years."

- **How:** Warm, a little knowing, like starting a story on the porch.
- **Lands:** Hooks the viewer in five seconds: this is about family, not a product.

**F2** · Scene 1 · voice-over

> "Seventeen years she been stepping out of frame. Let me tell you where it started."

- **How:** Slower. The music drops under her.
- **Lands:** Turns curiosity into a promise: you need to know why.

**F3** · Scene 1 · voice-over

> "June, two thousand nine. A double shift behind her, still in her scrubs. Sweat on her brow, and the grease on her edges giving up in the heat."

- **How:** Rhythmic, tender, no judgment of Ms. Dee.
- **Lands:** Grounds the shine in work and heat, not vanity. Every working mother feels it.

**F4** · Scene 1 · voice-over

> "Kids say things quick. Mamas carry them long. She stood in the back. And that's where she stayed."

- **How:** Quiet, almost a whisper on the last line.
- **Lands:** The cost lands: seventeen years of pictures.

**F5** · Scene 2 · voice-over

> "Now that baby's thirty-one. An ICU nurse, just like her mama. She takes care of everybody. Every body but her own."

- **How:** Pride, then a beat of sadness on 'her own.'
- **Lands:** Respect for Black women in healthcare, and the irony that sets up the problem.

**F6** · Scene 2 · voice-over

> "Eleven bottles. Six hundred dollars. Chasing the same shine she was ashamed of at fourteen."

- **How:** Dry, a little rueful.
- **Lands:** The irony that runs the film: grease then, glass now.

**F7** · Scene 2 · voice-over

> "Somebody's always watching."

- **How:** Low and simple.
- **Lands:** The stakes move to the next generation.

**F8** · Scene 2 · voice-over

> "Everything they said. Nobody said what was underneath."

- **How:** Gentle, sets up the truth.
- **Lands:** Promise of an answer.

**F9** · Scene 3 · voice-over

> "Five-thirty in the morning, and Simone's already suiting up."

- **How:** Crisp, matching the rhythm of the flat iron and brushes.
- **Lands:** Introduces the professional woman with respect.

**F10** · Scene 3 · voice-over

> "She don't wear makeup. She wears armor. 'Cause the room she walks in don't forgive."

- **How:** Proud and protective, a little edge on 'don't forgive.'
- **Lands:** Every corporate Black woman feels seen.

**F11** · Scene 3 · voice-over

> "New bump? Cover it. Long day? Layer it. Fall asleep in it. Then do it all again."

- **How:** Rhythmic, faster, like a treadmill.
- **Lands:** The cover-up cycle in four beats.

**F12** · Scene 4 · voice-over

> "Baby, that ain't glow. That's layers."

- **How:** Kind but firm. No laugh. Truth.
- **Lands:** The headline truth of the film.

**F13** · Scene 4 · voice-over

> "And these little bumps at your hairline? How long you been covering these?"

- **How:** Softer, concerned, lifting Kenya's edges.
- **Lands:** Names the hidden problem without shaming.

**F14** · Scene 4 · voice-over

> "Baby, I've seen it. It's beautiful. It's just tired of carrying all that."

- **How:** Very gentle. She lowers Simone's hand.
- **Lands:** Compassion: her skin isn't the problem, the load is.

**F15** · Scene 4 · voice-over

> "And at night?"

- **How:** Knowing.
- **Lands:** Sets up the confession.

**F16** · Scene 4 · voice-over

> "Mm-mm. What you put on your hair don't stay on your hair."

- **How:** Holds up a finger shiny with edge gel. Playful, then pointed.
- **Lands:** Edge control lands on the skin: the line people will quote.

**F17** · Scene 4 · on camera, lip-sync

> "Your mama called it grease. Your phone calls it glass. Baby, it's the same layers."

- **How:** Holding the 2009 photo. Slow, every word placed.
- **Lands:** The thesis of the film connecting two generations.

**F18** · Scene 5 · voice-over

> "Twenty-five years in this chair, I've seen every stage."

- **How:** She sets her brush down. Calm authority.
- **Lands:** Her credibility as the woman who has seen it all.

**F19** · Scene 5 · voice-over

> "The prom girl with her edges laid like glue. The college girl in a shade that wasn't hers. The new mama who ain't washed her face since the baby came. The nurse off a night shift. The boss who never takes it off. The grandmama still using her mama's jar."

- **How:** Over the portrait montage, one image per line, music swelling slightly.
- **Lands:** Every woman at every life stage finds herself.

**F20** · Scene 5 · voice-over

> "Different ages. Different jobs. Same story. We pile it on, 'cause nobody ever gave us the right thing to take it off."

- **How:** Strong, a little anger for the women, not at them.
- **Lands:** The big reframe: the problem is what was missing.

**F21** · Scene 5 · voice-over

> "Your mama wasn't wrong, baby. Nobody made it for us. Not for our skin, not for our shifts, not for our sweat. So we made do. Grease was making do."

- **How:** Tender. 'Making do' with love.
- **Lands:** Absolution: shame becomes understanding.

**F22** · Scene 5 · voice-over

> "And them videos? Most of 'em never even asked what kind of skin you got."

- **How:** Dry, a little shade.
- **Lands:** Credibility; the 84% super lands here.

**F23** · Scene 5 · voice-over

> "You ain't doing too little. You doing too much of the wrong thing."

- **How:** Clear and final.
- **Lands:** Sets up the answer: start with the wash.

**F24** · Scene 6 · voice-over

> "Not all black soap is the same. I asked the folks who make this one."

- **How:** Confident, a little secret.
- **Lands:** Transition to the founders.

**F25** · Scene 6 · voice-over

> "Folks who know the business. Folks who know the skin."

- **How:** Approval.
- **Lands:** Seals trust.

**F26** · Scene 7 · voice-over

> "So he went to the source."

- **How:** Anticipation; music opens wide.
- **Lands:** Launches the journey.

**F27** · Scene 7 · voice-over

> "Black seed. Treasured for thousands of years. They even found it in King Tut's tomb. Rich in antioxidants, and it's in every YO bottle."

- **How:** Wonder.
- **Lands:** Value and heritage of the hero ingredient.

**F28** · Scene 7 · voice-over

> "Your mama's bars dried you out 'cause plain black soap is just black soap. This one's got three things plain don't."

- **How:** Back in the chair, counting on her fingers.
- **Lands:** Answers the objection and sets up the trio.

**F29** · Scene 7 · voice-over

> "Sea moss: a mineral cushion, so you rinse soft, not tight. Black seed: smooth and nourished, even while you wash. And jojoba. It ain't even really an oil, baby. It's a liquid wax, close to what your own skin makes."

- **How:** One finger per ingredient, a beat between each.
- **Lands:** The YO trio: what makes this soap different.

**F30** · Scene 7 · voice-over

> "Cleanses deep. Exfoliates. Tones. And you don't walk away stripped."

- **How:** Satisfied, like a closing argument.
- **Lands:** The Triple-Action promise, compliant.

**F31** · Scene 8 · voice-over

> "Same soap. Other side of the ocean."

- **How:** Whispered, music almost gone.
- **Lands:** Ties the wash to the elder in Ghana: love handed down.

**F32** · Scene 9 · voice-over

> "Now we feed it. Ten oils. Two drops."

- **How:** Lift in energy as the beat comes in.
- **Lands:** Step two: replenish.

**F33** · Scene 9 · voice-over

> "Rosehip to smooth. Turmeric to brighten. Argan and almond, vitamin E. Calendula to soothe. Grapeseed, light as air. Jojoba and black seed, the family. And copaiba."

- **How:** Rhythmic roll call on the beat, one oil per cut.
- **Lands:** Every ingredient's job, building value.

**F34** · Scene 9 · voice-over

> "Bet you never heard of it. That's the point."

- **How:** A wink in the voice.
- **Lands:** Exclusivity.

**F35** · Scene 9 · voice-over

> "Glass sits on top. This sinks in."

- **How:** Simple contrast over the side-by-side.
- **Lands:** Glass versus glow, explained in six words.

**F36** · Scene 9 · voice-over

> "Now THAT'S a canvas."

- **How:** Delighted, brush gliding.
- **Lands:** The payoff for makeup wearers: it holds.

**F37** · Scene 9 · voice-over

> "Then the body. Seven oils, face to feet. Absorbs fast."

- **How:** Smooth, confident.
- **Lands:** Head-to-toe value.

**F38** · Scene 9 · voice-over

> "Ghana in the wash. Ethiopia in every bottle. A little Amazon in the glow. Mixed and bottled right here at home. Twenty plant ingredients. Three bottles. Face to feet. Thirty-seven ninety-seven."

- **How:** Building like a closing chant, the price said plainly.
- **Lands:** Origins, plant-based, made in America, and the price.

**F39** · Scene 10 · voice-over

> "Thirty nights."

- **How:** Calm.
- **Lands:** Time passing.

**F40** · Scene 10 · voice-over

> "And her mama took the longest to believe. Thirty nights. Then she did."

- **How:** Very tender.
- **Lands:** Ms. Dee's own change, so the ending is earned.

**F41** · Scene 11 · on camera, lip-sync

> "It ain't your skin. It ain't your fault. It's what you stacked on it. Wash it off. Feed it right. Then get in the picture."

- **How:** To camera, direct, warm, unhurried.
- **Lands:** The message and the call to action.

**F42** · Scene 11 · voice-over

> "YO. Your Original Skincare. The Complete Routine, thirty-seven ninety-seven. Online, or at your beauty supply."

- **How:** Over the end card, clear and friendly.
- **Lands:** What to buy, the price and where.

### Kenya (13 lines)

The bride, 31, ICU nurse. Bright, tired, proud. Cast: AI voice (audition 3).

**K1** · Scene 2 · on her phone screen

> "Okay y'all, wedding countdown! Step seven: seal it in."

- **How:** Upbeat creator voice, performing for her phone.
- **Lands:** The modern habit, shown with love, not mockery.

**K2** · Scene 2 · on camera, lip-sync

> "I did everything they said."

- **How:** Alone in the car, exhausted, almost crying, not quite.
- **Lands:** The low point every woman on her feet all day knows.

**K3** · Scene 4 · voice-over

> "But my skin's healthy. Look at the glow!"

- **How:** Defensive and proud.
- **Lands:** The myth: shine means healthy.

**K4** · Scene 4 · voice-over

> "...Since nursing school."

- **How:** Small, caught.
- **Lands:** Years of hiding in two words.

**K5** · Scene 5 · voice-over

> "So my mama was wrong... and I'm wrong too?"

- **How:** Hurt, close to tears.
- **Lands:** Voices the shame every viewer is feeling.

**K6** · Scene 6 · voice-over

> "Black soap? Mama's bars dried us out."

- **How:** Skeptical.
- **Lands:** The biggest objection, said by the hero.

**K7** · Scene 7 · voice-over

> "Huh. It don't feel tight."

- **How:** Genuine surprise, rubbing her hand.
- **Lands:** Proof on her own skin.

**K8** · Scene 8 · voice-over

> "Mama..."

- **How:** Eyes closed, tears.
- **Lands:** Forgiveness in one word.

**K9** · Scene 9 · voice-over

> "Co-pai-what?"

- **How:** Comic confusion.
- **Lands:** Makes the rare ingredient memorable.

**K10** · Scene 9 · voice-over

> "Not a mark on this dress."

- **How:** Touching the satin, relief.
- **Lands:** The non-sticky proof every woman fears.

**K11** · Scene 10 · on her phone screen

> "Y'all... I been doing too much."

- **How:** New video, no ring light, laughing at herself.
- **Lands:** She becomes the honest voice for her followers.

**K12** · Scene 10 · voice-over

> "What oil?"

- **How:** Innocent, hiding the bottle.
- **Lands:** The comic button.

**K13** · Scene 11 · on camera, lip-sync

> "Mama, I asked you to stand in the back once. Never again."

- **How:** Steady, loving, holding her hand. A small break on 'never again.'
- **Lands:** The payoff of the whole film.

### Kenya, 14 (1 line)

Kenya in 2009. Quick, embarrassed teen. Cast: AI voice.

**K14** · Scene 1 · on camera, lip-sync

> "Mama... can you stand in the back?"

- **How:** Quick, embarrassed, half under her breath, eyes on her friends.
- **Lands:** The wound the whole film heals. It has to sting because it's so casual.

### Ms. Dee (4 lines)

The mother, 56 (39 in the flashback). Soft, low, worn but loving. Cast: AI voice, or the Ms. Faye actress's recommendation if budget allows.

**D1** · Scene 1 · on camera, lip-sync

> "Take it without me, baby."

- **How:** Soft, practiced, a smile that doesn't reach her eyes. She's said this a hundred times.
- **Lands:** The gut punch: a mother removing herself from her own family picture.

**D2** · Scene 8 · voice-over

> "Let me."

- **How:** Barely above a whisper, holding out her hand.
- **Lands:** The mother steps forward: the turn of the whole film.

**D3** · Scene 8 · voice-over

> "I should've done this a long time ago."

- **How:** Soft, while washing. Her apology without saying sorry.
- **Lands:** The first emotional peak; the wound starts to close.

**D4** · Scene 10 · voice-over

> "There you are."

- **How:** Whispered to her own reflection.
- **Lands:** She sees herself again. Second-highest emotional moment.

### Simone (7 lines)

Maid of honor, 42, bank VP. Polished voice that cracks when exposed. Cast: AI voice.

**S1** · Scene 3 · on camera, lip-sync

> "Armor on."

- **How:** Whispered to the mirror. Resolve, no joy.
- **Lands:** One word explains why she does it: it's survival at work.

**S2** · Scene 3 · voice-over

> "Thanks, girl."

- **How:** Bright on the surface; the smile drops when the door closes.
- **Lands:** The mask between who she is and who she has to be.

**S3** · Scene 3 · voice-over

> "Armor on."

- **How:** Next morning. Same words, wearier.
- **Lands:** Repetition shows the cycle with no way out.

**S4** · Scene 4 · voice-over

> "Don't even start. Full face, ten hours a day, and it's gone by two."

- **How:** Brisk, joking to deflect.
- **Lands:** Relatable professional humor.

**S5** · Scene 4 · on camera, lip-sync

> "Don't. Nobody at work has seen my real skin in fifteen years."

- **How:** The voice cracks halfway. Her hand covers her jaw.
- **Lands:** The quiet emotional hit for every professional woman.

**S6** · Scene 4 · voice-over

> "...I sleep in it more than I'd admit."

- **How:** A small, ashamed laugh.
- **Lands:** The habit dermatologists warn about, said out loud.

**S7** · Scene 10 · voice-over

> "I took something off."

- **How:** Calm, smiling, lighter makeup.
- **Lands:** Her freedom in four words.

### Jordan, 16 (3 lines)

Kenya's niece. Excited, copies everything. Cast: AI voice (no minors hired).

**J1** · Scene 2 · voice-over

> "Step seven... seal it in."

- **How:** Whispered to her own mirror, copying Kenya word for word.
- **Lands:** Chilling echo: it's being passed down again, right now.

**J2** · Scene 4 · voice-over

> "Do mine just like Auntie's!"

- **How:** Excited, bouncing in the chair.
- **Lands:** The niece wants to copy the problem.

**J3** · Scene 10 · voice-over

> "Wash my edges every night. Auntie said."

- **How:** Proud, at the sink.
- **Lands:** The cycle breaks for the next generation.

### Amin (4 lines)

Founder. Your own voice, recorded on a phone. All voice-over.

**A1** · Scene 6 · voice-over

> "Fifteen years in this business, I watched them sell us more steps, smaller bottles, and labels nobody reads."

- **How:** Calm, honest, a man who's seen behind the counter.
- **Lands:** Insider truth builds trust.

**A2** · Scene 6 · voice-over

> "Hair products that never once thought about our skin. So I went and got it myself."

- **How:** Resolve on 'got it myself.'
- **Lands:** Why YO exists, and the founder's commitment.

**A3** · Scene 7 · voice-over

> "Right."

- **How:** Quiet, respectful.
- **Lands:** His values in one word.

**A4** · Scene 9 · voice-over

> "I didn't fly to the Amazon for this one. I studied it till I knew exactly why it belonged."

- **How:** Honest, a little pride.
- **Lands:** Point of difference, stated truthfully.

### Kimmy (2 lines)

Founder. Her own voice. All voice-over.

**KM1** · Scene 6 · voice-over

> "I grew up in my mother's esthetics room. She's a master esthetician."

- **How:** Warm, proud, smiling.
- **Lands:** Expert lineage: real skin knowledge.

**KM2** · Scene 6 · voice-over

> "Every woman who sat in her chair, she washed first. Then she fed the skin. That's how we built YO."

- **How:** Simple, loving.
- **Lands:** The method in one line: wash first, then feed.

### Ghana elder (3 lines)

Soap maker, 70s. Slow, certain. Cast: native Ghanaian speaker.

**E1** · Scene 7 · on camera, lip-sync

> "You want it fast, or you want it right?"

- **How:** Slow, certain, looking straight at him.
- **Lands:** The film's philosophy against eleven steps.

**E2** · Scene 7 · voice-over

> "Then you wait."

- **How:** A small smile.
- **Lands:** Craft, patience, quality.

**E3** · Scene 7 · voice-over

> "My grandmother washed me with this. I washed her mother."

- **How:** Over her washing her granddaughter's face. Tender.
- **Lands:** Heritage: this is our original skincare.

### Ethiopian farmer (1 line)

Black seed farmer. Cast: native Ethiopian (Amharic) speaker.

**ET1** · Scene 7 · on camera, lip-sync

> "Tikur azmud."

- **How:** Proud, pouring seeds into Amin's palm. Correct Amharic.
- **Lands:** Authentic origin you can hear.

### Marcus (1 line)

The groom, 33. Easy, funny. Cast: AI voice.

**M1** · Scene 10 · voice-over

> "Babe, where my oil go?"

- **How:** Searching the bathroom.
- **Lands:** A laugh, and men use it too.

### Groomsman (1 line)

Dry comic timing. Cast: AI voice.

**G1** · Scene 4 · voice-over

> "Bro. Your ankles."

- **How:** Dead serious, comic timing.
- **Lands:** A laugh for the men, and ashiness named.

### Photographer (2 lines)

Busy, bright. AI.

**P1** · Scene 1 · voice-over

> "Family of the bride! Everybody in!"

- **How:** Bright, busy, slightly off-mic.
- **Lands:** Sets the place and the stakes in one call.

**P2** · Scene 11 · voice-over

> "Family of the bride!"

- **How:** Same call as the opening.
- **Lands:** The setup returns.

### Office colleague (1 line)

Friendly. AI.

**C1** · Scene 3 · voice-over

> "Girl, you always look so put together."

- **How:** Friendly, sincere, at the next sink.
- **Lands:** Shows the praise that keeps the armor on.

### Monday colleague (1 line)

Curious. AI.

**C2** · Scene 10 · voice-over

> "Did you change something?"

- **How:** Curious, impressed.
- **Lands:** Others notice.

### Wedding guest (1 line)

Leaning in. AI.

**GU1** · Scene 11 · voice-over

> "Okay... what's the routine?"

- **How:** Leaning in, half whisper.
- **Lands:** The stranger asks: social proof.

## On-screen text (not spoken)

- Scene 2: comments on Kenya's video, "Glass skin goals!!" and "Routine??"
- Scene 5: "84% of top viral glass-skin videos didn't account for skin type." with a footnote to the EADV 2026 study
- Scene 7: "Sea moss · Black seed · Jojoba: the YO trio"
- Scene 9: each oil's name; "Helps fade the look of dark marks"; "Visibly reduces the look of ashiness"; "Absorbs fast. Won't stick to your clothes."
- Scene 11: "For every woman who worked a double and still showed up for the picture." Then "The real founders. The real soap." End card: YO logo, Your Original Skincare, Complete Routine $37.97, five-star Google reviews, bottled in the USA, also in 45+ beauty supply stores.
- Captions run word by word throughout, with the key word in gold.

## Compliance check on the product lines

- **F30** "Cleanses deep. Exfoliates. Tones." These are cosmetic actions you've cleared. "You don't walk away stripped" echoes the label's "without leaving skin feeling stripped."
- **F27, F29, F33** state ingredient facts only: antioxidant-rich, a liquid wax close to skin's own, vitamin E, smooth, brighten, soothe. No treat, heal or clear.
- **F35** "Glass sits on top. This sinks in." describes absorption, which matches "absorbs fast" on the site.
- **K10** "Not a mark on this dress" needs your satin test photo on file before it airs.
- **F16 and F13** describe hair products and bumps as the problem. YO never claims to clear them.
- No line uses "non-comedogenic," "best," "cures," or a brand name.

## Next

1. OK the actress for Ms. Faye and the two native speakers.
2. You and Kimmy record A1 to A4 and KM1 to KM2 (three takes each, phone in a closet).
3. GO on the AI voice auditions (about 12 credits) and phase 1 images (about 20 credits).
